/* LEITSTELLE DEUTSCHLAND v0.12 – public-procedure-inspired fictional dispatch training.
   Five W intake: https://www.notruf112.bayern.de/5w/
   Bavarian FMS (regional example, not a Germany-wide standard):
   https://www.gesetze-bayern.de/Content/Document/BayVwV156097-2
   No connection to 112, BOS radio, real dispatch software or live incident data. */
(()=>{'use strict';
const KEYS=['where','who','what','howmany','safety'];
const TITLES={where:'Wo ist das Ereignis?',who:'Wer ruft an?',what:'Was ist geschehen?',howmany:'Wie viele Betroffene?',safety:'Gefahren / weitere Rückfragen'};
const safe=x=>String(x??'').slice(0,300);
function stamp(s){return `${String(Math.floor((s.minute||0)/60)%24).padStart(2,'0')}:${String((s.minute||0)%60).padStart(2,'0')}`}
function initialize(i){if(!i)return;i.intake??={};i.callEnded??=false;i.sondersignal??=(i.prio===1);i.history??=[];i.transcript??=[]}
function answerText(i,key){const t=i.type||'';
  if(key==='where')return `Der Notfall ist in ${i.city||'der gemeldeten Region'}. ${i.location||'Genauer Zugang noch unklar.'}`;
  if(key==='who')return `Mein Name ist ${i.caller||'noch nicht genannt'}. Eine Rückrufnummer kann ich gerade nicht sicher angeben.`;
  if(key==='what')return i.intro||`Es handelt sich um einen gemeldeten Einsatz: ${t}.`;
  if(key==='howmany')return /Massenanfall/.test(t)?'Ich sehe mindestens sechs Betroffene, möglicherweise mehr.':/Verkehrsunfall mit Verletzten/.test(t)?'Mindestens zwei Verletzte.':/Person im Aufzug/.test(t)?'Drei Personen sind eingeschlossen.':/Wohnungsbrand|Gewerbebrand/.test(t)?'Es könnten mehrere Menschen betroffen sein; die genaue Zahl ist unbekannt.':'Eine Person ist sicher betroffen; weitere sind nicht bekannt.';
  if(key==='safety')return /Kohlenmonoxid/.test(t)?'Der CO-Warner schlägt an, Personen haben Beschwerden. Ich befinde mich inzwischen draußen.':/Brand|Feuer|Rauch/.test(t)?'Es kann Rauch und weitere Gefahren geben. Ich halte Abstand.':/Verkehrsunfall|Massenanfall/.test(t)?'Der Verkehr läuft teilweise weiter; die Unfallstelle ist noch nicht vollständig abgesichert.':'Ich sehe momentan keine weiteren unmittelbaren Gefahren. Bei Bedarf können Sie nachfragen.';
  return 'Das weiß ich gerade nicht.';
}
function ask(s,id,key,log){const i=s?.incidents?.find(i=>i.id===id);if(!i||!KEYS.includes(key)||['Anruf','Unversorgt','Abgeschlossen'].includes(i.phase))return null;initialize(i);if(i.callEnded)return null;
  const answer=answerText(i,key);i.intake[key]={answer,minute:s.minute};i.transcript.push(`${stamp(s)} · DISPOSITION: ${TITLES[key]}`,`${stamp(s)} · ANRUFER: ${answer}`);i.transcript=i.transcript.slice(-110);i.history.unshift({minute:s.minute,text:`Notrufabfrage: ${TITLES[key]}`});
  i.documentation??={};if(key==='where'&&!i.documentation.location)i.documentation.location=i.location||i.city;if(key==='who'&&!i.documentation.caller)i.documentation.caller=i.caller;if(key==='what'&&!i.documentation.keyword)i.documentation.keyword=i.type;if(key==='howmany'&&!i.documentation.persons)i.documentation.persons=answer;if(key==='safety'&&!i.documentation.danger)i.documentation.danger=answer;
  log?.(`#${id}: ${TITLES[key]} – Angaben erfasst`);return {question:TITLES[key],answer};
}
function hangup(s,id,log){const i=s?.incidents?.find(i=>i.id===id);if(!i||['Anruf','Unversorgt','Abgeschlossen'].includes(i.phase))return false;initialize(i);if(i.callEnded)return false;i.callEnded=true;const missing=KEYS.filter(k=>!i.intake[k]);i.transcript.push(`${stamp(s)} · VERBINDUNG BEENDET (Simulation)`);i.history.unshift({minute:s.minute,text:'Notrufverbindung beendet'+(missing.length?' – ungeklärte Abfragepunkte: '+missing.length:'')});log?.(`#${id}: Notrufverbindung beendet${missing.length?' · '+missing.length+' Abfragepunkte offen':''}`);return true}
function progress(i){initialize(i);return {done:KEYS.filter(k=>i.intake[k]).length,total:KEYS.length,missing:KEYS.filter(k=>!i.intake[k])}}
function fms(v){if(v.stage==='frei'||v.status==='frei')return {code:v.city===v.home?'2':'1',label:v.city===v.home?'Einsatzbereit auf Wache':'Einsatzbereit über Funk'};
 if(v.stage==='alarmiert')return {code:'A',label:'Alarmierung zugestellt – Ausrücken ausstehend'};
 if(v.stage==='Anfahrt')return {code:'3',label:'Einsatzauftrag übernommen / Anfahrt'};
 if(v.stage==='vor Ort')return {code:'4',label:'Einsatzstelle erreicht'};
 if(v.stage==='Transport')return {code:'7',label:'Patiententransport'};
 if(v.stage==='Nachbereitung')return {code:'8',label:'Am Transportziel / Übergabe'};
 return {code:'6',label:'Gebunden / aktuell nicht verfügbar'};
}
function priority(s,id,yes,log){const i=s?.incidents?.find(i=>i.id===id);if(!i||i.phase==='Abgeschlossen')return false;initialize(i);i.sondersignal=!!yes;i.history.unshift({minute:s.minute,text:`Simulierte Einsatzfahrt mit Blau/Horn: ${yes?'vorgesehen':'nicht vorgesehen'}`});log?.(`#${id}: Einsatzfahrt Blau/Horn ${yes?'vorgesehen':'nicht vorgesehen'} (fiktive Disposition)`);return true}
function createRadioRequest(s,v,log){if(!v||v.radioRequest||v.stage!=='vor Ort')return;const i=s.incidents.find(x=>x.id===v.incident);if(!i)return;const urgent=/Massenanfall|Gewerbebrand|Kohlenmonoxid/.test(i.type);v.radioRequest={code:urgent?'9':'5',time:s.minute,text:urgent?'Dringende Rückmeldung: Lageumfang noch unklar. Bitte Führung informieren.':'Lagemeldung von der Einsatzstelle verfügbar.'};s.radioLog??=[];s.radioLog.unshift(`${stamp(s)} · ${v.id}: S${v.radioRequest.code} · Sprechwunsch`);s.radioLog=s.radioLog.slice(0,70);log?.(`${v.id}: S${v.radioRequest.code} · Sprechwunsch eingegangen`)}
function takeRadio(s,id,log){const v=s?.vehicles?.find(v=>v.id===id);if(!v?.radioRequest)return null;const req=v.radioRequest;delete v.radioRequest;const i=s.incidents.find(x=>x.id===v.incident);let answer=req.text;if(i){i.history??=[];i.history.unshift({minute:s.minute,text:`Funk ${v.id}: ${answer}`});}
 s.radioLog??=[];s.radioLog.unshift(`${stamp(s)} · LEITSTELLE → ${v.id}: Sprechaufforderung J`,`${stamp(s)} · ${v.id}: ${answer}`);s.radioLog=s.radioLog.slice(0,70);log?.(`${v.id}: Sprechwunsch abgefragt – ${answer}`);return answer}
function service(s,log){if(!s?.vehicles)return;for(const i of s.incidents)initialize(i);for(const v of s.vehicles){if(v.stage==='vor Ort'&&!v.radioAsked&&v.eta>0){v.radioAsked=true;if(Math.random()<.45)createRadioRequest(s,v,log)}if(v.stage==='frei'){v.radioAsked=false;delete v.radioRequest}}}
function installTick(){const logic=window.LDLogic;if(!logic||logic.__procedureWrapped)return;const original=logic.tick;logic.tick=function(s,...args){const before=s?.minute;original(s,...args);if(s&&s.minute!==before)service(s, args.at(-1))};logic.__procedureWrapped=true}
window.LDProcedures={keys:KEYS,titles:TITLES,initialize,ask,hangup,progress,fms,priority,createRadioRequest,takeRadio,service};installTick();
})();
