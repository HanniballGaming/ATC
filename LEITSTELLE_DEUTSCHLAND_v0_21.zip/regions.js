/* Deutschlandweite, LÜCKENLOSE, aber bewusst VEREINFACHTE Leitstellen-Zuordnung.
   Natural Earth 1:110m Deutschlandumriss, geometrisch auf 18 Simulationsregionen verteilt.
   Die Grenzlinien sind KEINE amtlichen Leitstellengrenzen. */
(()=>{'use strict';
let collection=null, selectionMap=null, selectionLayer=null, gameMap=null, gameLayer=null, gameArea='';
const byArea=new Map(), boundsByArea=new Map();
function coords(feature){const a=[];function walk(v){if(!Array.isArray(v))return;if(typeof v[0]==='number'&&typeof v[1]==='number'){a.push(v);return}v.forEach(walk)}walk(feature.geometry.coordinates);return a}
function getBounds(feature){const xy=coords(feature);return [Math.min(...xy.map(p=>p[0])),Math.min(...xy.map(p=>p[1])),Math.max(...xy.map(p=>p[0])),Math.max(...xy.map(p=>p[1]))]}
function ringHit(ring,lon,lat){let inside=false;for(let i=0,j=ring.length-1;i<ring.length;j=i++){const a=ring[i],b=ring[j];const yes=(a[1]>lat)!==(b[1]>lat)&&lon<(b[0]-a[0])*(lat-a[1])/(b[1]-a[1])+a[0];if(yes)inside=!inside}return inside}
function polygonHit(polygon,lon,lat){if(!ringHit(polygon[0],lon,lat))return false;return !polygon.slice(1).some(h=>ringHit(h,lon,lat))}
function hasPoint(feature,lat,lon){const g=feature.geometry;return g.type==='Polygon'?polygonHit(g.coordinates,lon,lat):g.coordinates.some(p=>polygonHit(p,lon,lat))}
function areaFor(lat,lon){return collection?.features.find(f=>{const b=boundsByArea.get(f.properties.area);return lon>=b[0]&&lon<=b[2]&&lat>=b[1]&&lat<=b[3]&&hasPoint(f,lat,lon)})?.properties.area||null}
function sample(area){const f=byArea.get(area),b=boundsByArea.get(area);if(!f||!b)return null;for(let i=0;i<800;i++){const lon=b[0]+Math.random()*(b[2]-b[0]),lat=b[1]+Math.random()*(b[3]-b[1]);if(hasPoint(f,lat,lon))return [lat,lon]}return null}
function names(f){const names=window.getGame?.()?.areas;return names?.[f.properties.area]?.name||f.properties.area}
function svgPath(feature){const pr=([lon,lat])=>[(lon-5.65)*70,(55.25-lat)*68];const ring=r=>r.map((p,i)=>{const [x,y]=pr(p);return (i?'L':'M')+x.toFixed(1)+' '+y.toFixed(1)}).join('')+'Z';return (feature.geometry.type==='Polygon'?[feature.geometry.coordinates]:feature.geometry.coordinates).map(p=>p.map(ring).join('')).join('')}
function drawSvg(el,interactive=false,incidents=[]){if(!collection)return;el.innerHTML='<svg viewBox="0 0 670 570" style="width:100%;height:100%;background:#112735" role="img" aria-label="Deutschlandweit lückenlose vereinfachte Leitstellengebiete">'+collection.features.map(f=>'<path data-zone="'+f.properties.area+'" d="'+svgPath(f)+'" fill="#245b70" fill-opacity=".57" stroke="#80b3c6" stroke-width="1" stroke-linejoin="round"/>').join('')+incidents.map(i=>{const c=i.coords||window.LDCityCoords?.[i.city]||window.getGame?.()?.areas?.[window.getGame().s.area]?.center||[51,10];return '<circle cx="'+((c[1]-5.65)*70)+'" cy="'+((55.25-c[0])*68)+'" r="5" fill="'+(i.prio===1?'#ff806e':'#ffd475')+'" stroke="#fff"><title>Einsatz #'+i.id+'</title></circle>'}).join('')+'<text x="12" y="554" fill="#bcd4e0" font-size="12">Vereinfachte Gebiete · Natural Earth Public Domain</text></svg>';
 if(interactive){el.querySelectorAll('[data-zone]').forEach(a=>{a.style.cursor='pointer';a.addEventListener('click',()=>{const k=a.dataset.zone,d=document.getElementById('area');if(d){d.value=k;setSelected(k)}})})}
}
function renderFallbackGame(el,incidents){if(!el||!collection)return;drawSvg(el,false,incidents||[]);const chosen=window.getGame?.()?.s?.area;el.querySelectorAll('[data-zone]').forEach(node=>{node.setAttribute('fill',node.dataset.zone===chosen?'#207d8b':'#193d51');node.setAttribute('fill-opacity',node.dataset.zone===chosen?'.8':'.35')})}
function renderMenu(){const el=document.getElementById('selectmap');if(!el||!collection)return;if(!window.L){drawSvg(el,true);setSelected(document.getElementById('area')?.value);return;}
 if(selectionMap&&selectionMap.getContainer()!==el){selectionMap.remove();selectionMap=null;selectionLayer=null}
 if(!selectionMap){selectionMap=L.map(el,{scrollWheelZoom:false,attributionControl:true,zoomControl:true}).setView([51.14,10.47],6);
 L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'© OpenStreetMap-Mitwirkende'}).addTo(selectionMap);
 selectionLayer=L.geoJSON(collection,{style:()=>({color:'#7dbbd0',weight:1.2,fillColor:'#28848e',fillOpacity:.15}),onEachFeature:(feature,layer)=>{const key=feature.properties.area;layer.bindTooltip(names(feature)+' · Gebietsgrenze vereinfacht',{sticky:true});layer.on('click',()=>{const dropdown=document.getElementById('area');if(dropdown){dropdown.value=key;setSelected(key)}layer.openTooltip()})}}).addTo(selectionMap);
 selectionMap.fitBounds(selectionLayer.getBounds(),{padding:[9,9]});
 el.dataset.ready='true';}
 setSelected(document.getElementById('area')?.value);
 setTimeout(()=>selectionMap?.invalidateSize(),50)
}
function setSelected(key){document.querySelectorAll('#selectmap [data-zone]').forEach(node=>{node.setAttribute('fill',node.dataset.zone===key?'#267e94':'#245b70')});if(selectionLayer)selectionLayer.eachLayer(l=>{const chosen=l.feature?.properties.area===key;l.setStyle({fillOpacity:chosen?.36:.12,color:chosen?'#ffc86e':'#81acbf',weight:chosen?2.8:1.2});if(chosen)l.bringToFront()});const status=document.getElementById('region-desc');if(status)status.textContent='Die farbig markierten Gebiete sind vereinfachte Simulations-Zuständigkeiten, keine amtlichen Leitstellengrenzen. Jede dargestellte Fläche ist zugeordnet.'}
function renderOnMap(map,area){if(!map||!collection)return;if(gameMap!==map){gameMap=map;gameLayer=null;gameArea=''}if(gameLayer&&gameArea===area)return;if(gameLayer)gameLayer.remove();gameArea=area;
 const featured=byArea.get(area);if(!featured)return;
 gameLayer=L.geoJSON(collection,{interactive:false,style:f=>({color:f.properties.area===area?'#4fd9e8':'#7292a3',weight:f.properties.area===area?2.2:.55,fillColor:f.properties.area===area?'#4fd9e8':'#88adc1',fillOpacity:f.properties.area===area?.13:.015})}).addTo(map);
}
function zoomCurrent(){const key=window.getGame?.()?.s?.area,f=byArea.get(key),map=window.LDMap?.();if(!f||!map||!window.L)return;map.fitBounds(L.geoJSON(f).getBounds(),{padding:[15,15]})}
async function load(){try{const res=await fetch('./regions.geojson');if(!res.ok)throw Error('HTTP '+res.status);collection=await res.json();if(!Array.isArray(collection.features)||collection.features.length!==18)throw Error('Regionsdaten unvollständig');for(const feature of collection.features){byArea.set(feature.properties.area,feature);boundsByArea.set(feature.properties.area,getBounds(feature))}renderMenu();const g=window.getGame?.();if(g?.s){renderOnMap(window.LDMap?.(),g.s.area)}const node=document.getElementById('region-error');if(node)node.textContent='18 lückenlos zugeordnete, vereinfachte Simulationsgebiete (Landgeometrie: Natural Earth).';}catch(err){console.warn('Vereinfachte Regionsgebiete konnten nicht geladen werden',err);const node=document.getElementById('region-error');if(node)node.textContent='Gebietsgeometrie nicht verfügbar; Leitstellenauswahl funktioniert weiterhin.'}}
window.LDRegions={areaFor,sample,renderMenu,setSelected,renderOnMap,renderFallbackGame,zoomCurrent,get featureCount(){return collection?.features.length||0}};
load();
})();
