from pathlib import Path
import re,json,subprocess,zipfile
p=Path(__file__).parent
html=(p/'index.html').read_text()
files=[x.removeprefix('./') for x in re.findall(r'<script src="([^"]+)"',html) if not x.startswith('http')]
assert len(files)==len(set(files)) and len(files)>25
for f in files:
 assert (p/f).is_file(),f
 subprocess.run(['node','--check',str(p/f)],check=True,capture_output=True)
content='\n'.join(re.findall(r'<script(?: [^>]*)?>(.*?)</script>',html,re.S)).strip()
if content:
 subprocess.run(['node','--check'],input=content,text=True,check=True,capture_output=True)
geo=json.loads((p/'regions.geojson').read_text())
assert len(geo['features'])==18
manifest=json.loads((p/'manifest.webmanifest').read_text())
assert manifest['display']=='standalone'
cache=(p/'sw.js').read_text()
assert 'leitstelle-v020-shell' in cache
assert all(f"'./{f}'" in cache for f in files)
fixed=['index.html','regions.geojson','manifest.webmanifest','sw.js','menu-cover.webp','icon-180.png','icon-192.png','icon-512.png','icon.svg','README.md','VEROEFFENTLICHUNG.md','TESTBERICHT.md','.github/workflows/deploy-pages.yml','START_WINDOWS.cmd','test_v20.py','test_v19.py','test_v16.py','test_v17.py','test_v18.py','test_mobile_v16.py','validate_release_v20.py']
entries=list(dict.fromkeys([*files,*fixed]))
assert all((p/x).exists() for x in entries)
archive=p.parent/'LEITSTELLE_DEUTSCHLAND_v0_20_SPIELBAR.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for x in entries:z.write(p/x,arcname=x)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(entries)
print(f'RELEASE_OK modules={len(files)} files={len(entries)} zip_bytes={archive.stat().st_size}')
print(archive)
