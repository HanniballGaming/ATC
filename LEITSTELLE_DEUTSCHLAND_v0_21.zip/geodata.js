/* Data provenance: OpenStreetMap Overpass objects are mapped locations, not independently verified staffing/vehicles. */
(()=>{'use strict';const cache=new Map();const q=(lat,lon,r)=>`[out:json][timeout:25];(nwr["emergency"="ambulance_station"](around:${r},${lat},${lon});nwr["amenity"="fire_station"](around:${r},${lat},${lon});nwr["emergency"="fire_station"](around:${r},${lat},${lon}););out center;`;
async function loadStations(lat,lon,r=20000){const key=[lat,lon,r].join(':');if(cache.has(key))return cache.get(key);const controller=new AbortController(),t=setTimeout(()=>controller.abort(),15000);try{let j=null,lastError=null;
for(const endpoint of ['https://overpass.kumi.systems/api/interpreter','https://overpass-api.de/api/interpreter']){
  try{
    const res=await fetch(endpoint,{method:'POST',body:new URLSearchParams({data:q(lat,lon,r)}),signal:controller.signal});
    if(!res.ok)throw Error('HTTP '+res.status);
    j=await res.json();if(!Array.isArray(j.elements))throw Error('Ungültige Overpass-Antwort');break;
  }catch(error){lastError=error;if(controller.signal.aborted)break;}
}
if(!j)throw lastError||Error('Kein Overpass-Dienst erreichbar');const items=j.elements.filter(x=>(x.lat??x.center?.lat)!=null).map(x=>({id:x.type+'/'+x.id,name:x.tags?.name||'Nicht benannte Wache',lat:x.lat??x.center.lat,lon:x.lon??x.center.lon,kind:x.tags?.emergency==='ambulance_station'?'RD':'FW',source:'OpenStreetMap',verified:false,osm:`https://www.openstreetmap.org/${x.type}/${x.id}`}));cache.set(key,items);return items;}finally{clearTimeout(t)}}
window.LDGeo={loadStations};})();
