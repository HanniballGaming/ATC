/* LEITSTELLE DEUTSCHLAND v0.17 - fictional standby relocation and area coverage.
   This is a learning simulation: not a real watch roster, dispatch guideline or AAO. */
(()=>{'use strict';
const get=()=>window.LDOperations?.getState?.();
const safe=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const TYPES=['RTW','NEF','HLF'];
const wrapper=document.createElement('div');wrapper.id='ld-coverage';wrapper.setAttribute('role','dialog');wrapper.setAttribute('aria-modal','true');wrapper.setAttribute('aria-label','Gebietsabsicherung (Simulation)');
const css=document.createElement('style');css.textContent=`
#ld-coverage{position:fixed;inset:0;z-index:10030;background:#081725;color:#eaf4fb;font:14px system-ui;display:none;flex-direction:column}
#ld-coverage.open{display:flex}#ld-coverage *{box-sizing:border-box}#ld-coverage header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;padding:14px;background:#16334b;border-bottom:1px solid #588199}
#ld-coverage button,#ld-coverage select{font:inherit;color:#f0ffff;background:#18465e;border:1px solid #5d91a6;border-radius:6px;padding:10px;min-height:41px}#ld-coverage button{cursor:pointer}#ld-coverage button:disabled{opacity:.45;cursor:default}
#ld-coverage main{overflow:auto;padding:16px;max-width:1100px;width:100%;margin:auto}
#ld-coverage .form{display:grid;grid-template-columns:1fr 1fr auto;align-items:end;gap:12px}
#ld-coverage .form label{display:block;color:#b4d7e4;font-size:12px;margin-bottom:5px}
#ld-coverage .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px;margin:15px 0}
#ld-coverage .cell{padding:12px;border:1px solid #47728b;border-radius:7px;background:#112a3e}#ld-coverage .warning{color:#ffd09a}#ld-coverage .small{font-size:12px;color:#b6cbd9}
#ld-coverage .notice{margin-top:14px;padding:9px;border:1px solid #376780;border-radius:6px}
@media(max-width:680px){#ld-coverage .form{grid-template-columns:1fr}#ld-coverage header{padding:9px}#ld-coverage main{padding:9px}}
`;document.head.append(css);document.body.append(wrapper);
function coord(place){const c=window.LDCityCoords?.[place];if(!c)return null;return Array.isArray(c)?{lat:c[0],lon:c[1]}:{lat:c.lat,lon:c.lon}}
function origin(v){return v.stationCoords||coord(v.city)||coord(v.home)||null}
function estimateKm(a,b){if(!a||!b)return null;return window.LDRouting?.crow(a,b)*1.42??null}
function estimateMinutes(v,city,s){const dist=estimateKm(origin(v),coord(city));if(dist===null)return v.city===city?2:18;const avg=s.traffic==='stark'?30:s.traffic==='gering'?56:43;const weather=s.weather==='schlecht'?1.24:1;return Math.max(2,Math.round(dist/avg*60*weather+(v.type==='HLF'?5:2)))}
function matrix(s){const list=window.getGame?.()?.areas?.[s.area]?.cities||[];return list.map(city=>{
 const result={city};for(const type of TYPES){const free=s.vehicles.filter(v=>v.type===type&&v.status==='frei');const best=free.map(v=>({v,minutes:estimateMinutes(v,city,s)})).sort((a,b)=>a.minutes-b.minutes)[0];result[type]=best?{minutes:best.minutes,unit:best.v.id}:null}
 return result;
})}
function relocate(s,unitId,city){
 if(!s||!window.getGame?.()?.areas?.[s.area]?.cities?.includes(city))return {ok:false,reason:'Unbekannter Bereitstellungsort'};
 const v=s.vehicles.find(v=>v.id===unitId);if(!v||v.status!=='frei')return {ok:false,reason:'Fahrzeug derzeit nicht frei'};
 if(v.city===city)return {ok:false,reason:'Fahrzeug befindet sich bereits dort'};
 const dest=coord(city),old=origin(v);
 const km=estimateKm(old,dest),avg=s.traffic==='stark'?30:s.traffic==='gering'?56:43;
 const weather=s.weather==='schlecht'?1.24:1;
 const minutes=Math.max(2,Math.min(120,Math.ceil((km??12)/avg*60*weather)));
 const startCoords=old?[old.lat,old.lon]:null,endCoords=dest?[dest.lat,dest.lon]:null;
 const token=String(s.minute)+':'+unitId+':'+city+':'+(s.coverageMoves||0);
 v.relocation={from:v.city,to:city,startedAt:s.minute,minutes,token,simulated:true,
   startCoords,endCoords,routePath:null,routeSource:'Koordinaten-Ersatzschätzung'};
 v.destinationCity=city;v.destinationCoords=dest||null;
 v.stage='Verlegung';v.status='verlegt';v.eta=minutes;
 v.history??=[];v.history.push({minute:s.minute,status:'verlegt',destination:city});
 s.coverageMoves=(s.coverageMoves||0)+1;
 s.logs??=[];s.logs.unshift(`${String(Math.floor(s.minute/60)%24).padStart(2,'0')}:${String(s.minute%60).padStart(2,'0')} · ${v.id}: Gebietsabsicherung ${city} (ca. ${minutes} Sim.-Min.; fiktiv)`);
 window.LDOperations?.save?.();
 // An OSRM result may refine the travel time and animated route; it is never live traffic.
 // Late replies cannot resurrect finished, redirected or loaded vehicles.
 if(old&&dest&&window.LDRouting?.route){
   window.LDRouting.route(old,dest,{priority:false,turnoutSeconds:0}).then(result=>{
     const active=get()?.vehicles?.find(x=>x.id===unitId);
     if(get()!==s||active!==v||v.stage!=='Verlegung'||v.relocation?.token!==token)return;
     const total=Math.max(2,Math.min(150,Math.ceil(result.drivingSeconds/60*(s.weather==='schlecht'?1.24:1)*(s.traffic==='stark'?1.30:s.traffic==='gering'?.86:1))));
     const elapsed=Math.max(0,s.minute-v.relocation.startedAt);
     v.relocation.minutes=total;
     v.relocation.routePath=Array.isArray(result.path)&&result.path.length>1?result.path:null;
     v.relocation.routeSource=result.method;
     v.eta=Math.max(1,total-elapsed);
     window.LDOperations?.save?.();window.LDGIS?.refresh?.();
   }).catch(()=>{});
 }
 return {ok:true,minutes,unitId,city};
}
function render(){const s=get();if(!s)return close();const places=window.getGame?.()?.areas?.[s.area]?.cities||[];const free=s.vehicles.filter(v=>v.status==='frei');const chosen=wrapper.querySelector('[data-coverage-vehicle]')?.value;
 const chosenPlace=wrapper.querySelector('[data-coverage-city]')?.value;
 const data=matrix(s);
 wrapper.innerHTML=`<header><b>LEITSTELLE DEUTSCHLAND · GEBIETSABSICHERUNG</b><span class="small">Region: ${safe(window.getGame?.()?.areas?.[s.area]?.name||s.area)}</span><span style="flex:1"></span><button data-coverage="close">Zurück ✕</button></header>
 <main><h2>Verfügbarkeit und Bereitstellung</h2><p class="small">Prognose für ausgewählte Orte aus freien Simulationsfahrzeugen. Koordinaten, angenommene Straßenfaktoren und Modell-Aus­rückzeiten; keine amtlichen Hilfsfristdaten.</p>
 <div class="grid">${data.map(item=>`<div class="cell"><b>${safe(item.city)}</b>${TYPES.map(t=>`<div style="margin-top:7px"><small>${t}</small> · ${item[t]?`${item[t].minutes} Min. <small>${safe(item[t].unit)}</small>`:'<span class="warning">Keine freie Einheit</span>'}</div>`).join('')}</div>`).join('')}</div>
 <h3>Fahrzeug zur Gebietsabsicherung verlegen</h3><div class="form"><div><label>Freies Einsatzmittel</label><select data-coverage-vehicle>${free.map(v=>`<option value="${safe(v.id)}" ${v.id===chosen?'selected':''}>${safe(v.id)} · ${safe(v.city)}</option>`).join('')}</select></div><div><label>Simulierter Bereitstellungsort</label><select data-coverage-city>${places.map(city=>`<option value="${safe(city)}" ${city===chosenPlace?'selected':''}>${safe(city)}</option>`).join('')}</select></div><button data-coverage="move" ${!free.length?'disabled':''}>Verlegung anordnen</button></div>
 <p class="notice small">Ein verlegtes Fahrzeug ist bis zur Ankunft nicht als frei verfügbar. Der neue Standort ist ein fiktiver Bereitstellungsort, keine Behauptung über eine echte Wache oder Fahrzeugbesetzung.</p>
 <h3>Verlegungen in Bearbeitung</h3>${s.vehicles.filter(v=>v.stage==='Verlegung').map(v=>`<div class="cell">${safe(v.id)} · ${safe(v.relocation?.from)} → ${safe(v.destinationCity)} · ${v.eta||0} Sim.-Min. · ${safe(v.relocation?.routeSource||'Schätzung')}</div>`).join('')||'<p class="small">Keine laufenden Verlegungen.</p>'}
 <h3>Aktuelle Bereitschaftsorte / Rückverlegung</h3>${s.vehicles.filter(v=>v.status==='frei'&&v.city!==v.home).map(v=>`<div class="cell">${safe(v.id)} · derzeit ${safe(v.city)}, Heimatwache ${safe(v.home)} <button data-coverage="return" data-unit="${safe(v.id)}">Zur Heimatwache zurückverlegen</button></div>`).join('')||'<p class="small">Keine abweichenden Bereitstellungsorte.</p>'}
 <p class="small">Datenquellen: Simulationsfuhrpark; optional OSM-Standortkoordinaten. Nur zum Üben.</p></main>`;
}
function open(){if(!get())return;wrapper.classList.add('open');render()}
function close(){wrapper.classList.remove('open')}
wrapper.addEventListener('click',e=>{const b=e.target.closest('[data-coverage]');if(!b)return;
 if(b.dataset.coverage==='close'){close();return}
 if(b.dataset.coverage==='move'||b.dataset.coverage==='return'){
  const unit=b.dataset.coverage==='return'?b.dataset.unit:wrapper.querySelector('[data-coverage-vehicle]')?.value;
  const vehicle=get()?.vehicles?.find(v=>v.id===unit);
  const city=b.dataset.coverage==='return'?vehicle?.home:wrapper.querySelector('[data-coverage-city]')?.value;
  const result=relocate(get(),unit,city);if(!result.ok)alert(result.reason);render();window.LDRefresh?.();
 }
});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&wrapper.classList.contains('open')){close();e.stopImmediatePropagation()}} ,true);
const btn=document.createElement('button');btn.id='ld-coverage-toggle';btn.textContent='🚑 Gebietsabsicherung';btn.style.cssText='position:fixed;bottom:64px;left:14px;z-index:900;background:#14627e;color:white;border:1px solid #75bfcd;border-radius:7px;padding:10px;cursor:pointer';btn.onclick=open;document.body.append(btn);
setInterval(()=>{btn.style.display=get()?'block':'none';if(wrapper.classList.contains('open'))render()},3500);
window.LDCoverage={open,close,matrix,relocate,estimateMinutes};
})();
