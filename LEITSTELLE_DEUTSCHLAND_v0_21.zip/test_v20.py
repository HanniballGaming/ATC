"""v0.20 integration testing in isolated Chromium with mocked external geodata.
No real BOS network and no iPad hardware assumed.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re, sys
root=Path(__file__).parent
html=(root/'index.html').read_text()
shell=re.sub(r'<script[^>]*>.*?</script>','',html,flags=re.S)
shell=re.sub(r'<link\s+rel="stylesheet"[^>]+>','',shell)
blocks=re.findall(r'<script([^>]*)>(.*?)</script>',html,re.S)
checks=[]
def check(name,condition):
    yes=bool(condition);checks.append(yes);print(('PASS' if yes else 'FAIL')+' | '+name)
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security','--enable-webgl','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    page=browser.new_page(viewport={'width':1180,'height':820},has_touch=True)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(shell)
    geo=(root/'regions.geojson').read_text()
    page.evaluate('''geo=>{const data=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k)}});window.fetch=async(req)=>{if(String(req).includes('regions.geojson'))return new Response(geo,{status:200});throw Error('offline test network disabled')};}''',geo)
    for attrs,code in blocks:
        match=re.search(r'src="([^"]+)',attrs)
        if match:
            if match.group(1).startswith('http'):continue
            code=(root/match.group(1).removeprefix('./')).read_text()
        page.add_script_tag(content=code)
    page.wait_for_timeout(350)
    page.locator('[data-action="new"]').click()
    page.wait_for_timeout(400)
    check('Baseline game starts',page.evaluate('!!window.LDCaseQuality && !!window.LDDialogueMulti && !!window.LDWorkstation && !!window.getGame().s'))
    first=page.evaluate('window.getGame().s.incidents[0].id')
    check('New quality check lists 5 documentation fields',page.evaluate('id=>window.LDCaseQuality.checks(window.getGame().s,window.getGame().s.incidents.find(i=>i.id===id)).items.length===5',first))
    check('Pending call is warned',page.evaluate('id=>window.LDCaseQuality.checks(window.getGame().s,window.getGame().s.incidents.find(i=>i.id===id)).warnings.some(w=>w.key==="waiting")',first))
    check('Unfilled location cannot be confirmed',page.evaluate('''id=>{const s=window.getGame().s,i=s.incidents.find(x=>x.id===id);i.documentation.location='';return !window.LDCaseQuality.confirm(s,id,'place').ok}''',first))
    check('Unknown QA item cannot be confirmed',page.evaluate('''id=>!window.LDCaseQuality.confirm(window.getGame().s,id,'forged').ok''',first))
    page.evaluate('''id=>{const s=getGame().s,i=s.incidents.find(x=>x.id===id);i.documentation.location='Teststraße 12, Augsburg (rein fiktiv)';i.documentation.persons='Eine Person';i.documentation.danger='Keine bekannt';i.documentation.access='Treppenhaus';i.documentation.phone='0123456789';}''',first)
    for key in ['place','persons','hazards','access','callback']:
        check('Check '+key+' can be documented',page.evaluate('''x=>window.LDCaseQuality.confirm(window.getGame().s,x.id,x.key).ok''',{'id':first,'key':key}))
    check('Quality progress 100%',page.evaluate('''id=>{const s=getGame().s;return window.LDCaseQuality.checks(s,s.incidents.find(x=>x.id===id)).percent===100}''',first))
    check('Audit is recorded in case history',page.evaluate('''id=>getGame().s.incidents.find(x=>x.id===id).history.some(h=>h.text.includes('Leitplatzprüfung'))''',first))
    page.evaluate('window.openWorkstation("case")')
    page.wait_for_timeout(250)
    check('Quality panel linked to existing monitor 2',page.locator('#elsdesk #ld20-review button').count()==1)
    page.locator('#elsdesk #ld20-review button').click()
    check('Full checklist modal accessible',page.locator('#ld20-qa.open').count()==1)
    check('Quality modal displays progress', '5 von 5' in page.locator('#ld20-qa').inner_text())
    page.locator('#ld20-qa [data-qa="review"]').click()
    check('Quality review time persisted',page.evaluate('id=>Number.isFinite(getGame().s.incidents.find(x=>x.id===id).qa.reviewedAt)',first))
    page.locator('#ld20-qa [data-qa="close"]').click()
    check('Modal dismissible',page.locator('#ld20-qa.open').count()==0)
    page.evaluate('window.LDOperations.accept('+str(first)+')')
    response=page.evaluate('''id=>window.LDLogic.converse(getGame().s,id,'Wie alt ist die Person und atmet sie noch?',()=>{})''',first)
    check('Multiple questions answered together',response is not None and response.get('multi') and response.get('parts')==2)
    check('Multi-turn transcript saved',page.evaluate('id=>getGame().s.incidents.find(x=>x.id===id).transcript.filter(t=>t.includes("ANRUFER")).length>=2',first))
    repeat=page.evaluate('''id=>window.LDLogic.converse(getGame().s,id,'Wie alt ist die Person und atmet sie noch?',()=>{})''',first)
    check('Multi-part caller answers stable across repetition',response.get('answer')==repeat.get('answer'))
    page.evaluate('window.LDOperations.save()')
    check('Quality audit persists in local game save',page.evaluate('localStorage.getItem("leitstelle-deutschland-save-v1").includes("completedReview")||localStorage.getItem("leitstelle-deutschland-save-v1").includes("reviewedAt")'))
    page.evaluate('''id=>{const s=getGame().s,i=s.incidents.find(x=>x.id===id);i.phase='Unterwegs';i.assigned=['TEST-UNIT'];i.need=[];s.nextCall=100000;window.LDLogic.tick(s,getGame().areas,getGame().types,()=>{});}''',first)
    check('Closed incident receives archived quality review',page.evaluate('''id=>{const i=getGame().s.incidents.find(x=>x.id===id);return i.phase==='Abgeschlossen'&&i.qa.completedReview===true}''',first))
    check('No JavaScript runtime error',not errors)
    if errors:print('JS Errors:',errors[:10])
    browser.close()
print(f'{sum(checks)}/{len(checks)} tests passed')
if not all(checks):sys.exit(1)
