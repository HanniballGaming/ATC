/* Location-aware operational map. OSM tiles are external and online-only.
   Markers are fictional incidents/vehicles, not genuine control-room data. */
(()=>{'use strict';
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const style=document.createElement('style');style.textContent=`
#ld-gis{position:fixed;inset:0;z-index:10001;display:none;flex-direction:column;background:#091927;color:#ecf7fc;font:13px system-ui}#ld-gis.open{display:flex}#ld-gis .header{display:flex;gap:10px;align-items:center;flex-wrap:wrap;background:#17324a;border-bottom:1px solid #5b849b;padding:9px}#ld-gis button{background:#18546e;border:1px solid #5a9cae;color:white;padding:9px;border-radius:5px}#ld-gis .body{display:grid;grid-template-columns:minmax(0,1fr) 285px;flex:1;min-height:0}#ld-gis .map{min-height:220px;background:#142b3a;position:relative}#ld-gis .list{overflow:auto;padding:10px;background:#102335;border-left:1px solid #4e7083}#ld-gis .record{padding:10px 0;border-bottom:1px solid #476579}#ld-gis .legend{background:#173247;padding:7px;color:#accad7}#ld-gis .fallback{height:100%;width:100%;display:block}#ld-gis .small{color:#acc5d4;font-size:11px}#ld-gis button.active{background:#176a7b}@media(max-width:800px){#ld-gis .body{display:flex;flex-direction:column}#ld-gis .map{flex:1;min-height:40vh}#ld-gis .list{max-height:30vh;border-left:0;border-top:1px solid #4e7083}}`;document.head.append(style);
const root=document.createElement('div');root.id='ld-gis';root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');root.setAttribute('aria-label','Digitale Lagekarte (Simulation)');root.innerHTML=`<div class="header"><b>LEITSTELLE DEUTSCHLAND · GEODATENANSICHT</b><span class="small" id="ld-gis-state">Fiktive Einsatz- und Fahrzeugpositionen</span><div style="flex:1"></div><button data-gis="area" class="active">Leitstellenbereich</button><button data-gis="germany">Deutschland</button><button data-gis="close">Zurück zu den Monitoren ✕</button></div><div class="body"><div class="map" id="ld-gis-map"></div><aside class="list" id="ld-gis-list"></aside></div><div class="legend">● Rot: dringender Einsatz · ● Gelb: weiterer Einsatz · ● Türkis: verfügbares Simulationsfahrzeug · ● Grau: gebunden · © OpenStreetMap-Mitwirkende (nur Online-Kacheln)</div>`;document.body.append(root);
let map=null,markers=null,mode='area',previous=[],timer=null,lastArea=null;const state=()=>window.LDOperations?.getState?.();
function coordI(i,s){const c=i.coords||window.LDCityCoords?.[i.city]||window.getGame?.()?.areas?.[s.area]?.center||[51,10];return Array.isArray(c)?[c[0],c[1]]:[c.lat,c.lon]}
function coordV(v,s){
 const c=v.stationCoords||window.LDCityCoords?.[v.home]||window.LDCityCoords?.[v.city]||window.getGame?.()?.areas?.[s.area]?.center||[51,10];
 const station=Array.isArray(c)?[c[0],c[1]]:[c.lat,c.lon];
 if(v.stage==='Verlegung'&&v.relocation){
   const r=v.relocation,start=r.startCoords||station,end=r.endCoords||station;
   const fraction=Math.max(0,Math.min(1,1-(v.eta||0)/Math.max(1,r.minutes||v.eta||1)));
   if(Array.isArray(r.routePath)&&r.routePath.length>1&&window.LDRouting?.interpolate){
     const point=window.LDRouting.interpolate(r.routePath,fraction);
     if(point&&point.every(Number.isFinite))return point;
   }
   return [start[0]+(end[0]-start[0])*fraction,start[1]+(end[1]-start[1])*fraction];
 }
 const incident=s?.incidents?.find(i=>i.id===v.incident);
 if(!incident||!Number.isFinite(station[0])||!Number.isFinite(station[1]))return station;
 const destination=coordI(incident,s),interpolate=t=>[station[0]+(destination[0]-station[0])*t,station[1]+(destination[1]-station[1])*t];
 if(v.stage==='alarmiert')return station;
 if(v.stage==='Anfahrt'){
   const total=Math.max(1,v.travelMinutes||7),fraction=Math.max(0,Math.min(1,1-(v.eta||0)/total));
   if(v.routeGeometrySource==='OSRM-Straßengeometrie'&&Array.isArray(v.routePath)&&window.LDRouting?.interpolate){
     const mapped=window.LDRouting.interpolate(v.routePath,fraction);
     if(mapped&&mapped.every(Number.isFinite))return mapped;
   }
   return interpolate(fraction);
 }
 if(['vor Ort','Transport','Nachbereitung'].includes(v.stage))return destination;
 if(v.stage==='Rückfahrt'){const t=Math.max(0,Math.min(1,(v.eta||0)/10));return interpolate(t)}
 return station;
}

function position(c,frame){const x=(c[1]-frame.left)/(frame.right-frame.left)*1000,y=(frame.top-c[0])/(frame.top-frame.bottom)*680;return [x,y]}
function svgFallback(s,area){const center=window.getGame?.()?.areas?.[s.area]?.center||[51,10];const frame=mode==='germany'?{left:5.7,right:15.2,top:55.2,bottom:47.2}:{left:center[1]-.75,right:center[1]+.75,top:center[0]+.58,bottom:center[0]-.58};
const lines=[...Array(11)].map((_,n)=>`<line x1="${n*100}" y1="0" x2="${n*100}" y2="680" stroke="#28465b"/>`).join('')+[...Array(8)].map((_,n)=>`<line x1="0" y1="${n*97}" x2="1000" y2="${n*97}" stroke="#28465b"/>`).join('');
const incidents=s.incidents.filter(i=>i.phase!=='Abgeschlossen').map(i=>{const c=coordI(i,s),[x,y]=position(c,frame);if(x<0||x>1000||y<0||y>680)return '';return `<g><circle cx="${x}" cy="${y}" r="10" stroke="#fff" stroke-width="2" fill="${i.prio===1?'#d9484d':'#e5b845'}"/><text x="${x+14}" y="${y+4}" fill="white" font-size="16">#${i.id}</text></g>`}).join('');
const units=s.vehicles.map(v=>{const [x,y]=position(coordV(v,s),frame);if(x<0||x>1000||y<0||y>680)return '';return `<circle cx="${x}" cy="${y}" r="6" fill="${v.status==='frei'?'#6fd4bd':'#718d9f'}" stroke="#193348"/>`}).join('');
const el=root.querySelector('#ld-gis-map');el.innerHTML=`<svg class="fallback" viewBox="0 0 1000 680" role="img" aria-label="Koordinatenübersicht ohne Online-Kartenkacheln"><rect width="1000" height="680" fill="#123148"/>${lines}<text x="20" y="30" fill="#d4e3ef" font-size="22">${mode==='germany'?'Deutschland – Koordinatenübersicht':esc(area)} · vereinfachte Standortdarstellung</text>${units}${incidents}<text x="20" y="652" fill="#adc6d8" font-size="18">Keine Straßengeometrie im Offline-Fallback – reale Geografie nur mit OSM-Kartenkacheln</text></svg>`}
function render(){if(!root.classList.contains('open'))return;const s=state();if(!s)return close();const region=window.getGame?.()?.areas?.[s.area]?.name||s.area;
root.querySelector('#ld-gis-state').textContent=`${region} · ${s.incidents.filter(i=>i.phase!=='Abgeschlossen').length} offene Vorgänge · Simulierte Daten`;
const el=root.querySelector('#ld-gis-list');el.innerHTML=`<h3>Vorgänge</h3>${s.incidents.filter(i=>i.phase!=='Abgeschlossen').sort((a,b)=>a.prio-b.prio).slice(0,40).map(i=>`<div class="record"><strong>#${i.id} · ${esc(i.type)}</strong><div class="small">${esc(i.city)}, P${i.prio}, ${esc(i.phase)}</div><button data-gis="case" data-id="${i.id}">Einsatzakte öffnen</button></div>`).join('')||'<p>Keine offenen Einsätze.</p>'}<h3>Fahrzeugbestand</h3><div class="small">${s.vehicles.filter(v=>v.status==='frei').length}/${s.vehicles.length} einsatzbereit (simuliert)</div><p class="small">Fahrzeugpositionen sind simuliert. Türkise Routen: Einsatzfahrt, orange gestrichelte Routen: Gebietsabsicherung. Verfügbare OSRM-Straßengeometrien werden als Routenweg verwendet, andernfalls eine lineare Näherung. Keine GPS- oder Live-Verkehrsdaten.</p>`;
if(!window.L){svgFallback(s,region);return}
try{const container=root.querySelector('#ld-gis-map');if(!map||map.getContainer()!==container){if(map)map.remove();container.innerHTML='';map=L.map(container,{scrollWheelZoom:false,preferCanvas:true}).setView(window.getGame().areas[s.area].center,9);L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'© OpenStreetMap-Mitwirkende'}).addTo(map);markers=L.layerGroup().addTo(map);lastArea=null}
if(mode==='germany')map.setView([51,10.4],6,{animate:false});else if(lastArea!==s.area)map.setView(window.getGame().areas[s.area].center,9,{animate:false});lastArea=s.area;markers.clearLayers();for(const i of s.incidents.filter(i=>i.phase!=='Abgeschlossen')){L.circleMarker(coordI(i,s),{radius:8,color:'#e6ecf2',weight:1,fillOpacity:.9,fillColor:i.prio===1?'#d9484d':'#e5b845'}).bindPopup(`#${i.id}: ${esc(i.type)} – ${esc(i.city)} (Simulation)`).addTo(markers)}for(const v of s.vehicles.filter(v=>v.stage==='Anfahrt'&&v.routeGeometrySource==='OSRM-Straßengeometrie'&&Array.isArray(v.routePath)).slice(0,8)){
 L.polyline(v.routePath,{color:'#57cbd9',weight:2,opacity:.7,interactive:false}).addTo(markers);
}for(const v of s.vehicles.filter(v=>v.stage==='Verlegung'&&Array.isArray(v.relocation?.routePath)&&v.relocation.routePath.length>1).slice(0,8)){
 L.polyline(v.relocation.routePath,{color:'#f0b66b',weight:2,dashArray:'6 7',opacity:.8,interactive:false}).addTo(markers);
}for(const v of s.vehicles){L.circleMarker(coordV(v,s),{radius:4,color:'#1e3646',weight:1,fillColor:v.status==='frei'?'#6fd4bd':'#8099ac',fillOpacity:.85}).bindPopup(`${esc(v.id)}: ${esc(v.status)} (Simulationsposition)`).addTo(markers)}setTimeout(()=>map?.invalidateSize(),0)
}catch(err){console.warn('Online-Karte nicht verfügbar',err);map?.remove();map=null;svgFallback(s,region)}}
function open(){if(!state())return;root.classList.add('open');render();clearInterval(timer);timer=setInterval(render,3500)}
function close(){root.classList.remove('open');clearInterval(timer);timer=null;if(map){map.remove();map=null}root.querySelector('#ld-gis-map').replaceChildren()}
root.addEventListener('click',e=>{const b=e.target.closest('[data-gis]');if(!b)return;const a=b.dataset.gis;if(a==='close')close();else if(a==='area'||a==='germany'){mode=a;root.querySelectorAll('[data-gis="area"],[data-gis="germany"]').forEach(x=>x.classList.toggle('active',x.dataset.gis===mode));render()}else if(a==='case'){const id=b.dataset.id;close();window.openWorkstation?.('case');document.querySelector(`#elsdesk .item[data-id="${id}"]`)?.click()}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&root.classList.contains('open')){e.preventDefault();e.stopImmediatePropagation();close()}} ,true);
const observer=new MutationObserver(()=>{const pane=document.querySelector('#elsdesk [data-panel="case"]');if(!pane||pane.querySelector('[data-gis-open]'))return;const b=document.createElement('button');b.dataset.gisOpen='true';b.className='primary';b.textContent='🗺 Digitale Lagekarte öffnen';b.title='Fiktive Einsatz- und Fahrzeugstandorte auf einer geographischen Karte';b.onclick=open;pane.querySelector('h3')?.insertAdjacentElement('afterend',b)});
observer.observe(document.getElementById('elsdesk'),{childList:true,attributes:true,attributeFilter:['class']});
window.LDGIS={open,close,refresh:render,getSimulatedUnitLocation:coordV};
})();
