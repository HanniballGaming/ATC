/* LEITSTELLE DEUTSCHLAND v0.15 — simulation-only call correlation and resource management.
   No official 112 dispatch connection; not an operational dispatch protocol. */
(()=>{'use strict';
const desk=document.getElementById('elsdesk');
const get=()=>window.LDOperations?.getState?.();
const clean=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const stamp=m=>`${String(Math.floor(m/60)%24).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`;
function ensure(s){if(!s)return; s.coordination??={version:15,audit:[],merges:0,recalls:0,reassignments:0};
 s.coordination.audit??=[];s.coordination.merges??=0;s.coordination.recalls??=0;s.coordination.reassignments??=0;
 for(const i of s.incidents||[]){i.mergedFrom??=[];i.history??=[];i.assigned??=[];i.need??=[];}
 return s.coordination;
}
function audit(s,kind,txt,cases=[]){ensure(s);let entry={minute:s.minute,kind,text:String(txt),incidents:[...cases]};s.coordination.audit.unshift(entry);s.coordination.audit=s.coordination.audit.slice(0,100);
 s.logs??=[];s.logs.unshift(stamp(s.minute)+' · '+entry.text);s.logs=s.logs.slice(0,150);
 for(const id of cases){const i=s.incidents.find(x=>x.id===id);if(i){i.history.unshift({minute:s.minute,text:entry.text});i.history=i.history.slice(0,90)}} return entry;
}
function placeMatch(a,b){if(!a||!b)return false;
 if(Array.isArray(a.coords)&&Array.isArray(b.coords)&&a.coords.length>=2&&b.coords.length>=2){
  const R=6371,rad=Math.PI/180,phi1=a.coords[0]*rad,phi2=b.coords[0]*rad,dphi=(b.coords[0]-a.coords[0])*rad,dl=(b.coords[1]-a.coords[1])*rad;
  const h=Math.sin(dphi/2)**2+Math.cos(phi1)*Math.cos(phi2)*Math.sin(dl/2)**2;
  return 2*R*Math.asin(Math.min(1,Math.sqrt(h)))<=1.5;
 }
 const loc=x=>String(x.documentation?.location||x.location||'').trim().toLowerCase();
 const la=loc(a),lb=loc(b);if(la.length>8&&la===lb)return true;
 return String(a.city||'').trim().toLowerCase()===String(b.city||'').trim().toLowerCase();
}
function canMerge(s,sourceId,targetId){const source=s?.incidents?.find(x=>x.id===Number(sourceId)),target=s?.incidents?.find(x=>x.id===Number(targetId));
 if(!source||!target||source===target)return {ok:false,error:'Zwei unterschiedliche Vorgänge auswählen.'};
 if(source.phase==='Abgeschlossen'||target.phase==='Abgeschlossen')return {ok:false,error:'Abgeschlossene Vorgänge können nicht zusammengeführt werden.'};
 if(source.type!==target.type)return {ok:false,error:'Unterschiedliche Einsatzstichworte – zuerst prüfen.'};
 if(!placeMatch(source,target))return {ok:false,error:'Keine hinreichende räumliche Übereinstimmung.'};
 if(Math.abs((source.createdAt??s.minute)-(target.createdAt??s.minute))>30)return {ok:false,error:'Meldungen liegen mehr als 30 Simulationsminuten auseinander.'};
 return {ok:true,source,target};
}
function candidates(s,id){ensure(s);const target=s.incidents.find(x=>x.id===Number(id));if(!target)return [];return s.incidents.filter(x=>x.id!==target.id&&canMerge(s,x.id,target.id).ok).sort((a,b)=>Math.abs(a.createdAt-target.createdAt)-Math.abs(b.createdAt-target.createdAt)).map(i=>({id:i.id,type:i.type,city:i.city,age:i.age,phase:i.phase}));}
function counts(i,s){const c={};for(const t of i.need||[])c[t]=(c[t]||0)+1;
 for(const unit of i.assigned||[]){const v=s.vehicles.find(v=>v.id===unit);if(v)c[v.type]=(c[v.type]||0)+1;}return c;
}
function merge(s,sourceId,targetId){ensure(s);const test=canMerge(s,sourceId,targetId);if(!test.ok)return test;
 const {source,target}=test;const desiredA=counts(source,s),desiredB=counts(target,s);const desired={};
 for(const key of new Set([...Object.keys(desiredA),...Object.keys(desiredB)]))desired[key]=Math.max(desiredA[key]||0,desiredB[key]||0);
 const attached=new Set([...target.assigned,...source.assigned]);target.assigned=[...attached];
 for(const v of s.vehicles)if(v.incident===source.id)v.incident=target.id;
 const bound={};for(const id of target.assigned){const v=s.vehicles.find(x=>x.id===id);if(v)bound[v.type]=(bound[v.type]||0)+1;}
 target.need=Object.entries(desired).flatMap(([type,n])=>Array(Math.max(0,n-(bound[type]||0))).fill(type));
 target.prio=Math.min(target.prio,source.prio);if(target.documentation)target.documentation.priority=String(target.prio);
 target.mergedFrom??=[];target.mergedFrom.push(source.id,...(source.mergedFrom||[]));target.mergedFrom=[...new Set(target.mergedFrom)];
 target.transcript??=[];target.transcript.push(`${stamp(s.minute)} · Weitere Meldung #${source.id} demselben simulierten Ereignis zugeordnet.`);
 for(const line of source.transcript||[])target.transcript.push(`[Weitere Meldung #${source.id}] ${line}`);
 target.transcript=target.transcript.slice(-100);
 target.notes??=[];target.notes.push(`Weiterer Melder aus Vorgang #${source.id}`);
 if(target.assigned.length&&['Anruf','Unversorgt','Disponierung'].includes(target.phase))target.phase='Unterwegs';
 source.mergedInto=target.id;source.phase='Abgeschlossen';source.closedAt=s.minute;source.need=[];source.assigned=[];source.callEnded=true;
 audit(s,'Zusammenführung',`Doppelte Meldung #${source.id} kontrolliert in #${target.id} übernommen.`,[source.id,target.id]);
 s.coordination.merges++;return {ok:true,target:target.id,source:source.id};
}
function canRecall(s,unitId){const v=s?.vehicles?.find(v=>v.id===unitId);if(!v||!v.incident)return {ok:false,error:'Fahrzeug ist keinem Vorgang zugeordnet.'};
 if(!['alarmiert','Anfahrt'].includes(v.stage))return {ok:false,error:'Rücknahme im Modell nur vor dem Eintreffen zulässig.'};
 const source=s.incidents.find(i=>i.id===v.incident);if(!source||source.phase==='Abgeschlossen')return {ok:false,error:'Kein aktiver Ausgangsvorgang.'};
 return {ok:true,v,source};
}
function recall(s,unitId){ensure(s);const test=canRecall(s,unitId);if(!test.ok)return test;const {v,source}=test;
 source.assigned=source.assigned.filter(x=>x!==v.id);source.need.push(v.type);const id=source.id;
 const hadDeparted=v.stage==='Anfahrt',enRouteMinutes=Math.max(1,(v.travelMinutes||5)-(v.eta||0));
 v.incident=null;v.departure=null;v.radioPending=false;
 // After turnout a cancelled unit cannot teleport back to its station; it is unavailable during its return.
 if(hadDeparted){v.stage='Rückkehr nach Abbruch';v.status='Rückfahrt';v.eta=Math.max(2,Math.min(15,Math.ceil(enRouteMinutes*.75)));}
 else{v.stage='frei';v.status='frei';v.eta=0;}
 v.history??=[];v.history.push({minute:s.minute,status:hadDeparted?'Rückfahrt (abgebrochen)':'frei / Rücknahme',incident:id});
 audit(s,'Rücknahme',`${v.id} vor Eintreffen von #${id} zurückgenommen; ${hadDeparted?'Rückkehr zur Wache läuft':'am Standort wieder frei'}; Bedarf ${v.type} erneut offen.`,[id]);
 s.coordination.recalls++;return {ok:true,unit:v.id,source:id};
}
function reassign(s,unitId,targetId){ensure(s);const test=canRecall(s,unitId);if(!test.ok)return test;
 const {v,source}=test,target=s.incidents.find(i=>i.id===Number(targetId));if(!target||target.id===source.id||!['Disponierung','Unterwegs','Am Einsatzort'].includes(target.phase))return {ok:false,error:'Ein anderer bereits angenommener Einsatz muss ausgewählt werden.'};
 if(!(target.need||[]).includes(v.type))return {ok:false,error:`Einsatz #${target.id} hat keinen offenen Bedarf für ${v.type}.`};
 if(!(Number(target.prio)<Number(source.prio)))return {ok:false,error:'Umverteilung im Trainingsmodell nur zu höher priorisierten Lagen (kleinere P-Nummer).'};
 const backup={status:v.status,stage:v.stage,eta:v.eta,incident:v.incident,travelMinutes:v.travelMinutes,routeMethod:v.routeMethod,priority:v.priority,departure:v.departure,origin:v.origin,target:v.target,history:v.history?.slice()};
 const oldAssigned=[...source.assigned],oldNeed=[...source.need];
 source.assigned=source.assigned.filter(x=>x!==v.id);source.need.push(v.type);v.status='frei';v.stage='frei';v.incident=null;v.eta=0;
 let ok=false;try{ok=!!window.LDLogic.dispatch(s,target.id,v.type,v.id,()=>{});}catch{};
 if(!ok){Object.assign(v,backup);source.assigned=oldAssigned;source.need=oldNeed;return {ok:false,error:'Neuzuweisung gescheitert; ursprüngliche Alarmierung wiederhergestellt.'}}
 if(backup.stage==='Anfahrt'){
   // A vehicle already moving has no fresh turnout. Exact intermediate position is unavailable.
   v.stage='Anfahrt';v.status='Anfahrt';v.turnout=0;v.departure=s.minute;
   v.eta=Math.max(2,v.travelMinutes||6);v.routingEstimateAssumption=true;v.routeMethod=(v.routeMethod||'Modell')+' · Umverteilung ab geschätzter Zwischenposition';
 }
 audit(s,'Umverteilung',`${v.id} von #${source.id} zu zeitkritischerem Vorgang #${target.id} umverteilt${backup.stage==='Anfahrt'?' (Fahrt ab Zwischenposition geschätzt)':''}.`,[source.id,target.id]);
 s.coordination.reassignments++;return {ok:true,unit:v.id,source:source.id,target:target.id};
}
function summary(s){ensure(s);const pending=s.incidents.filter(i=>['Anruf','Unversorgt'].includes(i.phase));const free=s.vehicles.filter(v=>v.status==='frei');
 const unfilled=s.incidents.filter(i=>i.phase!=='Abgeschlossen'&&i.phase!=='Anruf'&&i.need?.length);
 return {pending:pending.length,oldest:Math.max(0,...pending.map(i=>i.age||0)),free:free.length,unfilled:unfilled.length,
   merges:s.coordination.merges,recalls:s.coordination.recalls,reassignments:s.coordination.reassignments};
}
window.LDCoordination={ensure,candidates,canMerge,merge,canRecall,recall,reassign,summary,placeMatch};
const css=document.createElement('style');css.textContent=`#elsdesk .ld15{padding:11px;margin:12px 0;background:#102a3d;border:1px solid #58768e;border-radius:8px}#elsdesk .ld15 h4{margin:0 0 7px;color:#a9eff3}#elsdesk .ld15 .muted{font-size:11px}#elsdesk .ld15-row{padding:7px 0;border-bottom:1px solid #2f5063;display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:space-between}#elsdesk .ld15-row>*{max-width:100%}#elsdesk .ld15-row select{max-width:300px;min-width:120px}#elsdesk .ld15-row button{min-height:34px}#elsdesk .ld15-tag{background:#173f52;border-radius:5px;padding:3px 7px}#elsdesk .ld15-alarm{color:#ffb6b6}#elsdesk .ld15-split{display:flex;gap:7px;flex-wrap:wrap;align-items:center}#elsdesk .ld15-split>*{flex:1 1 135px}#elsdesk .ld15 button:disabled{opacity:.4}`;document.head.append(css);
let lastSig='';
function currentId(){const active=desk.querySelector('article[data-panel="call"] .item.active[data-id]')||desk.querySelector('article .item.active[data-id]');return Number(active?.dataset.id)}
function buildPanels(){const s=get();if(!s||!desk?.classList.contains('open'))return;ensure(s);
 const call=desk.querySelector('article[data-panel="call"]'),casePanel=desk.querySelector('article[data-panel="case"]'),resources=desk.querySelector('article[data-panel="resources"]');if(!call||!casePanel||!resources)return;
 const activeId=currentId(),incident=s.incidents.find(i=>i.id===activeId&&i.phase!=='Abgeschlossen')||s.incidents.find(i=>i.phase!=='Abgeschlossen');
 const report=summary(s);const candidatesList=incident?candidates(s,incident.id):[];
 const sig=[s.minute,incident?.id,report.pending,report.oldest,report.free,report.unfilled,s.coordination.merges,s.coordination.recalls,s.coordination.reassignments,s.incidents.length,s.vehicles.map(v=>[v.id,v.stage,v.incident].join(':')).join(';')].join('|');
 if(sig===lastSig&&call.querySelector('#ld15-queue')&&casePanel.querySelector('#ld15-merge')&&resources.querySelector('#ld15-resource'))return;
 if(desk.querySelector('#ld15-resource select:focus'))return;
 lastSig=sig;
 let queue=call.querySelector('#ld15-queue');if(!queue){queue=document.createElement('section');queue.className='ld15';queue.id='ld15-queue';call.querySelector('h3')?.after(queue)}
 const wait=s.incidents.filter(i=>['Anruf','Unversorgt'].includes(i.phase)).sort((a,b)=>a.prio-b.prio||b.age-a.age);
 queue.innerHTML=`<h4>☎ Leitungs- und Warteschlangenübersicht</h4><div class="ld15-split"><span class="ld15-tag">${report.pending} unbeantwortet</span><span class="ld15-tag ${report.oldest>5?'ld15-alarm':''}">Längste Wartezeit ${report.oldest} Sim.-Min.</span></div>${wait.slice(0,6).map(i=>`<div class="ld15-row"><span><b>#${i.id}</b> · ${clean(i.type)}<br><span class="muted">${clean(i.city)} · P${i.prio} · ${i.age||0} Min.</span></span><button data-coord="select-call" data-id="${i.id}">Vorgang öffnen</button></div>`).join('')||'<p class="muted">Keine wartenden Notrufe.</p>'}<p class="muted">Die Priorisierung ist ein Spielmodell, keine amtliche Notruf-Triage.</p>`;
 let mergePanel=casePanel.querySelector('#ld15-merge');if(!mergePanel){mergePanel=document.createElement('section');mergePanel.className='ld15';mergePanel.id='ld15-merge';casePanel.querySelector('h3')?.after(mergePanel)}
 mergePanel.innerHTML=`<h4>Doppelmeldungen · Lagezuordnung</h4>${incident?`<p class="muted">Aktueller Vorgang #${incident.id}: gleicher Einsatztyp, räumliche Nähe und maximal 30 Sim.-Minuten Abstand.</p>${candidatesList.length?candidatesList.map(x=>`<div class="ld15-row"><span>#${x.id} · ${clean(x.city)} · ${clean(x.phase)}</span><button data-coord="merge" data-source="${x.id}" data-target="${incident.id}">Meldung übernehmen</button></div>`).join(''):'<p class="muted">Keine eindeutig passenden weiteren Meldungen erkannt.</p>'}`:'<p class="muted">Kein aktiver Vorgang.</p>'}<p class="muted">Nur nach manueller Bestätigung; alle Einträge bleiben im Protokoll nachvollziehbar.</p>`;
 let resource=resources.querySelector('#ld15-resource');if(!resource){resource=document.createElement('section');resource.className='ld15';resource.id='ld15-resource';resources.querySelector('h3')?.after(resource)}
 const inRoute=s.vehicles.filter(v=>v.incident&&['alarmiert','Anfahrt'].includes(v.stage));
 resource.innerHTML=`<h4>Rücknahme und Umverteilung</h4><div class="ld15-split"><span class="ld15-tag">${report.free} freie Mittel</span><span class="ld15-tag ${report.unfilled?'ld15-alarm':''}">${report.unfilled} Einsätze mit offenem Kräftebedarf</span></div>${inRoute.slice(0,12).map(v=>{const origin=s.incidents.find(i=>i.id===v.incident);const targets=s.incidents.filter(i=>i.id!==v.incident&&['Disponierung','Unterwegs','Am Einsatzort'].includes(i.phase)&&i.prio<origin?.prio&&i.need?.includes(v.type));return `<div class="ld15-row"><span><b>${clean(v.id)}</b> · ${clean(v.stage)}<br><span class="muted">#${v.incident}, P${origin?.prio||'?'} · ${v.eta||0} Min.</span></span><div class="ld15-split"><button data-coord="recall" data-unit="${clean(v.id)}">Alarm zurücknehmen</button>${targets.length?`<select data-transfer="${clean(v.id)}" aria-label="Zieleinsatz für ${clean(v.id)}">${targets.map(i=>`<option value="${i.id}">#${i.id} · P${i.prio}</option>`).join('')}</select><button data-coord="transfer" data-unit="${clean(v.id)}">Umverteilen</button>`:''}</div></div>`}).join('')||'<p class="muted">Kein alarmiertes oder anfahrendes Mittel zur Rücknahme.</p>'}<p class="muted">Nach Ausrücken wird bei Rücknahme die Rückfahrt simuliert. Umverteilung nur zu höher priorisierten Einsätzen vor dem Eintreffen; Zwischenpositionen bleiben Schätzwerte.</p>`;
}
let scheduled=false;function schedule(){if(scheduled)return;scheduled=true;setTimeout(()=>{scheduled=false;buildPanels()},60)}
const observer=new MutationObserver(schedule);observer.observe(desk,{attributes:true,attributeFilter:['class'],childList:true,subtree:false});
setInterval(()=>{if(desk.classList.contains('open'))buildPanels()},1300);
desk.addEventListener('click',e=>{const b=e.target.closest('[data-coord]');if(!b)return;e.stopPropagation();const s=get();if(!s)return;ensure(s);let outcome;
 if(b.dataset.coord==='select-call'){desk.querySelector(`article[data-panel="call"] .item[data-id="${Number(b.dataset.id)}"]`)?.click();return}
 if(b.dataset.coord==='merge'){
  const src=Number(b.dataset.source),dst=Number(b.dataset.target);if(!confirm(`Fiktive Doppelmeldung #${src} dem Einsatz #${dst} zuordnen?`))return;
  outcome=merge(s,src,dst);
 }else if(b.dataset.coord==='recall'){
  if(!confirm(`${b.dataset.unit} vor dem Eintreffen zurücknehmen?`))return;outcome=recall(s,b.dataset.unit);
 }else if(b.dataset.coord==='transfer'){
  const newId=Number(desk.querySelector(`select[data-transfer="${b.dataset.unit}"]`)?.value);if(!Number.isFinite(newId))return;
  if(!confirm(`${b.dataset.unit} zu Einsatz #${newId} umverteilen?`))return;outcome=reassign(s,b.dataset.unit,newId);
 }
 if(outcome&&!outcome.ok){alert(outcome.error);return}lastSig='';window.LDRefresh?.();schedule();
},true);
const oldInit=window.LDLogic.init;
window.LDLogic.init=function(s,...args){const value=oldInit.call(this,s,...args);ensure(s);return value};
window.LDCoordination.refresh=buildPanels;
})();
