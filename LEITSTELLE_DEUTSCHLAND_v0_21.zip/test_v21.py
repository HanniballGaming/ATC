"""Offline Chromium integration checks for local 3D, speech/caller and geographic provenance.
Does not assert actual iPad hardware, official watch staffing or live routing.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re,sys
root=Path(__file__).parent
html=(root/'index.html').read_text()
shell=re.sub(r'<script[^>]*>.*?</script>','',html,flags=re.S)
shell=re.sub(r'<link\s+rel="stylesheet"[^>]+>','',shell)
blocks=re.findall(r'<script([^>]*)>(.*?)</script>',html,re.S)
results=[]
def test(desc,value):
    yes=bool(value);results.append(yes)
    print(('PASS' if yes else 'FAIL')+' | '+desc)
with sync_playwright() as p:
    b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security','--enable-webgl','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    page=b.new_page(viewport={'width':1200,'height':800},has_touch=True)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(shell)
    geo=(root/'regions.geojson').read_text()
    page.evaluate('''geo=>{let m=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>m.get(k)||null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k)}});window.fetch=async url=>{if(String(url).includes('regions.geojson'))return new Response(geo,{status:200});throw Error('No public data requests in offline test')};}''',geo)
    for attrs,code in blocks:
        m=re.search(r'src="([^"]+)',attrs)
        if m:
            if m.group(1).startswith('http'):continue
            code=(root/m.group(1).removeprefix('./')).read_text()
        page.add_script_tag(content=code)
    page.wait_for_timeout(300)
    page.locator('[data-action="new"]').click()
    page.wait_for_timeout(550)
    test('All v0.21 modules loaded',page.evaluate('!!LDDialogue21&&!!LDVoice21&&!!LDGeoAudit21&&!!LDShiftUI21&&!!LDRoom3D'))
    test('Local room canvas present',page.locator('.room canvas').count()>=1)
    renderer=page.evaluate("document.querySelector('.room canvas')?.dataset.renderBackend||'unknown'")
    print('Renderer:',renderer)
    test('Known renderer or software fallback',renderer in ('webgl','software'))
    test('Official ILS Augsburg county scope is listed',page.evaluate('LDGeoAudit21.official.augsburg.districts.length===5'))
    test('Geometry still has 18 simplified regions',page.evaluate('window.LDRegions?.featureCount===18'))
    test('All simulated units retain fictional-source disclaimer',page.evaluate("window.getGame().s.vehicles.every(v=>!v.dataSource||!v.dataSource.includes('amtlich verifiziert'))"))
    s_id=page.evaluate('getGame().s.incidents[0].id')
    page.evaluate('id=>LDOperations.accept(id)',s_id)
    questions=['Hören Sie mich noch?','Sind Sie allein?','Hören Sie mich noch?','Bleiben Sie am Telefon.','Können Sie die Adresse bestätigen?']
    replies=[page.evaluate('p=>LDLogic.converse(getGame().s,getGame().s.incidents[0].id,p,()=>{})',q) for q in questions]
    test('Contextual caller interactions answered',all(r and r.get('version')==21 for r in replies))
    test('Repeated caller check stable',replies[0]['answer']==replies[2]['answer'])
    test('Conversation transcript tracks all turns',page.evaluate('getGame().s.incidents[0].transcript.filter(x=>x.includes("ANRUFER")).length>=5'))
    test('Caller memory saved inside incident',page.evaluate('!!getGame().s.incidents[0].callerConversation21.asked.alone'))
    test('Existing multi-part caller questions still work',page.evaluate('''()=>{const i=getGame().s.incidents[0];return LDLogic.converse(getGame().s,i.id,'Wie alt ist die Person und atmet sie noch?',()=>{}).parts===2}'''))
    page.evaluate("window.openWorkstation('call')")
    test('Headset control on actual workstation',page.locator('#elsdesk [data-action="headset"]').count()==1)
    page.locator('#elsdesk [data-action="headset"]').click()
    test('Voice controls accessible',page.locator('#ld21-audio.open').count()==1)
    page.locator('#ld-voice-enabled').uncheck()
    test('Speech output can be disabled and persisted',page.evaluate('LDVoice21.settings.enabled===false&&localStorage.getItem("ld-voice-options-v21").includes("false")'))
    page.locator('#ld21-audio [data-voice="close"]').click()
    page.locator('#elsdesk [data-action="close"]').click()
    page.evaluate('window.LDGeoAudit21.open()')
    test('Geodata source panel opens',page.locator('#ld21-geodata.open').count()==1)
    test('Official source link rendered for Augsburg',page.locator('#ld21-geodata a[href*="augsburg.de"]').count()==1)
    test('Verification caveat visible', 'keine amtlichen' in page.locator('#ld21-geodata').inner_text().lower())
    test('No station coordinates invented',page.evaluate('LDGeoAudit21.nearest(getGame().s,getGame().s.incidents[0]).length===0'))
    page.evaluate('''()=>getGame().s.mappedStations=[{id:'node/7777',name:'Testwache (Mock)',kind:'RD',lat:48.371,lon:10.899,source:'OpenStreetMap',osm:'https://www.openstreetmap.org/node/7777'}]''')
    page.evaluate('window.LDGeoAudit21.render()')
    test('Nearest OSM sites shown when mapped',page.locator('#ld21-geodata .scroll .card').count()==1)
    page.locator('#ld21-geodata [data-geo="close"]').click()
    page.evaluate('window.LDShiftUI21.open()')
    test('Wall operations panel can open',page.locator('#ld16-panel.open').count()==1)
    page.locator('#ld16-panel [data-ld16="close"]').click()
    test('No uncaught JavaScript exception',not errors)
    if errors:print('Browser errors:',errors[:8])
    page.screenshot(path=str(root/'preview_v21.png'))
    b.close()
print(f'{sum(results)}/{len(results)} v0.21 integration tests passed')
if not all(results):sys.exit(1)
