# Veröffentlichung als iPad-Web-App

**Version 0.19** ist ein eigenständiges statisches Webprojekt (kein npm, keine Build-Umgebung notwendig). Bis eine öffentliche URL bereitsteht, ist die App **nicht** öffentlich veröffentlicht und auf einem iPad noch nicht als eigenständige Web-App installiert.

## GitHub Pages (kostenlose Option)

1. Ein GitHub-Repository für das Spiel erstellen und alle Projektdateien **in das Repository-Hauptverzeichnis** hochladen, einschließlich des versteckten Ordners `.github/workflows/`.
2. In den Repository-Einstellungen unter **Pages** als `Source` **GitHub Actions** auswählen.
3. Den Workflow **„LEITSTELLE DEUTSCHLAND – GitHub Pages“** ausführen lassen, ggf. unter `Actions` manuell starten.
4. In der Workflow-Ausgabe die URL der veröffentlichten GitHub-Pages-Website öffnen.
5. Auf dem iPad in Safari die URL öffnen, dann über **Teilen → Zum Home-Bildschirm** hinzufügen (in manchen iPadOS-Versionen außerdem „Als Web-App öffnen“).

> Dies ist eine Anleitung; der tatsächliche GitHub-Upload, die Bereitstellung und die Installation wurden hier **nicht** durchgeführt. Eine öffentliche Website ist erst nach erfolgreichem Deployment erreichbar.

## ChatGPT Sites

Die App ist als normale HTML/JavaScript-PWA angelegt. Eine Übernahme in ChatGPT Sites ist nur möglich, soweit Sites eigene JavaScript-Dateien, Service Worker und WebGL zulässt. **Dies ist hier nicht geprüft.** Bei Bedarf die gleiche Version über GitHub Pages nutzen.

## Offline und Online

- Offline nach einer erfolgreichen Installation: lokal gespeicherte Spielstände, 3D-Leitstellenraum, Regel-Gespräche, Einsatzverwaltung, deutsche Simulationsgebiete, vereinfachte Koordinatenkarte.
- Online: OpenStreetMap-Kartenkacheln, öffentliche Overpass-Wachstandorte, OSRM-Straßenrouten; alle sind externe Dienste, die ausfallen, drosseln oder Nutzungsgrenzen haben können.
- Sprachausgabe ist von browser-/geräteverfügbaren Stimmen abhängig. Spracherkennung ist **nicht garantiert**, kann den Mikrofonzugriff erfordern und je nach Browser auf Internetdienste zurückgreifen. Texteingabe bleibt immer möglich.

### Wichtige Grenzen

Das Spiel ist eine Simulation und **kein** BOS-Einsatzleitsystem. Die 18 Leitstellengrenzen sind geometrisch vereinfacht, die Fahrzeugbelegungen fiktiv und die Fahrzeit- und Personalmodelle nicht amtlich validiert. Kartierte OpenStreetMap-Wachen sind keine bestätigten Rettungsmittelstandorte oder Dienstpläne. Keine echten Notrufe, keine echten Funkverbindungen.

Offizielle Informationen zur Leitstellenzuständigkeit Augsburg: https://www.augsburg.de/buergerservice-rathaus/berufsfeuerwehr/integrierte-leitstelle/

Kartendaten: https://www.openstreetmap.org/copyright; Kartenkachel-Richtlinie: https://operations.osmfoundation.org/policies/tiles/; Natural Earth Lizenz (Public Domain): https://www.naturalearthdata.com/about/terms-of-use/
