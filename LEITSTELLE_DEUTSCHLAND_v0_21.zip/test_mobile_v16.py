from pathlib import Path
from playwright.sync_api import sync_playwright
import re,json
p=Path(__file__).parent
html=(p/'index.html').read_text()
shell=re.sub(r'<script[^>]*>.*?</script>','',html,flags=re.S)
shell=re.sub(r'<link\s+rel="stylesheet"[^>]+>','',shell)
blocks=re.findall(r'<script([^>]*)>(.*?)</script>',html,re.S)
with sync_playwright() as x:
 browser=x.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security'])
 page=browser.new_page(viewport={'width':768,'height':1024},device_scale_factor=1,is_mobile=True,has_touch=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(shell)
 geo=(p/'regions.geojson').read_text()
 page.evaluate("""geodata=>{let store=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,String(v)),clear:()=>store.clear(),removeItem:k=>store.delete(k)}});window.fetch=async url=>String(url).includes('regions.geojson')?new Response(geodata,{status:200}):Promise.reject(new Error('offline'))}""",geo)
 for attrs,txt in blocks:
  m=re.search(r'src="([^"]+)',attrs)
  if m:
   if m.group(1).startswith('https:'):continue
   txt=(p/m.group(1).replace('./','')).read_text()
  page.add_script_tag(content=txt)
 page.locator('#ld-preset').select_option('busy')
 page.locator('[data-action="new"]').click()
 page.wait_for_timeout(1500)
 assert page.evaluate("window.getGame().s.workload==='hoch'")
 assert page.locator('canvas[data-render-backend="software"]').count()>0
 page.evaluate('window.openWorkstation("resources")')
 page.wait_for_timeout(400)
 assert page.locator('#elsdesk.open').count()==1
 assert page.locator('#elsdesk .tabs').is_visible()
 assert page.locator('#elsdesk article[data-panel="resources"]').is_visible()
 assert not page.locator('#elsdesk article[data-panel="call"]').is_visible()
 page.locator('#elsdesk [data-monitor="call"]').first.click()
 assert page.locator('#elsdesk article[data-panel="call"]').is_visible()
 page.locator('#elsdesk [data-action="close"]').click()
 assert page.locator('#elsdesk.open').count()==0
 # Physically-modeled workplace can be resumed after opening overlays.
 page.locator('#app [data-action="mode"]').click()
 assert page.evaluate("window.getGame().mode==='free'")
 page.locator('#app [data-action="mode"]').click()
 assert page.evaluate("window.getGame().mode==='seat'")
 # Save and reload from localStorage, including scenario settings.
 page.locator('#app [data-action="menu"]').click()
 assert page.locator('[data-action="load"]').count()==1
 page.locator('[data-action="load"]').click()
 assert page.evaluate("window.getGame().s.shift.mode==='busy'")
 page.evaluate('window.openWorkstation("case")')
 page.wait_for_timeout(700)
 page.locator('[data-ld16-toggle]').click()
 assert page.locator('#ld16-panel.open').count()==1
 assert 'Übungswertung' in page.locator('#ld16-panel').inner_text()
 assert errors==[],errors
 page.screenshot(path=str(p/'preview_ipad_portrait_v16.png'))
 browser.close()
 print('10/10: portrait/touch/workstation/free movement/save/reload/shift – pass')
