@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel% equ 0 (
  start "" "http://localhost:8000/"
  py -m http.server 8000
  goto :eof
)
where python >nul 2>&1
if %errorlevel% equ 0 (
  start "" "http://localhost:8000/"
  python -m http.server 8000
  goto :eof
)
echo Python wurde nicht gefunden. Installiere Python oder lade die Dateien auf einen HTTPS-Webhost hoch.
pause
