/* Local, finite-state, fictional call simulator. No cloud AI, voice cloning or real 112 link. */
(()=>{'use strict';
const old=window.LDLogic.converse;
const number=v=>Number.isFinite(Number(v))?Number(v):0;
const stamp=m=>`${String(Math.floor(m/60)%24).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`;
function profile(i){if(i.callerProfile)return i.callerProfile;const names=['Lindenweg','Gartenstraße','Am Park','Bahnhofstraße','Feldweg','Wiesenstraße','Hauptstraße'];
 const sid=Math.max(1,number(i.id));const street=names[(sid*3+1)%names.length];
 i.callerProfile={fictional:true,street:`${street} ${(sid*7)%51+1}`,floor:['Erdgeschoss','1. Obergeschoss','2. Obergeschoss','3. Obergeschoss'][(sid*11)%4],door:['Hintereingang','Hauseingang an der Straße','Zufahrt rechts neben dem Gebäude'][(sid*5)%3],elapsed:['seit wenigen Minuten','seit ungefähr einer Viertelstunde','seit etwa einer halben Stunde'][(sid*7)%3],affected:/Massenanfall/.test(i.type)?'mindestens sechs':/Verkehrsunfall/.test(i.type)?'mindestens zwei':'eine',mood:['aufgeregt','angespannt','sehr unruhig'][(sid*13)%3]};return i.callerProfile;
}
function topic(q){const t=q.toLocaleLowerCase('de-DE').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ß/g,'ss');
 if(/ruckruf|telefonnummer|handynummer|anrufnummer/.test(t))return 'phone';
 if(/wer.*ruft|wie.*heissen|ihr name|von wem|melder/.test(t))return 'caller';
 if(/adresse|hausnummer|welche strasse|wo genau|einsatzort|wo ist|ortschaft|standort/.test(t))return 'place';
 if(/zugang|eingang|tür|tur|etage|stockwerk|wohnung|anfahrtsweg/.test(t))return 'access';
 if(/atmet|atmung|luft|atem|bewusstsein|ansprechbar|bewusstlos|wach/.test(t))return 'condition';
 if(/wieviele|wie viele|anzahl|personen|betroffene|verletzte/.test(t))return 'people';
 if(/seit wann|wie lange|beginn|dauer|wann angefangen/.test(t))return 'onset';
 if(/gefahr|rauch|flamme|brennt|feuer|strom|sicher|eingeklemmt/.test(t))return 'risk';
 if(/noch etwas|weitere information|hat sich.*verandert|neuigkeit|andert sich/.test(t))return 'update';
 return null;
}
function answer(i,kind){const p=profile(i),type=i.type||'',med=!/Brand|Feuer|Rauch|Verkehrsunfall|Baum|Wasser|Aufzug/.test(type);
 if(kind==='phone')return 'Eine Rückrufnummer habe ich gerade nicht zur Hand. Ich bleibe am Telefon.';
 if(kind==='caller')return `Mein Name ist ${i.caller||'unbekannt'}. Ich bin ziemlich ${p.mood}.`;
 if(kind==='place')return `Wir sind in ${i.city||'der gemeldeten Region'}, ${p.street}, fiktive Adresse für diese Übung.`;
 if(kind==='access')return `Sie kommen über den ${p.door}. Es ist im ${p.floor}.`;
 if(kind==='onset')return `Das passiert ${p.elapsed}.`;
 if(kind==='people')return `Nach dem, was ich sehen kann, sind ${p.affected} Person${p.affected==='eine'?'':'en'} betroffen. Mehr kann ich nicht sicher sagen.`;
 if(kind==='condition'){
  if(/Bewusstlose/.test(type))return 'Die Person reagiert nicht, und ich kann keine normale Atmung erkennen.';
  if(/Atemnot/.test(type))return 'Die Person ist ansprechbar, hat aber Schwierigkeiten beim Atmen.';
  if(/Krampfanfall/.test(type))return 'Die Person wirkt nach dem Anfall verwirrt. Ich kann sie nicht sicher einschätzen.';
  if(med)return 'Die betroffene Person ist wach, aber ihr Zustand beunruhigt mich.';
  return 'Ich kann den Zustand der Betroffenen im Moment nicht zuverlässig einschätzen.';
 }
 if(kind==='risk'){
  if(/Brand|Kohlenmonoxid/.test(type))return 'Ich kann Rauch oder eine Gefahr nicht ausschließen. Wir versuchen Abstand zu halten.';
  if(/Verkehrsunfall/.test(type))return 'Die Straße ist teilweise blockiert, und der Verkehr bewegt sich noch.';
  if(/Wasserschaden/.test(type))return 'Es gibt elektrische Anlagen im betroffenen Raum. Niemand geht mehr hinein.';
  return 'Ich sehe gerade keine zusätzliche Gefahr, bin aber nicht sicher.';
 }
 if(kind==='update'){const follow=(i.live?.followUps||[]).at(-1);return follow?follow.text.replace(/^#\d+ · /,''):'Es gibt noch keine neue Information. Bitte schicken Sie Hilfe.'}
 return null;
}
window.LDLogic.converse=function(s,id,question,logger){const i=s?.incidents?.find(x=>x.id===id);if(!i||i.callEnded||['Anruf','Unversorgt','Abgeschlossen'].includes(i.phase))return null;
 const asked=String(question||'').trim().slice(0,320);if(!asked)return null;
 const intent=topic(asked);if(!intent)return old.call(this,s,id,asked,logger);
 const response=answer(i,intent);if(!response)return old.call(this,s,id,asked,logger);
 const now=stamp(s.minute||0);
 i.transcript??=[];i.history??=[];i.documentation??={};i.transcript.push(`${now} · DISPONENT: ${asked}`,`${now} · ANRUFER: ${response}`);i.transcript=i.transcript.slice(-110);
 i.history.unshift({minute:s.minute,text:`Rückfrage (${intent}) beantwortet`});i.history=i.history.slice(0,80);
 if(intent==='place'&&!i.documentation.location)i.documentation.location=`${i.city}, ${profile(i).street} (fiktiv)`;
 if(intent==='access'&&!i.documentation.access)i.documentation.access=`${profile(i).floor}, ${profile(i).door} (fiktiv)`;
 if(intent==='people'&&!i.documentation.persons)i.documentation.persons=response;
 if(intent==='risk'&&!i.documentation.danger)i.documentation.danger=response;
 if(intent==='caller'&&!i.documentation.caller)i.documentation.caller=i.caller;
 i.freeQuestions=(i.freeQuestions||0)+1;
 logger?.(`#${i.id}: freie Frage (${intent}) im Gespräch protokolliert`);
 return {answer:response,matched:true,scripted:true,intent};
};
window.LDDialogue={profile,topic,answer};
})();
