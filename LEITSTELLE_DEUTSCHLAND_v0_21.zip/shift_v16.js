/* LEITSTELLE DEUTSCHLAND - fictional shift control, alerts and debrief v0.16.
 * Every threshold here is an exercise parameter, NOT a real response-time target,
 * medical algorithm or official Alarm- und Ausrückeordnung. */
(()=>{'use strict';
const clock=n=>`${String(Math.floor((n||0)/60)%24).padStart(2,'0')}:${String(Math.floor(n||0)%60).padStart(2,'0')}`;
const esc=v=>String(v??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const get=()=>window.LDOperations?.getState?.();
const MODES={normal:{label:'Regeldienst',workload:'normal',traffic:'normal',weather:'normal',delay:7},quiet:{label:'Ruhiger Dienst',workload:'ruhig',traffic:'gering',weather:'normal',delay:12},busy:{label:'Einsatzspitze',workload:'hoch',traffic:'stark',weather:'normal',delay:3},storm:{label:'Unwetterlage',workload:'hoch',traffic:'stark',weather:'schlecht',delay:3}};
function ensure(s){if(!s)return null;const mode=MODES[s.trainingPreset]?s.trainingPreset:'normal';if(!s.shift){s.shift={version:16,mode,start:s.minute||480,startDay:Math.floor((s.minute||0)/1440),alerts:[],flagged:{},createdAt:new Date().toISOString(),lastAudit:s.minute||480};const p=MODES[mode];s.workload=p.workload;s.weather=p.weather;s.traffic=p.traffic;s.nextCall=Math.min(s.nextCall||p.delay,p.delay);}
 s.shift.alerts??=[];s.shift.flagged??={};for(const i of s.incidents||[]){i.shiftMeta??={};if(i.assigned?.length&&!Number.isFinite(i.shiftMeta.firstDispatchAt))i.shiftMeta.firstDispatchAt=i.acceptedAt??i.createdAt??s.minute;}
 return s.shift;}
function percentile(array,p){if(!array.length)return null;const a=array.slice().sort((x,y)=>x-y);return a[Math.max(0,Math.ceil(p*a.length)-1)];}
function metrics(s){ensure(s);const all=s.incidents||[];const picked=all.filter(i=>Number.isFinite(i.acceptedAt));const answered=picked.map(i=>Math.max(0,i.acceptedAt-(i.createdAt??i.acceptedAt)));const dispatched=all.filter(i=>Number.isFinite(i.shiftMeta?.firstDispatchAt));const alarmDelay=dispatched.map(i=>Math.max(0,i.shiftMeta.firstDispatchAt-(i.acceptedAt??i.createdAt??s.minute)));
 const atScene=all.filter(i=>Number.isFinite(i.firstArrivedAt));const response=atScene.map(i=>Math.max(0,i.firstArrivedAt-(i.createdAt??i.firstArrivedAt)));
 const completed=all.filter(i=>i.phase==='Abgeschlossen');const open=all.filter(i=>i.phase!=='Abgeschlossen');const urgent=open.filter(i=>i.prio===1);const missing=open.filter(i=>i.phase!=='Anruf'&&i.need?.length>0);
 const free=(s.vehicles||[]).filter(v=>v.status==='frei');const documentation=picked.filter(i=>{const d=i.documentation||{};return String(d.location||'').trim()&&String(d.caller||'').trim()&&(i.qpos>0||(i.freeQuestions||0)>0||Object.keys(i.intake||{}).length>0)});
 // Deliberately independent from real legal response-time requirements.
 const grade=Math.max(0,Math.min(100,Math.round(70 + completed.length*2 + documentation.length - (s.missed||0)*8 - urgent.filter(i=>!i.assigned?.length).length*5 - answered.filter(x=>x>4).length*2 - missing.filter(i=>(i.age||0)>8).length*2)));
 return {total:all.length,answered:picked.length,completed:completed.length,open:open.length,urgent:urgent.length,missing:missing.length,free:free.length,capacity:s.vehicles?.length||0,acceptMedian:percentile(answered,.5),acceptP90:percentile(answered,.9),dispatchMedian:percentile(alarmDelay,.5),responseMedian:percentile(response,.5),responseP90:percentile(response,.9),documented:documentation.length,handledByPeers:all.filter(i=>i.owner&&i.owner!=='Eigenplatz').length,missed:s.missed||0,grade,elapsed:Math.max(0,s.minute-s.shift.start)};
}
function alerts(s){const m=metrics(s);const out=[];const push=(severity,key,txt,id=null)=>out.push({severity,key,text:txt,incident:id});
 for(const i of (s.incidents||[]).filter(i=>i.phase!=='Abgeschlossen')){
  if(i.phase==='Anruf'&&(i.age||0)>=3)push('hoch','call-'+i.id,`Notruf #${i.id}: seit ${i.age} Sim.-Minuten in der Warteschlange`,i.id);
  if(i.prio===1&&!['Anruf','Unversorgt'].includes(i.phase)&&!i.assigned?.length)push('hoch','p1-'+i.id,`Priorität 1: #${i.id} noch ohne zugeordnete Einsatzmittel`,i.id);
  if(i.need?.length&&i.phase!=='Anruf'&&i.phase!=='Unversorgt'&&(i.age||0)>=7)push('mittel','need-'+i.id,`#${i.id}: ${i.need.join(', ')} weiterhin offen`,i.id);
 }
 const radios=(s.vehicles||[]).filter(v=>v.radioRequest?.code==='9');if(radios.length)push('hoch','radio9',`${radios.length} dringliche(r) FunksprechWunsch/FunksprechWünsche (simuliert)`);
 if(m.free===0&&m.open>0)push('mittel','capacity','Keine freien eigenen Einsatzmittel; mögliche Unterstützung prüfen');
 if(m.elapsed>=12*60)push('info','handover','Schichtdauer über 12 Simulationsstunden: Übergabe empfohlen');
 return out.sort((a,b)=>({hoch:0,mittel:1,info:2}[a.severity]-{hoch:0,mittel:1,info:2}[b.severity]));
}
function audit(s){const sh=ensure(s);if(!s||s.minute===sh.lastAudit)return;sh.lastAudit=s.minute;const next=alerts(s);for(const a of next){const last=sh.flagged[a.key];if(last===undefined||s.minute-last>=15){sh.flagged[a.key]=s.minute;sh.alerts.unshift({minute:s.minute,...a});}}
 sh.alerts=sh.alerts.slice(0,100);for(const key of Object.keys(sh.flagged))if(sh.flagged[key]<s.minute-360)delete sh.flagged[key];}
function preset(s,mode){if(!s)return false;if(!MODES[mode])return false;ensure(s);s.trainingPreset=mode;s.shift.mode=mode;const p=MODES[mode];s.workload=p.workload;s.traffic=p.traffic;s.weather=p.weather;s.nextCall=Math.min(s.nextCall||p.delay,p.delay);s.logs.unshift(`${clock(s.minute)} · Simulationslage: ${p.label} aktiviert (fiktiv)`);window.LDOperations?.save?.();return true;}
function textReport(s){const m=metrics(s),lines=[
 'LEITSTELLE DEUTSCHLAND – SIMULATION / SCHICHTAUSWERTUNG',
 `Gebiet: ${window.getGame?.()?.areas?.[s.area]?.name||s.area} (vereinfachte Simulationsgrenze)`,
 `Modus: ${MODES[s.shift.mode]?.label||'Regeldienst'}`,`Simulationszeit: ${clock(s.shift.start)} bis ${clock(s.minute)} · ${m.elapsed} Simulationsminuten`,
 `Notrufe: ${m.total}; angenommen: ${m.answered}; abgeschlossen: ${m.completed}; offen: ${m.open}; versäumt: ${m.missed}`,
 `Eigenkräfte frei: ${m.free}/${m.capacity}; Kollegenübernahmen: ${m.handledByPeers}`,
 `Annahmezeit Median: ${m.acceptMedian??'–'} Min., P90: ${m.acceptP90??'–'} Min.`,
 `Annahme bis erste Alarmierung Median: ${m.dispatchMedian??'–'} Min.`,
 `Notrufeingang bis erste Ankunft Median: ${m.responseMedian??'–'} Min., P90: ${m.responseP90??'–'} Min.`,
 `Abfrage/Dokumentation (Übungsmodell): ${m.documented}/${m.answered} angenommenen Vorgängen`,
 `Übungswert (keine amtliche Leistungskennzahl): ${m.grade}/100`,
 '', 'EINSATZÜBERSICHT',
 ...s.incidents.slice(0,60).map(i=>`#${i.id} ${i.type} | ${i.city} | P${i.prio} | ${i.phase} | ${i.assigned?.join(',')||'keine Kräfte'}`),
 '', 'HINWEIS: Vollständig fiktive Patienten, Einsatzmittel und Szenarien. Kein Notrufsystem, keine validierte Hilfsfrist oder offizielle AAO. Im Notfall 112.'
 ];return lines.join('\n');}
function download(s){const content=textReport(s),blob=new Blob([content],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob);const link=document.createElement('a');link.download='LEITSTELLE_DEUTSCHLAND_Schichtbericht.txt';link.href=url;link.click();setTimeout(()=>URL.revokeObjectURL(url),1200);}
// Preserve legacy simulation and add a versioned, backwards-compatible module.
const baseInit=window.LDLogic.init,baseSpawn=window.LDLogic.spawn,baseDispatch=window.LDLogic.dispatch,baseTick=window.LDLogic.tick;
window.LDLogic.init=function(s,...args){const result=baseInit.call(this,s,...args);ensure(s);return result};
window.LDLogic.spawn=function(s,...args){const i=baseSpawn.call(this,s,...args);if(i){ensure(s);i.shiftMeta??={};i.shiftMeta.receivedAt=s.minute;}return i};
window.LDLogic.dispatch=function(s,id,...rest){const success=baseDispatch.call(this,s,id,...rest);if(success){const i=s.incidents.find(v=>v.id===id);if(i){i.shiftMeta??={};i.shiftMeta.firstDispatchAt??=s.minute;}}return success};
window.LDLogic.tick=function(s,...args){const result=baseTick.call(this,s,...args);if(s&&!s.paused)audit(s);return result};
window.LDRelease={ensure,metrics,alerts,textReport,preset,download,audit,MODES};

const style=document.createElement('style');style.textContent=`
#ld16-panel{position:fixed;z-index:10030;inset:4vh 5vw;background:#0d1a2a;color:#e5f3f7;border:1px solid #4e7f99;box-shadow:0 12px 60px #000b;border-radius:11px;display:none;flex-direction:column;font:13px system-ui}
#ld16-panel.open{display:flex}#ld16-panel h2{font-size:18px;margin:0}#ld16-panel h3{font-size:14px;margin:17px 0 8px}#ld16-panel .ld16-top{background:#173146;padding:14px;display:flex;align-items:center;gap:9px;flex-wrap:wrap;border-bottom:1px solid #3f6075}
#ld16-panel .ld16-content{flex:1;overflow:auto;padding:15px}#ld16-panel .ld16-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:9px}#ld16-panel .ld16-stat{background:#193349;border:1px solid #3e637b;border-radius:8px;padding:12px}#ld16-panel .ld16-stat b{display:block;font-size:24px}#ld16-panel .ld16-stat span{font-size:11px;color:#b6d3dc}#ld16-panel .ld16-urgent{border-left:3px solid #fb7874;padding:8px 12px;background:#3c2833;margin:6px 0}#ld16-panel .ld16-medium{border-left:3px solid #f4c77d;padding:8px 12px;background:#2c3543;margin:6px 0}#ld16-panel .ld16-info{border-left:3px solid #8bcfd4;padding:8px 12px;background:#243a4a;margin:6px 0}
#ld16-panel button{background:#255068;color:white;border:1px solid #77b0c6;padding:9px 12px;border-radius:5px}#ld16-panel .ld16-ops{display:flex;gap:8px;flex-wrap:wrap}#ld16-panel .ld16-muted{color:#b0ccd9;font-size:11px}#ld16-panel pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px ui-monospace,monospace;line-height:1.55;background:#071622;padding:12px;max-height:36vh;overflow:auto}
@media(max-width:740px){#ld16-panel{inset:0;border-radius:0}#ld16-panel .ld16-content{padding:11px}}
`;document.head.append(style);
const modal=document.createElement('section');modal.id='ld16-panel';modal.setAttribute('role','dialog');modal.setAttribute('aria-label','Simulationsschicht und Bericht');document.body.append(modal);
function draw(){const s=get();if(!s){modal.classList.remove('open');return;}const m=metrics(s),al=alerts(s);modal.innerHTML=`<div class="ld16-top"><h2>Schichtführung · ${esc(MODES[s.shift.mode]?.label||'Regeldienst')}</h2><span class="ld16-muted">SIM ${clock(s.minute)} · ausschließlich simulierte Daten</span><span style="flex:1"></span><button data-ld16="save">Bericht speichern</button><button data-ld16="close">✕ Zurück</button></div><div class="ld16-content"><div class="ld16-grid">${[
 ['☎ Notrufe',m.total],['✓ Abgeschlossen',m.completed],['⏱ Annahme Median',m.acceptMedian===null?'–':m.acceptMedian+' min'],['🚑 Erste Ankunft Median',m.responseMedian===null?'–':m.responseMedian+' min'],['🚨 Noch offen',m.open],['🟢 Kräfte frei',`${m.free}/${m.capacity}`],['🧑‍💻 Kollegenübernahmen',m.handledByPeers],['◉ Übungswertung',m.grade+'/100']
].map(([label,value])=>`<div class="ld16-stat"><b>${esc(value)}</b><span>${esc(label)}</span></div>`).join('')}</div>
<h3>Prioritäts- und Kapazitätswarnungen</h3>${al.length?al.slice(0,12).map(a=>`<div class="${a.severity==='hoch'?'ld16-urgent':a.severity==='mittel'?'ld16-medium':'ld16-info'}">${esc(a.text)}</div>`).join(''):'<p>Keine aktuellen Warnhinweise.</p>'}
<h3>Trainingssteuerung</h3><div class="ld16-ops"><button data-ld16="call">Neuen Übungsnotruf erzeugen</button><button data-ld16="traffic">Verkehrsbehinderung simulieren</button><button data-ld16="handover">Schichtbericht dokumentieren</button></div>
<h3>Schichtauswertung</h3><p class="ld16-muted">Diese Auswertung bewertet ausschließlich die eigene Übungssimulation. Sie entspricht weder einem Hilfsfristnachweis noch einem realen Qualitätsaudit.</p><pre>${esc(textReport(s))}</pre></div>`;}
function open(){if(!get())return;draw();modal.classList.add('open')}
function close(){modal.classList.remove('open')}
window.LDShiftUI21={open,close};
modal.addEventListener('click',e=>{const b=e.target.closest('[data-ld16]');if(!b)return;const s=get();if(!s)return;switch(b.dataset.ld16){case 'close':close();break;case 'save':download(s);break;case 'call':window.LDOperations?.spawn?.();break;case 'traffic':window.LDDirector?.createClosure?.(s,msg=>s.logs.unshift(msg));window.LDOperations?.save?.();break;case 'handover':s.handover??=[];s.handover.unshift({minute:s.minute,text:textReport(s).slice(0,2500)});window.LDOperations?.save?.();break}if(b.dataset.ld16!=='close')draw();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.classList.contains('open')){e.stopImmediatePropagation();close()}if(e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()==='l'){e.preventDefault();modal.classList.contains('open')?close():open()}});
// Add toolbar action after every underlying workbench redraw without replacing its inputs.
setInterval(()=>{const s=get(),root=document.getElementById('elsdesk');if(!root?.classList.contains('open')||!s)return;const bar=root.querySelector('.bar');if(bar&&!bar.querySelector('[data-ld16-toggle]')){const button=document.createElement('button');button.dataset.ld16Toggle='';button.textContent='▦ Schichtlage';button.title='Schichtauswertung und Übungsszenarien (Strg+Umschalt+L)';button.addEventListener('click',open);bar.insertBefore(button,bar.querySelector('[data-action="close"]'))}},650);
})();
