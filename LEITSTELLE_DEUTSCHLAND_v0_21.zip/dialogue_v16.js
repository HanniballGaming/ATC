/* Local extended callers – deliberately finite-state and offline.
   No cloud AI, no medical authorization and no real call recordings. */
(()=>{'use strict';
const previous=window.LDLogic.converse;
const timestamp=s=>`${String(Math.floor((s.minute||0)/60)%24).padStart(2,'0')}:${String((s.minute||0)%60).padStart(2,'0')}`;
function classify(input){const t=String(input).toLocaleLowerCase('de-DE').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ß/g,'ss');
 const tests=[
  ['callback',/ruckruf|telefonnummer|handy|erreichbar|zuruckrufen/],
  ['location',/hausnummer|adresse|strass[e ]|wo genau|welcher ort|einsatzort|wo befinden|standort/],
  ['entry',/eingang|zufahrt|zufahren|zugang|kommen.*rein|stockwerk|etage|aufzug|treppenhaus/],
  ['who',/wer (sind sie|spricht)|wie heissen|ihr name|von wem|melder/],
  ['relation',/kennen sie|verwandt|beziehung|angehorig|familie|nachbar/],
  ['incident',/was (ist passiert|ist los|ist geschehen)|was genau|konnen sie schildern|beschreiben sie|welcher notfall/],
  ['victims',/wie viele|wieviele|anzahl|betroffene|verletzte|menschen|personen/],
  ['responsive',/ansprechbar|bewusstlos|reagiert|wach|augen offen|bewegt sich/],
  ['breathing',/atmet|atmung|atem|luft|sauerstoff/],
  ['onset',/seit wann|wie lange|anfang|begonnen|wann begann|zeitpunkt/],
  ['safety',/sind sie sicher|selbst.*sicher|in sicherheit|gefahr fur sie|weitere gefahr/],
  ['hazard',/gefahr|rauch|flammen|feuer|elektrisch|strom|gas|eingeklemmt|flussigkeit/],
  ['change',/verandert|andert sich|neuigkeit|aktuell|neue information|status/],
  ['symptom',/symptom|beschwerde|schmerzen|blut|verletzung|schwindel|taubheit|sprache/],
  ['age',/wie alt|alter|geburtsjahr/],
  ['exact',/konnen sie wiederholen|noch einmal|wiederholen sie|nicht verstanden/],
  ['help',/haben sie hilfe|wer hilft|jemand vor ort|weitere helfer/],
  ['arrival',/wann kommt|wie lange brauchen|kommt schon|sind sie unterwegs/],
  ['instructions',/was soll ich tun|soll ich|konnen sie mir sagen|erste hilfe|anweisung/],
 ];
 for(const [k,re] of tests)if(re.test(t))return k;return null;
}
function persona(i){i.advancedCaller??={relative:['Nachbar','Angehörige','Kollegin','Passant'][i.id%4],age:((i.id*7)%6)*10+24,helper:i.id%3===0?'eine weitere Person':'niemand anderes',updateIndex:0,asked:{}};return i.advancedCaller}
function answer(s,i,intent){const type=i.type||'',p=persona(i),q=window.LDDialogue?.profile?.(i)||{};
 const medical=/Bewusstlose|Atemnot|Sturz|Brustschmerzen|Schlaganfall|Krampfanfall|Fahrrad|Hilflose/.test(type);
 if(intent==='relation')return `Ich bin ${p.relative}. Ich weiß leider nicht alle Einzelheiten.`;
 if(intent==='incident')return i.intro||`Hier ist etwas passiert: ${type}. Wir brauchen Hilfe.`;
 if(intent==='responsive')return /Bewusstlose/.test(type)?'Nein, die Person ist nicht ansprechbar.':/Krampfanfall/.test(type)?'Sie ist jetzt verwirrt und reagiert nur langsam.':/Brand|Feuer/.test(type)?'Ich kann nicht sagen, ob alle Personen ansprechbar sind.':'Ja, die Person reagiert, wirkt aber beeinträchtigt.';
 if(intent==='breathing')return /Bewusstlose/.test(type)?'Ich erkenne keine normale Atmung.':/Atemnot/.test(type)?'Die Atmung fällt der Person sehr schwer.':/Brand|Kohlenmonoxid/.test(type)?'Einige Menschen husten, aber ich kann den Zustand nicht sicher beurteilen.':'Die Person scheint zu atmen, ich kann das nicht genau einschätzen.';
 if(intent==='safety')return /Brand|Kohlenmonoxid|Gewerbe/.test(type)?'Ich bin auf Abstand gegangen, hier besteht möglicherweise noch eine Gefahr.':/Verkehrsunfall/.test(type)?'Wir stehen nicht mehr direkt auf der Fahrbahn.':'Im Moment bin ich an einem sicheren Platz.';
 if(intent==='symptom')return /Brustschmerzen/.test(type)?'Starke Schmerzen in der Brust und deutliche Schwäche.':/Schlaganfall/.test(type)?'Die Sprache ist plötzlich verändert und ein Arm bewegt sich nicht normal.':/Atemnot/.test(type)?'Die Luft bleibt weg, die Person kann kaum sprechen.':/Sturz|Fahrrad/.test(type)?'Es gibt Schmerzen nach dem Sturz beziehungsweise Unfall.':/Wohnungsbrand|Gewerbebrand/.test(type)?'Es gibt Rauch; weitere Verletzungen kann ich nicht ausschließen.':medical?'Ich sehe, dass es der Person nicht gut geht.':'Das kann ich nicht beurteilen.';
 if(intent==='age')return medical?`Ich schätze die betroffene Person auf etwa ${p.age} Jahre.`:'Das Alter der Betroffenen ist mir nicht bekannt.';
 if(intent==='help')return `Im Moment hilft ${p.helper}.`;
 if(intent==='arrival'){const has=(s.vehicles||[]).some(v=>v.incident===i.id);return has?'Ich sehe noch keine Einsatzkräfte. Wissen Sie, wann sie hier eintreffen?':'Bitte schicken Sie schnell jemanden; bisher ist noch niemand gekommen.';}
 if(intent==='instructions')return 'Ich bin sehr aufgeregt. Können Sie mich bitte Schritt für Schritt durch das Gespräch führen?';
 if(intent==='exact'){const old=[...(i.transcript||[])].reverse().find(t=>t.includes('ANRUFER:'));return old?old.split('ANRUFER:').slice(1).join('ANRUFER:').trim():'Ich brauche Hilfe an der gemeldeten Einsatzstelle.';}
 if(intent==='change'){const f=(i.live?.followUps||[]).at(-1);return f?f.text.replace(/^#\d+ · /,''):'Es gibt im Moment keine neue Information, soweit ich das sehen kann.';}
 return null;
}
window.LDLogic.converse=function(s,id,raw,logger){const i=s?.incidents?.find(x=>x.id===id);if(!i||i.callEnded||['Anruf','Unversorgt','Abgeschlossen'].includes(i.phase))return null;
 const text=String(raw||'').trim().slice(0,320);if(!text)return null;
 const intent=classify(text),response=answer(s,i,intent);
 if(!response)return previous.call(this,s,id,text,logger);
 const now=timestamp(s),p=persona(i);p.asked[intent]=(p.asked[intent]||0)+1;
 i.transcript??=[];i.history??=[];i.transcript.push(`${now} · DISPONENT: ${text}`,`${now} · ANRUFER: ${response}`);i.transcript=i.transcript.slice(-110);
 i.history.unshift({minute:s.minute,text:`Notruf-Rückfrage beantwortet: ${intent}`});i.history=i.history.slice(0,80);i.freeQuestions=(i.freeQuestions||0)+1;
 i.documentation??={};if(intent==='incident'&&!i.documentation.keyword)i.documentation.keyword=i.type;if(intent==='victims'&&!i.documentation.persons)i.documentation.persons=response;
 if(intent==='hazard'&&!i.documentation.danger)i.documentation.danger=response;
 logger?.(`#${id}: Rückfrage (${intent}) und Antwort protokolliert`);
 return {answer:response,matched:true,scripted:true,intent};
};
window.LDDialoguePlus={classify,persona,answer};
})();
