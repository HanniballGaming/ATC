# Technischer Testbericht · v0.21

## Prüfungen (17.11.2026)

| Suite | Ergebnis | Geltungsbereich |
|---|---:|---|
| `test_v16.py` | 28/28 | Grundsimulation, Schicht, ELS, Browserstart |
| `test_v17.py` | 13/13 | Gebiets-/Routenfunktionen |
| `test_v18.py` | 24/24 | Szenarien, Verlegung, Rückfahrt |
| `test_v19.py` | 21/21 | Funk, OSM-Abfrage mit Mock, Teamfunktionen |
| `test_v20.py` | 23/23 | Einsatzaktenprüfung, Mehrfachfragen |
| `test_mobile_v16.py` | 10/10 | Simulierte iPad-Hochkantansicht, Touch und Laden |
| `test_v21.py` | 21/21 | Gesprächsgedächtnis, Quellenfenster, Headset, vorhandener 3D-Fallback |

**140 automatisierte Prüfungen** wurden in diesen Suiten bestanden. Die Tests überlappen sich stellenweise und sind keine 140 voneinander unabhängigen Produkttests. Bei den meisten Tests wurden Netzwerkzugriffe abgefangen und die Daten durch kontrollierte Testdaten ersetzt.

Die folgenden weiteren Prüfungen sind getrennt durchzuführen:

- Echter iPadOS-Safari-Test mit Touch, Mikrofonberechtigung, Wiedergabe der verfügbaren Systemstimmen und installierter PWA.
- GPU-gestützter WebGL-Test auf realer iPad-Hardware. Im hier verfügbaren Headless-Chromium liefert `getContext('webgl')` keinen Kontext; der funktionierende **Softwarefallback** wurde getestet.
- Belastungs- und 24-Stunden-Dauertest der Simulation auf mehreren Gerätekonfigurationen.
- Messung/Kalibrierung realer Ausrück- und Fahrzeiten sowie verifizierte bundesweite Wachbelegung (öffentliche Daten hierfür nicht vollständig vorhanden).
- Live-Routing-Tests gegen regulär bereitgestellten Routingdienst, Nutzungsbedingungen/Quoten inklusive.
- Auslieferung auf einem öffentlichen HTTPS-Host und anschließende Installations-/Offline-Abnahme.

Technischer Stand: Keine bekannten JS-Ausnahmen während der automatisierten Kernprüfungen; keine Behauptung realer amtlicher Datenvollständigkeit. Alle Anwender werden auf die rein fiktive Einsatzsimulation hingewiesen.
