/* LEITSTELLE DEUTSCHLAND 0.20 – multi-part questions for fictional caller simulation.
 * Deterministic rules, no LLM, no real medical dispatch advice. */
(()=>{'use strict';
const api=window.LDLogic;if(!api?.converse)return;
const previous=api.converse;
function split(text){return String(text||'').trim().slice(0,360).split(/\s+und\s+(?=(?:wie|wo|was|wer|wann|seit|ist|sind|hat|haben|atmet|können|kann|gibt|welche|welcher)\b)/i).map(x=>x.trim()).filter(Boolean).slice(0,3)}
function known(piece){const p=piece.toLocaleLowerCase('de-DE').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ß/g,'ss');const q=window.LDComms?.questions?.some(x=>x.re.test(p));return q||!!window.LDDialoguePlus?.classify?.(piece)}
function converse(s,id,question,logger){const segments=split(question);
 if(segments.length<2||!segments.every(known))return previous.call(this,s,id,question,logger);
 const output=[];
 for(let n=0;n<segments.length;n++){
  const r=previous.call(this,s,id,segments[n],logger);
  if(!r?.answer)continue;
  output.push(r.answer);
 }
 if(output.length!==segments.length)return output.length?{answer:output.join(' '),matched:true,scripted:true,multi:true}:null;
 const i=s?.incidents?.find(x=>x.id===id);if(i){i.multiQuestions=(i.multiQuestions||0)+1;i.history??=[];i.history.unshift({minute:s.minute,text:`Mehrteilige Rückfrage beantwortet (${output.length} Teilfragen)`});}
 return {answer:output.join(' '),matched:true,scripted:true,multi:true,parts:output.length};
}
api.converse=converse;
window.LDDialogueMulti={split,known,converse};
})();
