/* Local first-party shell cache only; never cache or prefetch OSM raster tiles. */
const CACHE='leitstelle-v021-shell';
const APP=['./','./index.html','./world.js','./room_webgl_v16.js','./manifest.webmanifest','./icon.svg','./menu-cover.webp','./icon-180.png','./icon-192.png','./icon-512.png','./cities.js','./enhancements.js','./geodata.js','./routing.js','./realism.js','./workstation.js','./procedures_v12.js','./soundscape_v12.js','./colleagues.js','./regions.js','./regions.geojson','./engine_v11.js','./operations_v12.js','./workflow_v13.js','./gis_v13.js','./room_fallback_v13.js','./director_v14.js','./dialogue_v14.js','./dialogue_v16.js','./coordination_v15.js','./shift_v16.js','./coverage_v17.js','./exercise_v18.js','./communications_v19.js','./stations_v19.js','./dispatch_policy_v19.js','./colleague_control_v19.js','./immersive_v19.js','./quality_v20.js','./dialogue_v20.js','./dialogue_v21.js','./voice_v21.js','./geodata_v21.js'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(APP)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('leitstelle-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',event=>{
 const req=event.request,url=new URL(req.url);
 if(req.method!=='GET'||url.origin!==location.origin)return;
 if(req.mode==='navigate'){
   event.respondWith(fetch(req).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(req,copy))}return r}).catch(()=>caches.match(req).then(r=>r||caches.match('./index.html'))));
 }else{
   event.respondWith(caches.match(req).then(r=>r||fetch(req).then(result=>{if(result.ok){const copy=result.clone();caches.open(CACHE).then(c=>c.put(req,copy))}return result})));
 }
});
