# LEITSTELLE DEUTSCHLAND · v0.21

**Installierbare, spielbare iPad-/Desktop-Web-App (PWA), Entwicklungsversion.** Kein amtliches Einsatzleitsystem und keine Verbindung zum echten Notruf 112.

## Start und Installation

1. Das ZIP vollständig auf einen **HTTPS-Webhost** hochladen, etwa GitHub Pages. Keine `file://`-Installation: Service Worker funktionieren dafür nicht.
2. In Safari auf dem iPad öffnen; im Teilen-Menü **Zum Home-Bildschirm** wählen. Der Safari-Menütext unterscheidet sich je nach iPadOS-Version.
3. Beim ersten Öffnen benötigt die PWA Internet, um die lokalen Dateien herunterzuladen. Nach erfolgreicher Installation bleiben die **eigenen Spielfunktionen** offline verfügbar. OSM-Kartenkacheln, Overpass-Suche und OSRM-Routing sind online und werden nicht für Offline-Nutzung vorab heruntergeladen.
4. Im Hauptmenü eine der 18 geografisch abdeckenden, **stark vereinfachten Simulationsregionen** auswählen. Anrufannahme, Disposition, 3D-Leitstelle, Funk und Spielstände funktionieren auch ohne Online-Kartendienste.

## Neu in v0.21

- **3D-Kollegenarbeitsplätze:** Zusätzliche dynamische Bildschirmoberflächen für KI-Kollegen und ein Lagebildschirm an der hinteren Wand. Die statischen 3D-Möbel werden durch einen lokal implementierten WebGL-Renderer gezeichnet; bei fehlendem WebGL wird der perspektivische Software-Raum verwendet. Im WebGL-Raum sind die Arbeitsplätze der Kollegen mit Namenshinweisen versehen. Die bisherigen Monitor-, Telefon- und Funkinteraktionen bleiben erhalten.
- **Dialogsystem v0.21:** Kontextbezogene, lokal generierte Antworten auf neue, umgangssprachliche Fragen (z. B. Verbindung, weitere Helfer, Gebäudezugang, Verschlechterung, Orientierung, Wiederholung), mit beständigem Gesprächsgedächtnis je fiktivem Notruf. Bestehende Mehrfachfragen und Notrufprotokolle bleiben erhalten. **Dies sind erweiterte Offline-Regeln, keine generative KI**.
- **Headset und Sprache:** Eigene Bedienoberfläche für geräteinterne deutsche System-Sprachausgabe, Sprechtempo, Lautstärke und Stummschaltung. Die Spracheingabe verwendet, wenn verfügbar, die Sprachfunktion des Browsers und benötigt möglicherweise eigene Internetdienste und eine Mikrofonfreigabe. Nicht auf allen iPads verfügbar.
- **Geografische Nachweise:** Eigenes Fenster für Kartenherkunft, amtlich dokumentierte ILS-Augsburg-Zuständigkeit auf Kreisebene, OSM-Standorte und die luftlinienmäßig nächstgelegenen bereits geladenen Wachstandorte eines Falls. **Keine Aussage über tatsächliche Einsatzmittel, Dienstbesetzung oder Hilfsfristen**.
- **Stabilität:** Ein Fehler bei fehlenden Koordinaten in der schematischen Einsatzkarte wurde abgefangen. Die Spielstandstruktur und alle bisherigen Kernaktionen bleiben kompatibel.

## Wirklichkeitsgrad / Datenherkunft

- Die **18 Polygone** decken die vorhandene vereinfachte Deutschland-Geometrie ab. Sie bilden **nicht** die tatsächlichen Grenzen und Anzahl aller deutschen Leitstellen ab.
- Eine amtliche **Kreiszuständigkeit** für ILS Augsburg ist auf der offiziellen Website der Stadt Augsburg dokumentiert: Stadt Augsburg, Landkreis Augsburg, Aichach-Friedberg, Dillingen a. d. Donau und Donau-Ries. Quelle: <https://www.augsburg.de/buergerservice-rathaus/berufsfeuerwehr/integrierte-leitstelle/>. Das Polygon im Spiel bleibt vereinfacht.
- Rettungs- und Feuerwehrwachen können **auf Wunsch und begrenzt** über OpenStreetMap/Overpass geladen werden. Vorhandene OSM-Einträge sind nicht gleichbedeutend mit amtlich verifizierter Einsatzbereitschaft. Alle Fahrzeugzuordnungen im Spiel sind fiktiv.
- OSRM kann nur Strecken aus einem Straßennetz berechnen; dies beinhaltet **keine Live-Verkehrs- oder Einsatzfahrtberechtigung**. Falls OSRM nicht verfügbar ist, wird eine ersichtliche Näherung benutzt. Die öffentliche OSRM-Demo ist nicht für Produktionsmassenlast garantiert.
- Online-Kartenkacheln stammen aus externen Diensten. **Kein automatisches Massencaching/Paket-Offline-Kartenmaterial**, gemäß OSM Tile Usage Policy: <https://operations.osmfoundation.org/policies/tiles/>.
- Audio, KI-Anrufer und Funk sind Simulation. Es gibt weder echte Anrufe noch echte BOS-Funkkanäle.

## Steuerung

Im 3D-Raum per Maus oder Finger umsehen, Monitore/Telefon/Funk antippen, per Schalter aufstehen oder sich wieder setzen, und mit Tastatur oder Touch-Fußsteuerung gehen. Am Schreibtisch sind **Monitor 1: Notrufe**, **Monitor 2: Einsatzbearbeitung** und **Monitor 3: Disposition/Funk** auswählbar. Die neue **Headset/Stimme**-Schaltfläche befindet sich in der oberen Arbeitsplatzleiste; **Gebiet/Quellen** ist im Spiel rechts unten erreichbar. Die Monitore sind auch über Strg+1/2/3 umschaltbar.

## Tests und Einschränkungen

Die Quellcode-Syntax, die Integrationstests und die ZIP-Struktur werden mitgeliefert und im `TESTBERICHT.md` dokumentiert. Die Tests sind automatisierte **Chromium-Simulationen**. Ein physischer iPad-Safari-Test und eine echte GPU-WebGL-Abnahme sind noch **nicht** abgeschlossen. Bei fehlendem WebGL funktioniert die Softwareansicht. Eine direkte Veröffentlichung in ChatGPT Sites oder GitHub Pages ist noch nicht erfolgt.

**Release-Status:** v0.21 ist eine erweiterte Entwicklungsversion; nicht als vollständig amtlich authentische Version 1.0 zu verstehen.
