/* Original synthesized dispatcher ambience: no voice recordings or third-party audio. */
(()=>{'use strict';let ctx=null,enabled=false;const audio=()=>ctx??=new (window.AudioContext||window.webkitAudioContext)();
function tone(freq,duration,type='sine',volume=.023,delay=0){if(!enabled)return;try{const a=audio();a.resume();const t=a.currentTime+delay,o=a.createOscillator(),g=a.createGain();o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(volume,t+.015);g.gain.exponentialRampToValueAtTime(.0001,t+duration);o.connect(g).connect(a.destination);o.start(t);o.stop(t+duration+.015)}catch{}}
function ring(){tone(570,.14,'triangle',.028);tone(735,.15,'triangle',.024,.17);tone(570,.13,'triangle',.025,.35)}
function radio(){tone(1320,.08,'sine',.012);tone(1020,.12,'sine',.012,.09)}
function set(enabledNow){enabled=!!enabledNow;return enabled}
window.LDSound={get enabled(){return enabled},set,ring,radio};
})();
