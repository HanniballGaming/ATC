"""User-facing v0.19 integration. Mock OSM data without network and do not assert real station rosters."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re, json, sys
root=Path(__file__).parent
html=(root/'index.html').read_text()
shell=re.sub(r'<script[^>]*>.*?</script>','',html,flags=re.S)
shell=re.sub(r'<link\s+rel="stylesheet"[^>]+>','',shell)
blocks=re.findall(r'<script([^>]*)>(.*?)</script>',html,re.S)
passed=[]
def check(label,value):
    passed.append(bool(value)); print(('PASS ' if value else 'FAIL ')+label)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security','--enable-webgl','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
 page=b.new_page(viewport={'width':1100,'height':780},has_touch=True)
 errs=[];page.on('pageerror',lambda ex:errs.append(str(ex)))
 page.set_content(shell)
 geo=(root/'regions.geojson').read_text()
 page.evaluate('''geo=>{const data=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k)}});
window.fetch=async(req,opts)=>{const url=String(req);if(url.includes('regions.geojson'))return new Response(geo,{status:200});if(url.includes('overpass'))return new Response(JSON.stringify({elements:[{id:20031,type:'node',lat:48.37,lon:10.9,tags:{name:'Testwache RD (OSM-Mock)',emergency:'ambulance_station'}},{id:20032,type:'node',lat:48.38,lon:10.95,tags:{name:'Testwache FW (OSM-Mock)',amenity:'fire_station'}}]}),{status:200});throw Error('No network in test')};}''',geo)
 for attrs,code in blocks:
  m=re.search(r'src="([^"]+)',attrs)
  if m:
   if m.group(1).startswith('http'):continue
   code=(root/m.group(1).replace('./','')).read_text()
  page.add_script_tag(content=code)
 page.wait_for_timeout(400)
 page.locator('[data-action="new"]').click()
 page.wait_for_timeout(600)
 check('Spielstart und alle bisherigen Module',page.evaluate('!!window.getGame()?.s && !!window.LDComms && !!window.LDStationCatalog && !!window.LDDispatchModel'))
 page.evaluate('''()=>{const s=window.getGame().s,s0=s.incidents[0];if(s0.phase==='Anruf')window.LDOperations.accept(s0.id)}''')
 case=page.evaluate('window.getGame().s.incidents[0].id')
 answer=page.evaluate('''id=>window.LDComms.converse(window.getGame().s,id,'Wie alt ist die betroffene Person?',()=>{})''',case)
 again=page.evaluate('''id=>window.LDComms.converse(window.getGame().s,id,'Alter der Person?',()=>{})''',case)
 check('Freie Altersfrage konsistent',bool(answer and answer['answer']==again['answer']))
 check('Gespräch protokolliert',page.evaluate('id=>window.getGame().s.incidents.find(i=>i.id===id).transcript.some(x=>x.includes("DISPONENT"))',case))
 check('Ausrückmodell initialisiert',page.evaluate('''()=>window.getGame().s.vehicles.every(v=>['RD','BF','FF','sonstige'].includes(v.crewModel))'''))
 check('Ausrückzeit positiv',page.evaluate('''()=>window.LDDispatchModel.turnout(window.getGame().s,window.getGame().s.vehicles[0])>=1'''))
 # Communications overlay
 page.evaluate('window.LDComms.open()')
 check('Funkkonsole öffnet',page.locator('#ld-comms.open').count()==1)
 page.locator('#ld-comms-text').fill('Wo sind Sie? Bitte Standort mitteilen.')
 page.locator('#ld-comms [data-comm="sound"]').click()
 page.locator('#ld-comms [data-comm="send"]').click()
 check('Fahrzeug antwortet auf Statusfrage',page.locator('#ld-comms-answer').inner_text().count('Bereich')>0)
 check('Funkprotokoll persistent',page.evaluate('window.getGame().s.radioLog.length>0'))
 page.locator('#ld-comms [data-comm="close"]').click()
 check('Funkkonsole schließt',page.locator('#ld-comms.open').count()==0)
 # Stations via mocked OSM: 2 objects, no real verification claim
 page.evaluate('window.LDStationCatalog.open()')
 page.locator('[data-stations="center"]').click()
 page.wait_for_function('window.getGame().s.mappedStations?.length===2',timeout=20000)
 check('Wachen über standardisierte OSM-API importierbar',page.evaluate('window.getGame().s.mappedStations.length===2'))
 first=page.evaluate('window.getGame().s.vehicles.find(v=>v.type==="RTW"&&v.status==="frei").id')
 page.locator(f'#ld-stations [data-unit="{first}"]').select_option('node/20031')
 check('Fiktive Einheit erhält OSM-Koordinaten',page.evaluate('id=>{const v=window.getGame().s.vehicles.find(v=>v.id===id);return v.stationOSM==="node/20031"&&v.stationCoords.lat===48.37&&v.dataSource.includes("Fiktives Fahrzeug")}',first))
 check('Keine behauptete reale Fahrzeugbelegung',page.locator('#ld-stations .pane').inner_text().count('keine reale')>=1)
 page.locator('[data-stations="close"]').click()
 page.evaluate('window.LDOperations.save()')
 check('Neue Eigenschaften gespeichert',page.evaluate('localStorage.getItem("leitstelle-deutschland-save-v1").includes("stationOSM")'))
 # Runtime dynamic, some GPU implementations disallow real GL in sandbox
 ctx=page.evaluate('''()=>{const c=document.querySelector('.room canvas');return c?{backend:c.dataset.renderBackend,w:c.width,h:c.height}:null}''')
 print('Renderer observed:',ctx)
 check('3D-Ansicht oder Softwarefallback vorhanden',page.evaluate('!!document.querySelector(".room canvas")'))
 # Test team delegation across simulation minutes.
 new_id=page.evaluate('''()=>{const s=window.getGame().s;return window.LDLogic.spawn(s,window.getGame().areas,window.getGame().types,()=>{}).id}''')
 check('KI-Leitplatz-Übergabe wird protokolliert',page.evaluate('''id=>window.LDColleagueControl.delegate(window.getGame().s,id,'KI-Leitplatz 3')''',new_id))
 page.evaluate('''()=>{const s=window.getGame().s;s.paused=false;s.speed=1;s.nextCall=999999;for(let n=0;n<6;n++)window.LDLogic.tick(s,window.getGame().areas,window.getGame().types,()=>{})}''')
 check('KI-Kollege bearbeitet den Vorgang',page.evaluate('''id=>{const s=window.getGame().s,i=s.incidents.find(i=>i.id===id);return i.owner==='KI-Leitplatz 3'&&i.phase!=='Anruf'&&s.colleagueRoster.some(c=>c.id===i.owner)}''',new_id))
 check('Kollegenübersicht kann geöffnet werden',page.evaluate('''()=>{window.LDColleagueControl.open();return document.querySelector('#ld-colleague-control.open')!==null}'''))
 page.evaluate('window.LDColleagueControl.close()')
 # First-person-only view remains reversible and touchscreen-operable.
 check('Ego-Vollbild-Schalter vorhanden',page.locator('#ld-immersion').count()==1)
 page.locator('#ld-immersion').click()
 check('Ego-Vollbild blendet Übersicht aus',page.evaluate("document.body.classList.contains('ld-immersive')&&getComputedStyle(document.querySelector('.game>.layout')).display==='none'"))
 page.locator('#ld-immersion').click()
 check('Übersicht wiederherstellbar',page.evaluate("!document.body.classList.contains('ld-immersive')&&getComputedStyle(document.querySelector('.game>.layout')).display!=='none'"))
 check('Keine JS-Ausnahme',not errs)
 if errs:print('Errors:',errs)
 b.close()
print(f'{sum(passed)}/{len(passed)} checks passed')
if not all(passed):sys.exit(1)
