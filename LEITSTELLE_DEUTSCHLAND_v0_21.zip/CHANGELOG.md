# Changelog

## 0.21 · 17.11.2026

- Zusätzliche dynamische KI-Kollegenmonitore und aktiver Lagebildschirm im WebGL-Raum.
- Physische Kollegenarbeitsplätze mit interaktiver Statusanzeige im 3D-Raum.
- Erweiterte natürliche Offline-Fragen an fiktive Anrufer mit Gesprächsgedächtnis.
- Einstellbare Headset-Sprachausgabe und Laufzeit-Unterstützungsprüfung.
- Neues Geodaten- und Quellenfenster mit offizieller Kreiszuständigkeit ILS Augsburg.
- Abfrage der nächstgelegenen geladenen OSM-Wachstandorte pro Einsatzakte.
- Verhindert ungültige SVG-Positionswerte bei Fällen ohne schematische Koordinaten.
- Service-Worker-Cache aktualisiert.
