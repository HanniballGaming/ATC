/* Dependency-free offline 3D-perspective control room renderer.
   Low-detail software rendering for browsers without online WebGL dependencies.
   The primary Three.js WebGL room takes priority whenever available. */
(()=>{'use strict';
let room=null,canvas=null,ctx=null,frameId=0,lastPaint=0,cam={x:0,y:1.47,z:5.7,yaw:0,pitch:-.04},moving=false,drag=null,hitTargets=[],backend=null;
const objects=[];
const C={wall:'#2c3c4b',wallSide:'#263544',floor:'#47525b',floorLine:'#62707a',ceiling:'#273746',desk:'#697684',metal:'#526274',screen:'#081d2b',body:'#274d62',skin:'#bf967a',chair:'#212c36',keyboard:'#2a3b49',plant:'#477768'};
const user=()=>window.getGame?.();
function addBox(x,y,z,w,h,d,color,tag=null){objects.push({t:'box',x,y,z,w,h,d,color,tag})}
function addPlane(x,y,z,w,h,color,tag=null){objects.push({t:'plane',x,y,z,w,h,color,tag})}
function addPerson(x,z,index){addBox(x,1.06,z+.84,.53,.62,.29,['#244859','#345266','#344958'][index%3]);addBox(x-.33,.98,z+.74,.13,.42,.22,'#315468');addBox(x+.33,.98,z+.74,.13,.42,.22,'#315468');objects.push({t:'head',x,y:1.55,z:z+.83,r:.22,color:['#ba8a6c','#c79779','#ad806a'][index%3],tag:'colleague'});addBox(x,.48,z+1.16,.76,.12,.6,C.chair);addBox(x,.84,z+1.46,.74,.65,.12,C.chair)}
function addDesk(x,z,own,index){addBox(x,.77,z,3.75,.12,1.72,C.desk);for(const dx of [-1.62,1.62])for(const dz of [-.63,.63])addBox(x+dx,.4,z+dz,.08,.78,.08,C.metal);
for(let k=-1;k<=1;k++){const px=x+k*1.17;addBox(px,1.43,z-.49,1.1,.8,.1,'#0b1621');addBox(px,1.05,z-.49,.1,.5,.07,C.metal);addPlane(px,1.43,z-.421,1.03,.70,own?'#102c3c':'#163647',own?(['call','case','resources'][k+1]):null)}
addBox(x,.87,z+.4,.89,.055,.32,C.keyboard);addBox(x+.7,.88,z+.43,.11,.04,.11,'#1c2b38');addBox(x+1.32,.92,z+.45,.24,.14,.32,'#15222e',own?'call':null);addBox(x-1.35,.91,z+.46,.26,.05,.18,'#1a3948',own?'resources':null);
if(!own)addPerson(x,z,index);else{addBox(x,.45,z+1.12,.8,.14,.65,C.chair);addBox(x,.8,z+1.44,.75,.64,.11,C.chair)}}
function initScene(){objects.length=0;addBox(0,-.055,0,22,.12,20,C.floor);addPlane(0,2.18,-9.78,22,4.25,C.wall);addBox(-10.95,2.04,0,.1,4.05,20,C.wallSide);addBox(10.95,2.04,0,.1,4.05,20,C.wallSide); // side walls
for(let i=0;i<9;i++){const z=-8+i*2;addBox(0,4.0,z,21,.05,.035,'#8393a2')}
for(const x of [-7,0,7])for(const z of [-6,0,6])addBox(x,3.94,z,2.6,.08,.68,'#c7d8de');
// Room divider, briefing display, door and plants.
addPlane(0,2.52,-9.60,4.5,1.74,'#0d2637');addPlane(0,2.52,-9.55,4.12,1.5,'#22556a');addPlane(-7.05,1.5,-9.59,1.2,2.72,'#607384');
for(let row=0;row<2;row++)for(let col=0;col<3;col++)addDesk((col-1)*6,row===0?-6:-2,false,col+row*3);
addDesk(0,3.5,true,0);
for(const x of [-9.5,9.5])for(const z of [-5,2]){addBox(x,.35,z,.5,.7,.5,'#5d666a');addBox(x,.98,z,.1,.9,.1,'#396c58');for(let k=-1;k<=1;k++)addBox(x+.13*k,1.3,z,.36,.55,.21,'#426c52')}
}
function transform(x,y,z){const dx=x-cam.x,dz=z-cam.z,dy=y-cam.y,co=Math.cos(cam.yaw),si=Math.sin(cam.yaw);const xx=dx*co-dz*si,forward=-(dx*si+dz*co),pco=Math.cos(cam.pitch),psi=Math.sin(cam.pitch);return {x:xx,y:dy*pco-forward*psi,z:dy*psi+forward*pco}}
function projection(x,y,z,W,H){const p=transform(x,y,z);if(p.z<=.11)return null;const f=Math.min(W*.77,H*1.7);return {x:W/2+p.x/p.z*f,y:H*.52-p.y/p.z*f,z:p.z}}
function colors(hex,f){const h=hex.slice(1),r=parseInt(h.slice(0,2),16),g=parseInt(h.slice(2,4),16),b=parseInt(h.slice(4,6),16);return 'rgb('+[r,g,b].map(v=>Math.min(255,Math.max(0,Math.round(v*f)))).join(',')+')'}
function faceCorners(o,type){const {x,y,z,w,h,d}=o,hw=w/2,hh=h/2,hd=d/2;const q=(a,b,c,e)=>[[x+a*hw,y+b*hh,z+c*hd],[x+e[0]*hw,y+e[1]*hh,z+e[2]*hd]];const L=x-hw,R=x+hw,U=y+hh,D=y-hh,N=z+hd,F=z-hd;return [
{pts:[[L,D,N],[R,D,N],[R,U,N],[L,U,N]],f:1.0,face:'front'},
{pts:[[R,D,F],[L,D,F],[L,U,F],[R,U,F]],f:.63},
{pts:[[L,D,F],[L,D,N],[L,U,N],[L,U,F]],f:.72},
{pts:[[R,D,N],[R,D,F],[R,U,F],[R,U,N]],f:.83},
{pts:[[L,U,N],[R,U,N],[R,U,F],[L,U,F]],f:1.12},
{pts:[[L,D,F],[R,D,F],[R,D,N],[L,D,N]],f:.61}
]}
function buildFaces(W,H){const faces=[];for(const o of objects){if(o.t==='head'){const pt=projection(o.x,o.y,o.z,W,H),r=projection(o.x+o.r,o.y,o.z,W,H);if(pt&&r)faces.push({type:'head',p:pt,r:Math.max(3,Math.abs(r.x-pt.x)),depth:pt.z,color:o.color,tag:o.tag});continue}
if(o.t==='plane'){const x=o.x,w=o.w/2,y=o.y,h=o.h/2,z=o.z;const corners=[[x-w,y-h,z],[x+w,y-h,z],[x+w,y+h,z],[x-w,y+h,z]];const ps=corners.map(c=>projection(...c,W,H));if(ps.every(Boolean))faces.push({type:'quad',ps,depth:ps.reduce((a,p)=>a+p.z,0)/4,color:o.color,tag:o.tag,front:true});continue}
for(const side of faceCorners(o)){const ps=side.pts.map(c=>projection(...c,W,H));if(ps.every(Boolean))faces.push({type:'quad',ps,depth:ps.reduce((a,p)=>a+p.z,0)/4,color:colors(o.color,side.f),tag:o.tag&&side.face==='front'?o.tag:null,front:side.face==='front'});}}
return faces.sort((a,b)=>b.depth-a.depth)}
function draw(){const g=user(),el=document.querySelector('.room');if(!g?.s||!el){if(canvas)canvas.remove();canvas=null;room=null;return}
if(el.querySelector('canvas[data-render-backend="webgl"]')){if(canvas)canvas.remove();canvas=null;room=null;return}
if(room!==el){if(canvas)canvas.remove();room=el;canvas=document.createElement('canvas');canvas.dataset.renderBackend='software';canvas.setAttribute('aria-label','Offline-3D-Perspektive des Leitstellenraums');canvas.style.cssText='position:absolute;inset:0;width:100%;height:100%;touch-action:none;z-index:1;cursor:crosshair';el.prepend(canvas);ctx=canvas.getContext('2d',{alpha:false});attachControls();initScene()}
if(!ctx)return;const W=Math.max(1,el.clientWidth),H=Math.max(1,el.clientHeight);const scale=Math.min(window.devicePixelRatio||1,1.2);if(canvas.width!==Math.round(W*scale)||canvas.height!==Math.round(H*scale)){canvas.width=Math.round(W*scale);canvas.height=Math.round(H*scale)}ctx.setTransform(scale,0,0,scale,0,0);
const hour=(g.s.minute/60)%24,night=hour>=21||hour<6;const bg=ctx.createLinearGradient(0,0,0,H);bg.addColorStop(0,night?'#111e2a':'#263d4b');bg.addColorStop(.73,night?'#36434c':'#425766');bg.addColorStop(1,'#172833');ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
hitTargets=[];const faces=buildFaces(W,H);for(const f of faces){if(f.type==='head'){ctx.beginPath();ctx.ellipse(f.p.x,f.p.y,f.r,f.r*1.13,0,0,Math.PI*2);ctx.fillStyle=f.color;ctx.fill();ctx.strokeStyle='#d8bda0';ctx.lineWidth=1;ctx.stroke();hitTargets.push({tag:'colleague',x:f.p.x-f.r,y:f.p.y-f.r,w:f.r*2,h:f.r*2,depth:f.depth});continue}
ctx.beginPath();f.ps.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=f.color;ctx.fill();ctx.strokeStyle='#1a2834';ctx.lineWidth=.6;ctx.stroke();
if(f.tag){const cx=f.ps.reduce((a,p)=>a+p.x,0)/4,cy=f.ps.reduce((a,p)=>a+p.y,0)/4,bw=Math.abs(f.ps[1].x-f.ps[0].x),bh=Math.abs(f.ps[3].y-f.ps[0].y);
let txt=f.tag==='call'?'112 | NOTRUFE':f.tag==='case'?'EINSATZLEITSYSTEM':'FUNK | DISPOSITION';ctx.fillStyle='#82f4ef';ctx.font=`bold ${Math.min(18,Math.max(8,bw/12))}px monospace`;ctx.textAlign='center';ctx.fillText(txt,cx,cy-bh*.14);
const value=f.tag==='call'?`${g.s.incidents.filter(i=>i.phase==='Anruf').length} WARTEND`:f.tag==='case'?`${g.s.incidents.filter(i=>i.phase!=='Abgeschlossen').length} VORGÄNGE`:`${g.s.vehicles.filter(v=>v.status==='frei').length} FREI`;
ctx.fillStyle='#d7f6fb';ctx.font=`${Math.min(16,Math.max(8,bw/16))}px monospace`;ctx.fillText(value,cx,cy+bh*.12);hitTargets.push({tag:f.tag,x:Math.min(...f.ps.map(p=>p.x)),y:Math.min(...f.ps.map(p=>p.y)),w:Math.max(...f.ps.map(p=>p.x))-Math.min(...f.ps.map(p=>p.x)),h:Math.max(...f.ps.map(p=>p.y))-Math.min(...f.ps.map(p=>p.y)),depth:f.depth});}}
ctx.textAlign='left';ctx.fillStyle='#d3e5ee';ctx.font='bold 13px system-ui';ctx.fillText(`LEITSTELLE DEUTSCHLAND  ·  ${g.areas[g.s.area]?.name||'Simulation'}`,13,23);
ctx.fillStyle='#acc5d2';ctx.font='11px system-ui';ctx.fillText('OFFLINE-3D · Monitore antippen · Wischen: umsehen',13,H-13);
}
function attachControls(){canvas.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,moved:false};canvas.setPointerCapture(e.pointerId)});
canvas.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.moved ||=Math.abs(e.clientX-drag.startX)+Math.abs(e.clientY-drag.startY)>9;cam.yaw-=dx*.004;cam.pitch=Math.max(-.9,Math.min(.8,cam.pitch-dy*.004));drag.x=e.clientX;drag.y=e.clientY});
canvas.addEventListener('pointerup',e=>{if(!drag)return;const click=!drag.moved;drag=null;if(!click)return;const rect=canvas.getBoundingClientRect(),x=e.clientX-rect.left,y=e.clientY-rect.top;const hits=hitTargets.filter(p=>x>=p.x&&x<=p.x+p.w&&y>=p.y&&y<=p.y+p.h).sort((a,b)=>a.depth-b.depth);const h=hits[0];if(h?.tag==='colleague')document.getElementById('colleague-toggle')?.click();else if(h?.tag)window.openWorkstation?.(h.tag)})}
function isClear(x,z){if(Math.abs(x)>9.4||Math.abs(z)>8.7)return false;return ![[0,3.5],[-6,-6],[0,-6],[6,-6],[-6,-2],[0,-2],[6,-2]].some(([a,b])=>Math.abs(x-a)<2.2&&Math.abs(z-b)<1.15)}
function move(d){const x=cam.x-Math.sin(cam.yaw)*d,z=cam.z-Math.cos(cam.yaw)*d;if(isClear(x,cam.z))cam.x=x;if(isClear(cam.x,z))cam.z=z}
function tick(t){frameId=requestAnimationFrame(tick);if(t-lastPaint<110)return;lastPaint=t;const g=user();if(!g?.s)return draw();if(window.LDRoom3D&&!window.LDRoom3D.isSoftware){if(canvas){canvas.remove();canvas=null;room=null}return}
window.LDRoom3D=backend;const isFree=g.mode==='free';if(!isFree){if(moving){cam.x=0;cam.z=5.7;cam.yaw=0;cam.pitch=-.04}cam.y=1.47}else cam.y=1.7;moving=isFree;if(!document.getElementById('elsdesk')?.classList.contains('open')&&!document.getElementById('ld-gis')?.classList.contains('open'))draw()}
backend={isSoftware:true,turn:(degree)=>{cam.yaw+=degree*Math.PI/180},nudge:(d)=>move(d*.46),position:()=>({fx:cam.x,fz:cam.z,yaw:cam.yaw})};
requestAnimationFrame(tick);
})();
