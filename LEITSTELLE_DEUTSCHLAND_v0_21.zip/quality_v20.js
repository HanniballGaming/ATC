/* LEITSTELLE DEUTSCHLAND 0.20 – operator quality/dispatch checks.
 * Original fictional training rules: NOT official protocols, medical advice or AAO.
 * Does not delay or prevent time-critical alarmierung.
 */
(()=>{'use strict';
const S=()=>window.LDOperations?.getState?.();
const esc=x=>String(x??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const timestamp=m=>`${String(Math.floor((Number(m)||0)/60)%24).padStart(2,'0')}:${String(Math.floor(Number(m)||0)%60).padStart(2,'0')}`;
const safeName=i=>`#${Number(i?.id)||0}`;
const cases=s=>(s?.incidents||[]).filter(i=>i.phase!=='Abgeschlossen');
function setup(i){if(!i)return null;i.qa??={version:20,confirmed:{},notes:[],reviewedAt:null};i.qa.confirmed??={};i.qa.notes??=[];return i.qa}
function doci(i){i.documentation??={caller:i.caller||'',location:i.location||i.city||'',phone:'',access:'',persons:'',danger:'',keyword:i.type||'',priority:String(i.prio||2),notes:''};return i.documentation}
function checks(s,i){if(!i)return {items:[],warnings:[],complete:0,required:0,percent:0};
 const d=doci(i),q=setup(i),isCall=['Anruf','Unversorgt'].includes(i.phase),started=Number.isFinite(i.acceptedAt),isDone=i.phase==='Abgeschlossen';
 const items=[
  {key:'place',label:'Einsatzort plausibilisiert',detail:'Ort, Straße/Hausnummer oder Zufahrt mit dem Anrufer abgleichen',done:!!q.confirmed.place&&!!String(d.location||'').trim(),field:'location'},
  {key:'persons',label:'Betroffene erfasst',detail:'Anzahl und Zustand der Betroffenen dokumentieren',done:!!q.confirmed.persons&&!!String(d.persons||'').trim(),field:'persons'},
  {key:'hazards',label:'Gefahrenlage erfragt',detail:'Mögliche Gefahren oder „keine bekannt“ dokumentieren',done:!!q.confirmed.hazards&&!!String(d.danger||'').trim(),field:'danger'},
  {key:'access',label:'Anfahrt und Zugang geklärt',detail:'Zufahrt, Stockwerk oder Treffpunkt, soweit bekannt',done:!!q.confirmed.access&&!!String(d.access||'').trim(),field:'access'},
  {key:'callback',label:'Rückrufmöglichkeit gesichert',detail:'Rückrufnummer ergänzen, falls verfügbar',done:!!q.confirmed.callback&&!!String(d.phone||'').trim(),field:'phone'}
 ];
 const assigned=(i.assigned||[]).length,need=i.need||[],elapsed=Math.max(0,(s?.minute||0)-(i.createdAt??s?.minute??0));
 const warnings=[];
 if(isCall)warnings.push({key:'waiting',level:'hoch',text:`Notruf wartet auf Annahme (${elapsed} Sim.-Min.)`});
 if(!isCall&&!isDone&&i.prio===1&&assigned===0)warnings.push({key:'critical',level:'hoch',text:'Zeitkritischer Vorgang: noch kein Einsatzmittel alarmiert'});
 if(!isDone&&!isCall&&need.length)warnings.push({key:'needs',level:elapsed>=7?'hoch':'mittel',text:`Noch offene Einsatzmittel: ${need.join(', ')}`});
 if(!isDone&&!isCall&&i.prio===1&&!q.confirmed.place)warnings.push({key:'place',level:'mittel',text:'Einsatzort ist noch nicht als überprüft dokumentiert'});
 if(started&&!isDone&&s?.vehicles?.length&&need.length){
  const unmet=[...new Set(need)].filter(t=>!s.vehicles.some(v=>v.type===t&&v.status==='frei'));
  if(unmet.length)warnings.push({key:'coverage',level:'hoch',text:`Keine freien eigenen Mittel für ${unmet.join(', ')}; Unterstützung prüfen`});
 }
 const complete=items.filter(x=>x.done).length;
 return {items,warnings,complete,required:items.length,percent:Math.round(complete/items.length*100),isCall,elapsed};
}
function audit(s,i,text){const q=setup(i);const entry={minute:s.minute,text:String(text).slice(0,160)};q.notes.unshift(entry);q.notes=q.notes.slice(0,60);i.history??=[];i.history.unshift({minute:s.minute,text:`Leitplatzprüfung: ${entry.text}`});i.history=i.history.slice(0,100);s.logs??=[];s.logs.unshift(`[${timestamp(s.minute)}] QK #${i.id}: ${entry.text}`);s.logs=s.logs.slice(0,100);}
function confirm(s,id,key,on=true){const i=s?.incidents?.find(x=>x.id===Number(id));if(!i||i.phase==='Abgeschlossen')return {ok:false,reason:'Vorgang nicht mehr bearbeitbar'};
 const map={place:'location',persons:'persons',hazards:'danger',access:'access',callback:'phone'};
 if(!Object.hasOwn(map,key))return {ok:false,reason:'Unbekanntes Prüfmerkmal'};
 const doc=doci(i),q=setup(i),data=String(doc[map[key]]||'').trim();
 if(on&&!data)return {ok:false,reason:`Bitte zuerst das Feld „${map[key]}“ am Einsatzmonitor ausfüllen`};
 q.confirmed[key]=!!on;
 audit(s,i,`${key}: ${on?'durch Disponent bestätigt':'Bestätigung zurückgenommen'}`);
 window.LDOperations?.save?.();return {ok:true};
}
function review(s,id){const i=s?.incidents?.find(x=>x.id===Number(id));if(!i)return false;const c=checks(s,i);i.qa.reviewedAt=s.minute;audit(s,i,`Bearbeitungsprüfung ${c.complete}/${c.required}; ${c.warnings.length} aktuelle Hinweise`);window.LDOperations?.save?.();return true}
const style=document.createElement('style');style.textContent=`
#ld20-qa{position:fixed;inset:0;display:none;background:#030a14ed;z-index:12030;padding:clamp(8px,2vw,28px);font:13px system-ui;color:#e7f4f9;overflow:auto}#ld20-qa.open{display:block}
#ld20-qa .window{max-width:1000px;margin:auto;border:1px solid #548395;border-radius:12px;background:#11283b;box-shadow:0 14px 52px #0009;overflow:hidden}#ld20-qa .head{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:15px 18px;background:#17374b;border-bottom:1px solid #45667b}#ld20-qa .body{padding:16px}#ld20-qa h2{font-size:19px;margin:0}#ld20-qa .muted{font-size:12px;color:#adcad8}#ld20-qa .grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:15px}#ld20-qa .item{display:flex;align-items:center;gap:8px;justify-content:space-between;padding:9px;border-bottom:1px solid #36546a}#ld20-qa .item span{flex:1}#ld20-qa button,#ld20-qa select{background:#1e526a;border:1px solid #71a5b4;border-radius:6px;padding:9px;color:#fff;min-height:40px}#ld20-qa .complete{color:#8cdec3}#ld20-qa .warning{border-left:3px solid #ffb56f;background:#2b3241;padding:9px;margin:6px 0}#ld20-qa .danger{border-color:#f17e7e;background:#392a37}#ld20-qa .log{max-height:230px;overflow:auto;background:#0a1d2a;border-radius:7px;padding:9px;white-space:pre-wrap;font:12px ui-monospace,monospace}#ld20-qa .pct{height:9px;border-radius:99px;background:#254157;overflow:hidden}#ld20-qa .pct>div{height:100%;background:#65c8ba}#ld20-review{padding:10px;margin:10px 0;border-left:3px solid #72bcc7;background:#193749}#ld20-review .status{font-size:11px;color:#d4e8ef}#ld20-review button{margin-top:7px;min-height:40px}@media(max-width:700px){#ld20-qa .grid{grid-template-columns:1fr}#ld20-qa .body{padding:9px}#ld20-qa .head{padding:10px}#ld20-qa .item{align-items:flex-start;flex-wrap:wrap}}
`;document.head.append(style);
const dlg=document.createElement('section');dlg.id='ld20-qa';dlg.setAttribute('role','dialog');dlg.setAttribute('aria-modal','true');dlg.setAttribute('aria-label','Einsatzbezogene Leitplatz-Qualitätsprüfung');document.body.append(dlg);
let activeId=null,prevFocus=null;
function resolve(s){if(!s)return null;const current=window.LDWorkstation?.active?.();if(activeId==null&&s.incidents.some(i=>i.id===current))activeId=current;if(activeId==null)activeId=cases(s)[0]?.id??s.incidents[0]?.id;return s.incidents.find(x=>x.id===activeId)||null}
function draw(){const s=S();if(!s)return close();const i=resolve(s);if(!i)return close();const c=checks(s,i);const q=setup(i);const list=cases(s);
 dlg.innerHTML=`<div class="window"><div class="head"><h2>Leitplatzprüfung · Fall #${esc(i.id)}</h2><span class="muted">SIM ${timestamp(s.minute)} · Übungsmodell</span><span style="flex:1"></span><button data-qa="close">✕ Zurück</button></div><div class="body"><p class="muted">Arbeitsplatzinterne Vollständigkeitsprüfung – kein offizielles Abfrageschema, keine medizinische Entscheidungshilfe. Alarmierung bleibt jederzeit möglich.</p><label>Vorgang <select id="ld20-select">${list.map(x=>`<option value="${x.id}" ${x.id===i.id?'selected':''}>#${x.id} · ${esc(x.type)} · ${esc(x.phase)}</option>`).join('')||`<option value="${i.id}">#${i.id}</option>`}</select></label><p><strong>${esc(i.type)}</strong> · ${esc(i.city)} · P${esc(i.prio)} · ${esc(i.phase)}</p><div class="pct"><div style="width:${c.percent}%"></div></div><p class="muted">${c.complete} von ${c.required} Dokumentationspunkten bestätigt · ${c.elapsed} Sim.-Min. seit Eingang</p><div class="grid"><div><h3>Prüfliste</h3>${c.items.map(t=>`<div class="item"><span><strong class="${t.done?'complete':''}">${t.done?'✓':'○'} ${esc(t.label)}</strong><br><small class="muted">${esc(t.detail)}</small></span><button data-qa="check" data-key="${t.key}" data-confirm="${t.done?'0':'1'}">${t.done?'Zurücknehmen':'Bestätigen'}</button></div>`).join('')}<p class="muted">Angaben können am zweiten Arbeitsplatzmonitor bearbeitet werden.</p><button data-qa="edit">Einsatzakte öffnen</button><button data-qa="review">Prüfung dokumentieren</button></div><div><h3>Aktuelle Hinweise</h3>${c.warnings.map(w=>`<div class="warning ${w.level==='hoch'?'danger':''}">${esc(w.text)}</div>`).join('')||'<p class="complete">Keine besonderen Warnungen aus dem Übungsmodell.</p>'}<h3>Prüfchronologie</h3><div class="log">${q.notes.slice(0,20).map(t=>`${timestamp(t.minute)} · ${esc(t.text)}`).join('\n')||'Noch keine Prüfeinträge'}</div></div></div></div></div>`;
}
function open(id=null){const s=S();if(!s)return;if(id!=null)activeId=Number(id);else activeId=window.LDWorkstation?.active?.()||cases(s)[0]?.id||s.incidents[0]?.id;prevFocus=document.activeElement;draw();dlg.classList.add('open');dlg.querySelector('button[data-qa="close"]')?.focus()}
function close(){dlg.classList.remove('open');prevFocus?.focus?.()}
dlg.addEventListener('change',e=>{if(e.target.id==='ld20-select'){activeId=Number(e.target.value);draw()}});
dlg.addEventListener('click',e=>{const b=e.target.closest('[data-qa]');if(!b)return;const a=b.dataset.qa,s=S();if(!s)return;
 if(a==='close')return close();if(a==='edit'){close();window.openWorkstation?.('case');return}
 if(a==='check'){const result=confirm(s,activeId,b.dataset.key,b.dataset.confirm==='1');if(!result.ok){window.alert?.(result.reason);return}draw();window.refreshWorkstation?.();return}
 if(a==='review'){review(s,activeId);draw();window.refreshWorkstation?.()}
});
function inject(){const s=S(),article=document.querySelector('#elsdesk.open [data-panel="case"]');if(!article||!s||article.querySelector('#ld20-review'))return;const i=s.incidents.find(x=>x.id===window.LDWorkstation?.active?.());if(!i)return;const c=checks(s,i);const div=document.createElement('div');div.id='ld20-review';div.innerHTML=`<b>Leitplatzprüfung</b><div class="status">${c.complete}/${c.required} Angaben bestätigt · ${c.warnings.length} Hinweise · ausschließlich Simulationsmaßstäbe</div><button type="button" data-qa-inline>Prüf- und Dokumentationsliste öffnen</button>`;div.querySelector('button').addEventListener('click',()=>open(i.id));article.querySelector('h3')?.insertAdjacentElement('afterend',div)}
const work=document.querySelector('#elsdesk');if(work)new MutationObserver(inject).observe(work,{childList:true,subtree:false});
setInterval(()=>{inject();if(dlg.classList.contains('open')&&S()&&!dlg.contains(document.activeElement))draw()},1500);
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&dlg.classList.contains('open')){e.stopImmediatePropagation();close()}});
// Audit each case once when the simulated incident is actually closed.
const baseTick=window.LDLogic?.tick;if(baseTick){window.LDLogic.tick=function(s,...args){const before=new Set((s.incidents||[]).filter(i=>i.phase!=='Abgeschlossen').map(i=>i.id));const result=baseTick.call(this,s,...args);for(const i of (s.incidents||[])){if(i.phase==='Abgeschlossen'&&before.has(i.id)&&!setup(i).completedReview){const c=checks(s,i);setup(i).completedReview=true;audit(s,i,`Einsatzabschluss – dokumentiert ${c.complete}/${c.required}`)}}return result}}
window.LDCaseQuality={setup,checks,confirm,review,open,close,inject,draw};
})();
