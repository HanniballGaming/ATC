"""Additional v0.17 end-to-end tests in headless Chromium; not a real iPad test."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import re, json
root = Path(__file__).parent
html = (root/'index.html').read_text()
shell = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.S)
shell = re.sub(r'<link\s+rel="stylesheet"[^>]+>', '', shell)
blocks = re.findall(r'<script([^>]*)>(.*?)</script>', html, re.S)
checks=[]
def check(name,actual):
    checks.append((name,bool(actual)))
    print(('PASS' if actual else 'FAIL'), name)
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security'])
    page=browser.new_page(viewport={'width':1024,'height':768},has_touch=True,accept_downloads=True)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(shell)
    geodata=(root/'regions.geojson').read_text()
    page.evaluate('''geodata=>{const data=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k),clear:()=>data.clear()}});window.fetch=async url=>String(url).includes('regions.geojson')?new Response(geodata,{status:200}):Promise.reject(new Error('Offline-Test'))}''', geodata)
    for attr,code in blocks:
        match=re.search(r'src="([^"]+)',attr)
        if match:
            if match.group(1).startswith('http'):continue
            code=(root/match.group(1).replace('./','')).read_text()
        page.add_script_tag(content=code)
    page.wait_for_timeout(600)
    check('Alle 18 Regionen auswählbar',page.locator('#area option').count()==18)
    page.locator('[data-action="new"]').click()
    page.wait_for_timeout(1200)
    check('Gebietsabsicherung erreichbar',page.locator('#ld-coverage-toggle').is_visible())
    page.locator('#ld-coverage-toggle').click()
    check('Gebietsabsicherung öffnet',page.locator('#ld-coverage.open').count()==1)
    check('Abdeckungsprognosen berechnet',page.locator('#ld-coverage .grid .cell').count()>=4)
    check('Mindestens ein verfügbares Fahrzeug',page.locator('[data-coverage-vehicle] option').count()>0)
    options=page.locator('[data-coverage-city] option').all_text_contents()
    check('Bereitstellungsorte vorhanden',len(options)>=3)
    # Choose a destination unlike the selected unit's current position.
    chosen=page.evaluate('''()=>{const s=window.getGame().s;const v=s.vehicles.find(v=>v.status==='frei');const c=window.getGame().areas[s.area].cities.find(c=>c!==v.city);return {unit:v.id,city:c}}''')
    page.locator('[data-coverage-vehicle]').select_option(chosen['unit'])
    page.locator('[data-coverage-city]').select_option(chosen['city'])
    page.locator('[data-coverage="move"]').click()
    check('Verlegung protokolliert',page.evaluate('''u=>{const s=window.getGame().s;const v=s.vehicles.find(x=>x.id===u);return v.stage==='Verlegung'&&v.status==='verlegt'&&s.coverageMoves===1}''',chosen['unit']))
    check('Verlegtes Fahrzeug nicht disponierbar',page.evaluate('''u=>!window.getGame().s.vehicles.filter(v=>v.status==='frei').some(v=>v.id===u)''',chosen['unit']))
    page.locator('[data-coverage="close"]').click()
    page.evaluate('''u=>{const s=window.getGame().s;const v=s.vehicles.find(x=>x.id===u);s.nextCall=99999;const prev=s.speed;s.speed=10;for(let n=0;n<15;n++)window.LDLogic.tick(s,window.getGame().areas,[],()=>{});s.speed=prev}''',chosen['unit'])
    check('Verlegung endet am Zielort',page.evaluate('''x=>{const v=window.getGame().s.vehicles.find(v=>v.id===x.unit);return v.city===x.city&&v.stage==='frei'&&v.status==='frei'}''',chosen))
    page.evaluate('window.LDOperations.save()')
    check('Verlegung bleibt gespeichert',page.evaluate('''()=>JSON.parse(localStorage.getItem('leitstelle-deutschland-save-v1')||'null')?.coverageMoves===1''') or page.evaluate('''()=>Object.keys(localStorage).some(k=>JSON.parse(localStorage.getItem(k)||'null')?.coverageMoves===1)'''))
    # Offline behavior of polyline interpolation uses verified in-game algorithm, not external tiles.
    pt=page.evaluate('''()=>window.LDRouting.interpolate([[48,10],[48,11],[49,11]],0.5)''')
    check('Linieninterpolation im Straßennetzmodul',pt is not None and 47.9<pt[0]<49.1 and 9.9<pt[1]<11.1)
    check('Fallback trägt korrekte Kennzeichnung',page.evaluate("window.LDRouting.fallback({lat:48,lon:10},{lat:49,lon:11}).geometrySource==='none'"))
    check('Keine JavaScript-Ausnahme',len(errors)==0)
    print('ERRORS:',errors)
    browser.close()
print(f'TOTAL {sum(ok for _,ok in checks)}/{len(checks)}')
assert all(ok for _,ok in checks)
