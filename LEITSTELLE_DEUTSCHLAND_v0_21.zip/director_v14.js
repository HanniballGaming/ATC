/* LEITSTELLE DEUTSCHLAND 0.14 — local fictional situation director.
   This is NOT a medically certified triage tool, actual dispatch center,
   real-time road incident database or empirically calibrated driving model. */
(()=>{'use strict';
const els=document.getElementById('elsdesk');
const escapeHTML=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const time=m=>`${String(Math.floor((m||0)/60)%24).padStart(2,'0')}:${String((m||0)%60).padStart(2,'0')}`;
const get=()=>window.LDOperations?.getState?.();
const caseById=(s,id)=>s?.incidents?.find(i=>i.id===Number(id));
const firstAvailable=(s,type)=>s?.vehicles?.find(v=>v.status==='frei'&&v.type===type);
const family=t=>/Wohnungsbrand|Gewerbebrand|Brandmeldeanlage|Kohlenmonoxid/.test(t)?'fire':/Verkehrsunfall|Massenanfall|Fahrrad/.test(t)?'road':/Wasser|Baum|Aufzug|Türöffnung/.test(t)?'technical':'medical';
const scenarios={
 medical:[
  'Nachmeldung: Der Zustand der betroffenen Person hat sich verändert. Erneute Einschätzung der Dringlichkeit erforderlich.',
  'Lagemeldung: Die Einsatzstelle bittet um eine Rückfrage zur Zufahrt und zu weiteren Betroffenen.',
  'Weitere Information: Die gemeldete Lage ist noch nicht abschließend geklärt.'
 ],
 fire:[
  'Nachmeldung: Die Rauchentwicklung ist stärker als zunächst gemeldet. Mögliche Ausbreitung prüfen.',
  'Lagemeldung: Zusätzliche Informationen zu Personen im betroffenen Objekt liegen vor.',
  'Weitere Information: Es bestehen noch offene Fragen zur Gebäudenutzung und Erreichbarkeit.'
 ],
 road:[
  'Nachmeldung: Der Verkehr staut sich vor der Einsatzstelle; Anfahrt und Absicherung prüfen.',
  'Lagemeldung: Die Zahl der Betroffenen muss vor Ort erneut bestätigt werden.',
  'Weitere Information: Die Absicherung der Anfahrtssituation bleibt relevant.'
 ],
 technical:[
  'Nachmeldung: Die Einsatzlage ist weiterhin nicht vollständig geklärt. Gefährdungen und Zugang prüfen.',
  'Lagemeldung: Die eingesetzten Kräfte melden zusätzlichen Klärungsbedarf.',
  'Weitere Information: Rückmeldungen zur Einsatzstelle liegen vor.'
 ]
};
const sceneReports={
 medical:'Status 4: Erstmeldung von der Einsatzstelle. Patient wird untersucht; Transportentscheidung steht noch aus.',
 fire:'Status 4: Erste Erkundung läuft. Brand- und Personensituation werden überprüft.',
 road:'Status 4: Unfallstelle erreicht. Verkehrsabsicherung und Erkundung laufen.',
 technical:'Status 4: Einsatzstelle erreicht. Technische Lage wird erkundet.'
};
function ensure(s){
 if(!s)return;
 s.director??={lastMinute:s.minute,notifications:[],closures:[],nextTraffic:s.minute+36,version:14};
 s.director.notifications??=[];s.director.closures??=[];s.director.nextTraffic??=s.minute+36;
 for(const i of s.incidents||[]){
  i.live??={next:s.minute+Math.max(3,6-(i.age||0)),count:0,sceneReported:false,followUps:[],reviewedAt:null,urgencySuggested:false};
  if(!Number.isFinite(i.live.next))i.live.next=s.minute+5;
 }
 return s.director;
}
function log(s,msg,i,logger){const text=String(msg);if(i){i.history??=[];i.history.unshift({minute:s.minute,text});i.history=i.history.slice(0,90)}s.director.notifications.unshift({minute:s.minute,incident:i?.id||null,text});s.director.notifications=s.director.notifications.slice(0,32);logger?.(text);}
function develop(s,i,logger){if(!i||['Abgeschlossen','Anruf','Unversorgt'].includes(i.phase))return;const d=i.live,k=family(i.type);const active=(s.vehicles||[]).filter(v=>v.incident===i.id);const atScene=active.some(v=>v.stage==='vor Ort'||v.stage==='Transport'||v.stage==='Nachbereitung');
 if(atScene&&!d.sceneReported){d.sceneReported=true;log(s,`#${i.id} · ${sceneReports[k]}`,i,logger)}
 if(d.count>=3||s.minute<d.next)return;
 // A later status message depends on what the player has already dispatched.
 const text=d.count===0&&!active.length?
 `#${i.id} · Erneuter Anruf: Noch kein Einsatzmittel auf dem Weg. ${scenarios[k][0]}`:
 `#${i.id} · ${scenarios[k][d.count]}`;
 d.followUps.push({minute:s.minute,text,read:false});d.followUps=d.followUps.slice(-12);d.count++;
 d.next=s.minute+(d.count===1?9:14);
 if(d.count===1&&(!active.length||i.prio>1)&&['medical','fire','road'].includes(k))d.urgencySuggested=true;
 log(s,text,i,logger);
}
function trafficAffected(s,v,i){const d=s?.director?.closures||[];return d.filter(x=>x.until>s.minute&&(x.city===i?.city||x.city===v?.city||x.city==='Gebietsübergreifend'))}
function createClosure(s,logger,customCity){ensure(s);const cities=window.getGame?.()?.areas?.[s.area]?.cities||[];
 const city=customCity||cities[(s.minute+Math.floor((s.nextId||1)*7))%Math.max(1,cities.length)]||'Gebietsübergreifend';
 const id='V-'+(s.minute)+'-'+s.director.closures.length;
 const choices=['Verkehrsbehinderung / Rückstau','Baustellenbedingte Einschränkung','Witterungsbedingte Einschränkung'];
 const kind=choices[(s.minute+s.director.closures.length)%choices.length];
 const event={id,city,kind,since:s.minute,until:s.minute+Math.max(20,35+(s.minute%24)),delay:2+(s.minute%4),fictional:true};
 s.director.closures.push(event);s.director.closures=s.director.closures.slice(-10);
 log(s,`Verkehrslage (Simulation): ${kind} bei ${city}; +${event.delay} Min. Ersatzzeitmodell.`,null,logger);
 return event;
}
function advance(s,logger){ensure(s);if(!Number.isFinite(s.minute))return;const d=s.director;
 // Several simulated minutes can advance in a single rendering frame.
 if(s.minute<=d.lastMinute)return;
 d.closures=d.closures.filter(x=>x.until>s.minute);
 for(const i of s.incidents){if(!i.live)i.live={next:s.minute+5,count:0,sceneReported:false,followUps:[]};develop(s,i,logger)}
 if(s.minute>=d.nextTraffic){createClosure(s,logger);d.nextTraffic=s.minute+75;}
 for(const v of s.vehicles){if(!v.incident||!['alarmiert','Anfahrt'].includes(v.stage))continue;
  const i=caseById(s,v.incident);if(!i)continue;
  const disruptions=trafficAffected(s,v,i);
  for(const c of disruptions)if(!v.disruptionApplied?.includes(c.id)){
   v.disruptionApplied??=[];v.disruptionApplied.push(c.id);v.travelMinutes=(v.travelMinutes||5)+c.delay;
   if(v.stage==='Anfahrt')v.eta=(v.eta||0)+c.delay;
   v.routeMethod=(v.routeMethod||'Ersatzmodell')+' · '+c.kind+' (fiktiv)';
   log(s,`${v.id}: Fahrzeitprognose +${c.delay} Min. wegen simulierter Störung bei ${c.city}.`,i,logger);
  }
 }
 d.lastMinute=s.minute;
}
function review(s,id,logger){ensure(s);const i=caseById(s,id);if(!i||!i.live)return null;const next=i.live.followUps?.filter(f=>!f.read)||[];for(const f of next)f.read=true;i.live.reviewedAt=s.minute;const result=next.length?`${next.length} Lageaktualisierung(en) übernommen und protokolliert.`:'Aktuell keine ungelesenen Lageaktualisierungen.';log(s,`#${id}: ${result}`,i,logger);return result}
function reportScene(s,id,logger){ensure(s);const i=caseById(s,id);if(!i||i.phase==='Abgeschlossen')return null;const units=s.vehicles.filter(v=>v.incident===i.id),atScene=units.filter(v=>['vor Ort','Transport','Nachbereitung'].includes(v.stage));const text=atScene.length?`${atScene.map(v=>v.id).join(', ')}: ${sceneReports[family(i.type)]}`:`Noch keine eigenen Kräfte am Einsatzort. Verfügbar: ${units.map(v=>`${v.id} ${v.status}`).join(', ')||'keine zugeordneten Einsatzmittel'}.`;
 s.radioLog??=[];s.radioLog.unshift(`${time(s.minute)} · LAGEMELDUNG #${i.id}: ${text}`);s.radioLog=s.radioLog.slice(0,70);log(s,`Lagemeldung #${i.id}: ${text}`,i,logger);return text}
function dispatchPlan(s,id,logger){const i=caseById(s,id);if(!i||!['Disponierung','Unterwegs','Am Einsatzort'].includes(i.phase))return {done:0,unfilled:[]};let done=0;const needs=[...i.need];for(const type of needs){const suggested=window.LDLogic?.suggestions?.(s,i,type)?.[0],v=suggested&&firstAvailable(s,type);if(!v)continue;if(window.LDLogic.dispatch(s,id,type,suggested.id,logger)){done++}}
 const unfilled=[...i.need];log(s,`#${id}: ${done} Fahrzeug(e) nach Vorschlagsliste alarmiert; ${unfilled.length} Anforderungen offen.`,i,logger);return {done,unfilled}}
function scoreSuggestions(s,i,list){return list.map(item=>{const v=s.vehicles.find(v=>v.id===item.id),affect=v?trafficAffected(s,v,i):[];const extra=affect.reduce((sum,c)=>sum+c.delay,0);return {...item,minutes:Math.round((item.minutes+extra)*10)/10,method:item.method+(extra?' + sim. Verkehrslage':'')}}).sort((a,b)=>a.minutes-b.minutes||a.id.localeCompare(b.id))}
const originalInit=window.LDLogic.init,originalSpawn=window.LDLogic.spawn,originalTick=window.LDLogic.tick,originalSuggestions=window.LDLogic.suggestions,originalDispatch=window.LDLogic.dispatch;
window.LDLogic.init=function(s,...rest){const v=originalInit.call(this,s,...rest);ensure(s);return v};
window.LDLogic.spawn=function(s,...args){const v=originalSpawn.call(this,s,...args);ensure(s);return v};
window.LDLogic.tick=function(s,areas,types,logger){if(!s||s.paused)return originalTick.call(this,s,areas,types,logger);const before=s.minute;const result=originalTick.call(this,s,areas,types,logger);if(s.minute!==before)advance(s,logger);return result};
window.LDLogic.suggestions=function(s,i,type){ensure(s);return scoreSuggestions(s,i,originalSuggestions.call(this,s,i,type))};
window.LDLogic.dispatch=function(s,id,type,unitId,logger){ensure(s);const i=caseById(s,id);const target=unitId||window.LDLogic.suggestions(s,i,type)?.[0]?.id;if(!target)return false;const ok=originalDispatch.call(this,s,id,type,target,logger);if(ok){const v=s.vehicles.find(v=>v.id===target);const extra=trafficAffected(s,v,i);for(const c of extra){v.disruptionApplied??=[];if(v.disruptionApplied.includes(c.id))continue;v.disruptionApplied.push(c.id);v.travelMinutes+=c.delay;v.routeMethod+=' + simulierte Verzögerung';}log(s,`${target}: Dispositionsentscheidung für #${id} dokumentiert`,i,logger)}return ok};
window.LDDirector={ensure,advance,review,reportScene,dispatchPlan,createClosure,trafficAffected};

const style=document.createElement('style');style.textContent=`#elsdesk .ld14-panel{margin:12px 0;padding:12px;background:#102c3b;border:1px solid #4d8b9d;border-radius:8px;color:#d7ecf5}#elsdesk .ld14-panel h4{color:#9ce9ed;margin:0 0 6px}#elsdesk .ld14-feed{max-height:180px;overflow:auto}#elsdesk .ld14-message{padding:6px 4px;border-bottom:1px solid #2f5163;font-size:12px}#elsdesk .ld14-unread{border-left:3px solid #e6b669;background:#48332669;padding:7px}#elsdesk .ld14-controls{display:flex;gap:6px;flex-wrap:wrap}#elsdesk .ld14-warn{color:#ffb6a5}#elsdesk .ld14-meta{font-size:11px;color:#adc4d2}#elsdesk button[data-director]{min-height:39px}`;document.head.append(style);
let lastId=null,lastSig='';function selected(){const s=get();if(!s)return {s:null,i:null};ensure(s);const selectedId=els.querySelector('article[data-panel="call"] .item.active[data-id]')?.dataset.id;const i=caseById(s,selectedId)||s.incidents.find(x=>x.phase!=='Abgeschlossen')||s.incidents[0];return {s,i}}
function panelRender(){if(!els.classList.contains('open'))return;const {s,i}=selected();if(!s)return;const caseNode=els.querySelector('article[data-panel="case"]'),resourceNode=els.querySelector('article[data-panel="resources"]');if(!caseNode||!resourceNode)return;
 let situation=document.getElementById('ld14-situation');if(!situation){situation=document.createElement('section');situation.className='ld14-panel';situation.id='ld14-situation';caseNode.querySelector('h3')?.after(situation)}
 let transport=document.getElementById('ld14-traffic');if(!transport){transport=document.createElement('section');transport.className='ld14-panel';transport.id='ld14-traffic';resourceNode.querySelector('h3')?.after(transport)}
 const updates=(i?.live?.followUps||[]).slice(-4).reverse(),unread=updates.filter(v=>!v.read).length;const sig=`${s.minute}|${i?.id}|${unread}|${i?.live?.count}|${i?.live?.sceneReported}|${s.director.closures.map(c=>c.id).join(',')}|${i?.phase}|${i?.need?.length}`;
 if(lastId===caseNode&&sig===lastSig)return;lastId=caseNode;lastSig=sig;
 situation.innerHTML=`<h4>Live-Lageentwicklung · Vorgang ${i?'#'+i.id:'–'}</h4><div class="ld14-meta">Fiktive, zeitabhängige Nachmeldungen; Änderungen sind keine medizinische Entscheidungshilfe.</div>${i?`<p class="ld14-meta">${i.live?.sceneReported?'Erste Lagemeldung eingegangen':'Erste Lagemeldung ausstehend'} · ${unread} ungelesen · Priorität P${i.prio}</p>${i.live?.urgencySuggested?'<p class="ld14-warn">Erneute Dringlichkeitsprüfung empfohlen. Priorität manuell prüfen.</p>':''}<div class="ld14-feed">${updates.map(x=>`<div class="ld14-message ${x.read?'':'ld14-unread'}"><span class="ld14-meta">${time(x.minute)}</span> ${escapeHTML(x.text)}</div>`).join('')||'<p class="ld14-meta">Noch keine weiteren Meldungen.</p>'}</div><div class="ld14-controls"><button data-director="review" data-id="${i.id}">Nachmeldungen übernehmen</button><button data-director="scene" data-id="${i.id}">Lagemeldung anfordern</button><button class="primary" data-director="dispatch" data-id="${i.id}">Alle offenen Vorschläge alarmieren</button></div>`:'<p>Kein Einsatz ausgewählt.</p>'}`;
 transport.innerHTML=`<h4>Verkehrslage · modellierte Störungen</h4><div class="ld14-meta">Keine tatsächlichen Verkehrs- oder Sperrungsdaten. Das Modell berücksichtigt örtliche Verzögerungen bei neuen und laufenden Dispositionen.</div><div class="ld14-feed">${s.director.closures.filter(x=>x.until>s.minute).map(x=>`<div class="ld14-message"><b>${escapeHTML(x.city)}</b> · ${escapeHTML(x.kind)}<br><span class="ld14-meta">Zusatz ca. ${x.delay} Sim.-Min., bis ${time(x.until)} (fiktiv)</span></div>`).join('')||'<p class="ld14-meta">Aktuell keine simulierten Störungen.</p>'}</div><button data-director="traffic">Trainingsstörung auslösen</button>`;
}
let renderScheduled=false;function schedule(){if(renderScheduled)return;renderScheduled=true;setTimeout(()=>{renderScheduled=false;panelRender()},20)};
const observer=new MutationObserver(schedule);observer.observe(els,{childList:true,subtree:false,attributes:true,attributeFilter:['class']});
els.addEventListener('click',e=>{const b=e.target.closest('[data-director]');if(!b)return;const {s,i}=selected();if(!s)return;e.stopPropagation();const action=b.dataset.director,id=Number(b.dataset.id||i?.id);let result=null;
 if(action==='review')result=review(s,id,window.LDOperations.log);
 if(action==='scene')result=reportScene(s,id,window.LDOperations.log);
 if(action==='dispatch')result=dispatchPlan(s,id,window.LDOperations.log);
 if(action==='traffic')result=createClosure(s,window.LDOperations.log);
 window.LDOperations?.save?.();lastSig='';window.LDRefresh?.();schedule();return result;
},true);
setInterval(()=>{if(els.classList.contains('open'))schedule()},1800);
})();
