from playwright.sync_api import sync_playwright
from pathlib import Path
import re,json
base=Path(__file__).parent
html=(base/'index.html').read_text()
blocks=re.findall(r'<script([^>]*)>(.*?)</script>',html,re.S)
shell=re.sub(r'<script[^>]*>.*?</script>','',html,flags=re.S)
shell=re.sub(r'<link\s+rel="stylesheet"[^>]+>','',shell)
geodata=(base/'regions.geojson').read_text()
results=[]

def check(name,condition):
 results.append((name, bool(condition)))
 print(('PASS' if condition else 'FAIL'),name)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-webgl','--disable-web-security'])
 page=b.new_page(viewport={'width':1180,'height':840},device_scale_factor=1,accept_downloads=True)
 errs=[]
 page.on('pageerror',lambda e:errs.append(str(e)))
 page.set_content(shell,wait_until='domcontentloaded')
 page.evaluate("""text => {const store=new Map();Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,String(v)),removeItem:k=>store.delete(k),clear:()=>store.clear(),key:n=>[...store.keys()][n]||null,get length(){return store.size}}});const original=window.fetch;window.fetch=async(url)=>{if(String(url).includes('regions.geojson'))return new Response(text,{status:200,headers:{'Content-Type':'application/json'}});throw Error('Online-Dienst nicht verfügbar (Test)')}}""",geodata)
 for attrs,code in blocks:
  m=re.search(r'src="([^"]+)',attrs)
  if m:
   if m.group(1).startswith('https:'):continue
   code=(base/m.group(1).replace('./','')).read_text()
  page.add_script_tag(content=code)
 page.wait_for_timeout(550)
 check('18 vereinfachte Leitstellenregionen',page.locator('#area option').count()==18)
 check('4 Schichtmodi wählbar',page.locator('#ld-preset option').count()==4)
 page.locator('#ld-preset').select_option('storm')
 page.locator('[data-action="new"]').click()
 page.wait_for_timeout(1750)
 check('Spielstand initialisiert',page.evaluate('!!window.getGame().s'))
 check('Preset Unwetterlage aktiv',page.evaluate("window.getGame().s.shift?.mode==='storm' && window.getGame().s.weather==='schlecht' && window.getGame().s.workload==='hoch'"))
 check('24 Fahrzeuge',page.evaluate('window.getGame().s.vehicles.length')==24)
 check('Gebietsdaten geladen',page.evaluate('!!window.LDRegions'))
 check('Renderfallback ohne WebGL',page.locator('canvas[data-render-backend="software"]').count()>0 or page.locator('canvas[data-render-backend="webgl"]').count()>0)
 check('Schichtmodul vorhanden',page.evaluate("typeof window.LDRelease?.metrics==='function' && typeof window.LDRelease?.textReport==='function'"))
 check('Kennzahl vor Einsätzen',page.evaluate('window.LDRelease.metrics(window.getGame().s).total')>=1)
 page.evaluate('window.openWorkstation("call")')
 page.wait_for_timeout(900)
 check('Bedienbarer Arbeitsplatz',page.locator('#elsdesk.open article').count()==3)
 check('Schichtlage Button',page.locator('[data-ld16-toggle]').count()==1)
 page.locator('[data-ld16-toggle]').click()
 check('Schichtbericht öffnet',page.locator('#ld16-panel.open').count()==1)
 check('Schichtbericht enthält Kennzahlen',page.locator('#ld16-panel').inner_text().find('Notrufe')>=0)
 check('Bericht ist verständlich',page.evaluate('window.LDRelease.textReport(window.getGame().s).includes("SIMULATION")'))
 page.locator('#ld16-panel [data-ld16="call"]').click()
 check('Übungsnotruf auslösbar',page.evaluate('window.getGame().s.incidents.length')>=2)
 page.locator('#ld16-panel [data-ld16="traffic"]').click()
 check('Verkehrsstörung im Modus erzeugbar',page.evaluate('window.getGame().s.director?.closures?.length>0'))
 page.locator('#ld16-panel [data-ld16="handover"]').click()
 check('Schichtübergabe speicherbar',page.evaluate('window.getGame().s.handover.length>=1'))
 with page.expect_download(timeout=6500) as d:
  page.locator('#ld16-panel [data-ld16="save"]').click()
 check('Schichtbericht exportierbar',d.value.suggested_filename.endswith('.txt'))
 page.locator('#ld16-panel [data-ld16="close"]').click()
 check('Schichtlage schließbar',page.locator('#ld16-panel.open').count()==0)
 s=page.evaluate('window.getGame().s');incident=s['incidents'][0]
 case_id=incident['id']
 page.evaluate('(id)=>window.LDLogic.accept(window.getGame().s,id,()=>{})',case_id)
 check('Notrufannahme nach Overlay',page.evaluate('(id)=>window.getGame().s.incidents.find(i=>i.id===id).phase!=="Anruf"',case_id))
 page.evaluate('(id)=>{const s=window.getGame().s;let i=s.incidents.find(i=>i.id===id),t=i.need[0];if(t)window.LDLogic.dispatch(s,id,t,null,()=>{})}',case_id)
 check('Disposition und Zeitmessung',page.evaluate('(id)=>Number.isFinite(window.getGame().s.incidents.find(i=>i.id===id).shiftMeta.firstDispatchAt)',case_id))
 check('Warnmeldungen berechenbar',page.evaluate('Array.isArray(window.LDRelease.alerts(window.getGame().s))'))
 check('Erweiterte Dialogabsichten vorhanden',page.evaluate("window.LDDialoguePlus.classify('Wie alt ist der Patient?')==='age'"))
 first=page.evaluate('(id)=>window.LDLogic.converse(window.getGame().s,id,"Wie alt ist der Patient?",()=>{})',case_id)
 second=page.evaluate('(id)=>window.LDLogic.converse(window.getGame().s,id,"Wie alt ist der Patient?",()=>{})',case_id)
 check('Identische Rückfragen konsistent',first['answer']==second['answer'])
 check('Offene Frage dokumentiert',page.evaluate('(id)=>window.getGame().s.incidents.find(i=>i.id===id).transcript.some(t=>t.includes("Wie alt ist der Patient"))',case_id))
 check('Freie Lagebeschreibung funktioniert',page.evaluate('(id)=>!!window.LDLogic.converse(window.getGame().s,id,"Was ist passiert?",()=>{}).answer',case_id))
 check('Koordinatenmodell für Einsatzfahrzeuge',page.evaluate("typeof window.LDGIS?.getSimulatedUnitLocation==='function'"))
 check('Keine JS-Ausnahmen',len(errs)==0)
 print('ERRORS',errs)
 page.screenshot(path=str(base/'preview_v16.png'))
 b.close()
print(f'SUMMARY {sum(ok for _,ok in results)}/{len(results)}')
assert all(ok for _,ok in results)
