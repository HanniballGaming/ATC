/* LEITSTELLE DEUTSCHLAND: self-contained, dependency-free WebGL 1.0 room renderer.
   This is a procedurally modelled fictional dispatch center. No external assets,
   network imports, or real dispatch-center floor plans are used. */
(()=>{'use strict';
const g=()=>window.getGame?.();
const FOV=67*Math.PI/180;
let room=null,canvas=null,gl=null,colorProgram=null,textureProgram=null,geo=null,vertices=[],monitorMeshes=[],monitorInfo=[],peers=[],screenTextures=[],drag=null,seat=true,last=0,lastScreens=0,disabled=false,labelLayer=null;
const cam={x:0,y:1.5,z:5.7,yaw:0,pitch:-.045},keys={};
const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
function rgb(hex,factor=1){const n=parseInt(hex.slice(1),16);return [((n>>16)&255)/255*factor,((n>>8)&255)/255*factor,(n&255)/255*factor]}
function shade(a,mul){return [a[0]*mul,a[1]*mul,a[2]*mul]}
function tri(a,b,c,col){vertices.push(...a,...col,...b,...col,...c,...col)}
function quad(a,b,c,d,col){tri(a,b,c,col);tri(a,c,d,col)}
function box(x,y,z,w,h,d,col){const l=x-w/2,r=x+w/2,b=y-h/2,t=y+h/2,n=z+d/2,f=z-d/2,c=rgb(col);
  quad([l,b,n],[r,b,n],[r,t,n],[l,t,n],shade(c,.92));quad([r,b,f],[l,b,f],[l,t,f],[r,t,f],shade(c,.57));
  quad([l,b,f],[l,b,n],[l,t,n],[l,t,f],shade(c,.72));quad([r,b,n],[r,b,f],[r,t,f],[r,t,n],shade(c,.8));
  quad([l,t,n],[r,t,n],[r,t,f],[l,t,f],shade(c,1.16));quad([l,b,f],[r,b,f],[r,b,n],[l,b,n],shade(c,.5));}
function pane(x,y,z,w,h,kind){box(x,y,z-.12,w+.12,h+.11,.12,'#08131d');monitorInfo.push({x,y,z,w,h,kind});}
function colleague(x,z,k){peers.push({x,y:1.58,z:z+.83});const shirt=['#315c73','#264859','#3d5668','#314f64'][k%4];box(x,1.06,z+.82,.62,.65,.32,shirt);box(x-.33,1.07,z+.65,.12,.43,.21,shirt);box(x+.33,1.07,z+.65,.12,.43,.21,shirt);box(x,1.59,z+.83,.38,.42,.36,['#c79d7e','#aa7f63','#d2aa8b'][k%3]);box(x,1.73,z+.82,.4,.13,.37,['#342c2a','#1a252c','#3a2d26'][k%3]);box(x+.21,1.58,z+.83,.05,.22,.22,'#152938');box(x+.19,1.47,z+.59,.10,.04,.20,'#202f3a')}
function desk(x,z,own=false,k=0){
 box(x,.78,z,3.95,.11,1.65,'#607282');for(const a of [-1.8,1.8])for(const b of [-.67,.67])box(x+a,.4,z+b,.075,.76,.075,'#526574');
 for(let j=-1;j<=1;j++){const px=x+j*1.18;box(px,1.51,z-.52,1.13,.79,.12,'#111b29');box(px,1.05,z-.51,.12,.53,.10,'#65717a');
 if(own)pane(px,1.51,z-.445,1.02,.69,['call','case','resources'][j+1]);else if(j===0)pane(px,1.51,z-.445,1.02,.69,'peer_'+k);else box(px,1.51,z-.445,1.01,.68,.025,['#0c2e3e','#174258','#12485b'][(j+k+3)%3]);}
 box(x,.872,z+.44,1.02,.045,.32,'#182a38');for(let row=0;row<3;row++)for(let col=0;col<13;col++)box(x-.45+col*.069,.905,z+.31+row*.074,.053,.01,.048,'#667989');
 box(x+.78,.884,z+.48,.16,.045,.15,'#152635');box(x+1.42,.9,z+.42,.22,.12,.30,'#1b2d3c');box(x-1.42,.87,z+.45,.31,.06,.21,'#174d5a');
 box(x,.46,z+1.13,.78,.15,.63,'#222c39');box(x,.86,z+1.44,.74,.7,.10,'#233647');box(x,.19,z+1.13,.08,.37,.08,'#65717a');
 if(!own)colleague(x,z,k);
}
function generate(){vertices=[];monitorInfo=[];peers=[];
 // Architecture, warm grey floor, panelled walls and acoustic ceiling.
 box(0,-.10,0,22,.2,20,'#515d68');box(0,2.0,-9.85,22,4,.2,'#354655');box(-11,2,0,.18,4,20,'#364555');box(11,2,0,.18,4,20,'#364555');box(0,4.1,0,22,.18,20,'#202d3b');
 for(let k=-10;k<=10;k+=2){box(k,.015,0,.015,.015,19.8,'#65717a');box(0,.015,k,21,.015,.014,'#65717a')}
 for(let z=-9;z<10;z+=3.4){box(0,4.0,z,21.8,.045,.04,'#586777');for(let x=-10;x<=10;x+=3.5)box(x,4.0,z, .04,.045,3.4,'#586777')}
 for(let z of [-6,0,6])for(let x of [-7,0,7]){box(x,3.95,z,2.7,.08,.85,'#e2f0e9');box(x,3.90,z,2.85,.025,.94,'#98b7bd')}
 for(let row=0;row<2;row++)for(let col=0;col<3;col++)desk((col-1)*6,row===0?-6:-2,false,col+row*3);
 desk(0,3.5,true);
 // Glass room dividers and large briefing panel, door, clock and plants.
 box(0,2.54,-9.72,4.7,1.7,.12,'#132637');box(0,2.53,-9.62,4.39,1.45,.018,'#1d6275');pane(0,2.53,-9.50,4.14,1.36,'wall');
 for(let i=0;i<6;i++)box(-1.8+i*.72,2.25,-9.6,.50,.055,.025,i%2?'#4c9bb3':'#8acbcb');
 box(-7,1.4,-9.7,1.45,2.8,.07,'#647d8a');box(-6.48,1.30,-9.6,.07,.18,.06,'#c3d6d6');
 box(6.2,2.9,-9.65,.66,.66,.045,'#d6e4e5');box(6.2,2.9,-9.61,.48,.49,.03,'#1b3541');
 for(let x of [-9.7,9.7])for(let z of [-4,3]){box(x,.36,z,.60,.73,.60,'#68747a');box(x,.95,z,.1,.92,.12,'#316c57');for(let i=-1;i<=1;i++){box(x+i*.22,1.25,z,.36,.50,.17,'#458c72')}}
 // Operational equipment: shoulder-mounted headsets, intercoms, ID panels and diffuse task lights.
 for(const z of [-6,-2,3.5])for(const x of [-6,0,6]){
   if(z===3.5&&x!==0)continue;
   box(x-1.35,.94,z+.42,.25,.14,.34,'#253e4b'); // phone base
   box(x-1.35,1.015,z+.40,.22,.045,.27,'#617c87'); // phone display
   box(x-1.37,1.095,z+.41,.31,.08,.09,'#172d3b'); // handset
   box(x+.96,1.01,z+.18,.035,.40,.035,'#b6d5ce'); // microphone stem
   box(x+.96,1.22,z+.18,.16,.07,.12,'#0c1c29'); // microphone head
   box(x+1.54,.86,z+.06,.18,.07,.15,'#242f37'); // controls
   for(let q=0;q<3;q++)box(x+1.47+q*.06,.90,z+.09,.035,.018,.032,['#e2a34e','#66bd96','#d76967'][q]);
   box(x-1.66,1.13,z-.22,.05,.58,.06,'#8a9c9f'); // desk lamp
   box(x-1.66,1.43,z-.30,.47,.055,.23,'#d4dcd9');
   box(x-.3,.80,z+.64,.36,.008,.15,'#c0c8cb'); // ID plate
   box(x+.45,.855,z+.56,.28,.025,.18,'#d0d8d6'); // paper dispatch notes
   box(x+.47,.88,z+.57,.19,.009,.012,'#657582'); // note line
   box(x+.42,.88,z+.62,.17,.009,.012,'#657582');
   box(x-1.02,.87,z+.57,.21,.12,.21,'#d2e2dd'); // cup / drinking water
   box(x-1.02,.93,z+.57,.16,.015,.16,'#173d4a');
 }
 // Operations director wall with layered map / status boards.
 for(let col=0;col<7;col++)for(let row=0;row<3;row++){
   box(-2.1+col*.71,3.0-row*.26,-9.51,.56,.15,.028,
       row===0?'#2d7183':(col+row)%4===0?'#bd7b4f':(col+row)%3===0?'#487d74':'#335a71');
 }
 for(let row=0;row<3;row++){
   box(8.9,2.9-row*.40,-9.52,2.1,.31,.045,'#213b4e');
   for(let col=0;col<9;col++)box(8.04+col*.21,2.96-row*.40,-9.47,.14,.038,.021,
     (col+row)%5===0?'#72b7a6':'#557b86');
 }
 // Acoustic wall elements and glass partitions, preserving player sightlines.
 for(let x of [-10.82,10.82])for(let z=-8;z<=8;z+=1.12){
  box(x,3.55,z,.048,.48,.56,(Math.abs(z)%3)<1?'#445969':'#3c5060');
 }
 for(let x of [-8.7,8.7]){
  box(x,2.0,7.6,.10,2.9,3.5,'#456679');
  box(x,3.48,7.6,.14,.07,3.6,'#8ba5af');
  box(x,1.30,7.6,.16,.06,3.6,'#8ba5af');
 }
 // Cable ducts and low-brightness access lights.
 for(let x=-8;x<=8;x+=2){box(x,.08,-8.95,.84,.06,.12,'#213f50');box(x,.13,-8.95,.15,.03,.12,'#4a9f9e')}
 // Wall glass panels are represented by subtle blue frames to preserve visibility.
 for(let x of [-10.85,10.85])for(let z=-7;z<=7;z+=4){box(x,2,z,.08,2.2,.07,'#7d9baa');box(x,3.05,z+2,.09,.05,3.7,'#7d9baa')}
}
function shader(type,src){const sh=gl.createShader(type);gl.shaderSource(sh,src);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw Error('Shader: '+gl.getShaderInfoLog(sh));return sh}
function program(vs,fs){const p=gl.createProgram();gl.attachShader(p,shader(gl.VERTEX_SHADER,vs));gl.attachShader(p,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error('WebGL Link: '+gl.getProgramInfoLog(p));return p}
const vsColor=`attribute vec3 aPosition; attribute vec3 aColor; uniform mat4 uVP; varying vec3 vColor; void main(){gl_Position=uVP*vec4(aPosition,1.);vColor=aColor;}`;
const fsColor=`precision mediump float; varying vec3 vColor; void main(){gl_FragColor=vec4(vColor,1.);}`;
const vsTex=`attribute vec3 aPosition; attribute vec2 aUV; uniform mat4 uVP; varying vec2 vUV; void main(){gl_Position=uVP*vec4(aPosition,1.);vUV=aUV;}`;
const fsTex=`precision mediump float; varying vec2 vUV; uniform sampler2D uImage;void main(){gl_FragColor=texture2D(uImage,vUV);}`;
function setup(){gl=canvas.getContext('webgl',{antialias:true,alpha:false,powerPreference:'low-power'})||canvas.getContext('experimental-webgl');if(!gl)throw Error('WebGL nicht verfügbar');
 gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.clearColor(.055,.095,.14,1);colorProgram=program(vsColor,fsColor);textureProgram=program(vsTex,fsTex);
 generate();geo=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,geo);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vertices),gl.STATIC_DRAW);
 monitorMeshes=monitorInfo.map(q=>{const {x,y,z,w,h}=q,zz=z+.005,l=x-w/2,r=x+w/2,b=y-h/2,t=y+h/2;
 const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([l,b,zz,0,0,r,b,zz,1,0,r,t,zz,1,1,l,b,zz,0,0,r,t,zz,1,1,l,t,zz,0,1]),gl.STATIC_DRAW);return buf});
 screenTextures=monitorInfo.map((q)=>{const c=document.createElement('canvas');c.width=512;c.height=344;const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);return {canvas:c,texture:t,kind:q.kind}});
 updateScreens();
}
function updateScreens(){const s=g()?.s;if(!gl)return;for(const item of screenTextures){const {canvas:c,texture,kind}=item,ctx=c.getContext('2d');const isPeer=kind.startsWith('peer_');ctx.fillStyle='#081b29';ctx.fillRect(0,0,512,344);ctx.fillStyle=isPeer?'#214458':'#12394b';ctx.fillRect(0,0,512,50);ctx.fillStyle='#80e7ed';ctx.font='bold 25px system-ui';ctx.fillText(isPeer?'LEITPLATZ · KOLLEGEN':({call:'112 · NOTRUFANNAHME',case:'ELS · EINSATZBEARBEITUNG',resources:'FUNK · DISPOSITION'})[kind],18,33);
 if(s){const cases=s.incidents.filter(x=>x.phase!=='Abgeschlossen'),clock=`${String(Math.floor(s.minute/60)%24).padStart(2,'0')}:${String(s.minute%60).padStart(2,'0')}`;ctx.fillStyle='#f0ffff';ctx.font='19px monospace';ctx.fillText('SIM '+clock+'   ·   '+(g().areas[s.area]?.name||'Leitstelle').slice(0,25),18,83);const lines=kind==='wall'?[`${cases.length} OFFENE VORGAENGE`,`${cases.filter(i=>i.prio===1).length} PRIORITAET 1`,`${s.vehicles.filter(v=>v.status==='frei').length} FREIE KRAEFTE`,`${(s.colleagueRoster||[]).length} LEITPLAETZE`]:isPeer?[(s.colleagueRoster||[])[Number(kind.split('_')[1])%Math.max(1,(s.colleagueRoster||[]).length)]?.name||'Leitplatz besetzt',`${cases.length} offene Einsätze`,`Notrufe: ${cases.filter(i=>i.phase==='Anruf').length}`,`Status: ${cases.length>4?'hohe Belastung':'Regeldienst'}`]:kind==='call'?cases.slice(0,5).map(i=>`#${i.id} ${i.phase==='Anruf'?'ANRUF':'OFFEN'} ${i.city}`):kind==='case'?cases.slice(0,5).map(i=>`#${i.id} ${i.type}`):s.vehicles.slice(0,6).map(v=>`${v.id}: ${v.status}`);lines.forEach((l,i)=>{ctx.fillStyle=i%2?'#b9e7e9':'#e0f6f7';ctx.fillText(l.slice(0,41),18,124+i*34)});
 ctx.fillStyle='#87bbc4';ctx.font='16px monospace';ctx.fillText(kind==='wall'?'SIMULIERTES LAGEBILD':isPeer?'KOLLEGENARBEITSPLATZ':'ANTIPPEN ZUM BEARBEITEN',18,318)}else{ctx.fillStyle='#c0dce0';ctx.font='22px monospace';ctx.fillText('LEITPLATZ NICHT BESETZT',20,120)}
 gl.bindTexture(gl.TEXTURE_2D,texture);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,c);}}
function matMul(a,b){const out=Array(16).fill(0);for(let j=0;j<4;j++)for(let i=0;i<4;i++)for(let k=0;k<4;k++)out[j*4+i]+=a[k*4+i]*b[j*4+k];return out}
function matrix(aspect){const f=1/Math.tan(FOV/2),near=.05,far=75;const proj=[f/aspect,0,0,0,0,f,0,0,0,0,(far+near)/(near-far),-1,0,0,2*far*near/(near-far),0];
 const co=Math.cos(cam.yaw),si=Math.sin(cam.yaw),cp=Math.cos(cam.pitch),sp=Math.sin(cam.pitch);
 const right=[co,0,-si],forward=[-si*cp,sp,-co*cp],up=[si*sp,cp,co*sp],eye=[cam.x,cam.y,cam.z];
 const dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];const view=[right[0],up[0],-forward[0],0,right[1],up[1],-forward[1],0,right[2],up[2],-forward[2],0,-dot(right,eye),-dot(up,eye),dot(forward,eye),1];
 return {vp:new Float32Array(matMul(proj,view)),right,up,forward};
}
function projectPoint(x,y,z,axes,aspect,w,h){const d=[x-cam.x,y-cam.y,z-cam.z],dot=(a)=>d[0]*a[0]+d[1]*a[1]+d[2]*a[2],zDist=dot(axes.forward);if(zDist<=.05)return null;const t=Math.tan(FOV/2);return {x:(.5+dot(axes.right)/zDist/(t*aspect)*.5)*w,y:(.5-dot(axes.up)/zDist/t*.5)*h,d:zDist}}
function tapMonitor(e){const rect=canvas.getBoundingClientRect(),w=rect.width,h=rect.height,ratio=w/h,axes=matrix(ratio),px=e.clientX-rect.left,py=e.clientY-rect.top;let found=null;
 for(const m of monitorInfo){const corners=[[m.x-m.w/2,m.y-m.h/2,m.z],[m.x+m.w/2,m.y+m.h/2,m.z]].map(c=>projectPoint(...c,axes,ratio,w,h));if(corners.some(x=>!x))continue;const [a,b]=corners;const minX=Math.min(a.x,b.x),maxX=Math.max(a.x,b.x),minY=Math.min(a.y,b.y),maxY=Math.max(a.y,b.y);if(px>=minX-6&&px<=maxX+6&&py>=minY-8&&py<=maxY+8&&(!found||a.d<found.d))found={kind:m.kind,d:a.d}}
 if(found&&found.d<18){if(found.kind==='wall')window.LDShiftUI21?.open?.();else if(found.kind.startsWith('peer_'))window.LDColleagueControl?.open?.();else if(found.d<7)window.openWorkstation?.(found.kind);return}
 // Device hotspots are projected from the physical instruments on the player's desk.
 // They work with mouse or touch even when the workspace is not open.
 for(const device of [{x:-1.35,y:1.04,z:3.91,action:'phone'},
                       {x:.96,y:1.18,z:3.75,action:'radio'}]){
   const p=projectPoint(device.x,device.y,device.z,axes,ratio,w,h);
   if(p&&p.d<5.3&&Math.hypot(px-p.x,py-p.y)<Math.max(23,37/p.d*2.0)){
     if(device.action==='phone')window.openWorkstation?.('call');
     else window.LDComms?.open?.();return;
   }
 }
 for(const peer of peers){const center=projectPoint(peer.x,peer.y,peer.z,axes,ratio,w,h),right=projectPoint(peer.x+.4,peer.y,peer.z,axes,ratio,w,h);if(!center||!right)continue;const radius=Math.max(14,Math.abs(right.x-center.x));if(Math.abs(px-center.x)<radius&&Math.abs(py-center.y)<radius*1.7){document.getElementById('colleague-toggle')?.click();return}}}
function isClear(x,z){if(Math.abs(x)>9.45||Math.abs(z)>8.4)return false;return ![[0,3.5],[-6,-6],[0,-6],[6,-6],[-6,-2],[0,-2],[6,-2]].some(([a,b])=>Math.abs(x-a)<2.15&&Math.abs(z-b)<1.12)}
function walkTo(x,z){if(isClear(x,cam.z))cam.x=x;if(isClear(cam.x,z))cam.z=z}
function move(d){walkTo(cam.x-Math.sin(cam.yaw)*d,cam.z-Math.cos(cam.yaw)*d)}
function bindCanvas(){canvas.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,sx:e.clientX,sy:e.clientY,moved:false};canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.moved||=Math.abs(e.clientX-drag.sx)+Math.abs(e.clientY-drag.sy)>9;cam.yaw-=dx*.0045;cam.pitch=clamp(cam.pitch-dy*.0045,-.98,.86);drag.x=e.clientX;drag.y=e.clientY});canvas.addEventListener('pointerup',e=>{if(!drag)return;const tap=!drag.moved;drag=null;if(tap)tapMonitor(e)})}
function reset(){if(labelLayer){labelLayer.remove();labelLayer=null}if(canvas){canvas.remove();canvas=null}if(gl){gl.deleteBuffer(geo);monitorMeshes.forEach(m=>gl.deleteBuffer(m));screenTextures.forEach(m=>gl.deleteTexture(m.texture));gl.deleteProgram(colorProgram);gl.deleteProgram(textureProgram);gl=null}room=null}
function start(el){room=el;canvas=document.createElement('canvas');canvas.dataset.renderBackend='webgl';canvas.setAttribute('aria-label','Begehbarer 3D-Leitstellenraum. Monitore antippen.');canvas.style.cssText='position:absolute;inset:0;display:block;width:100%;height:100%;touch-action:none;cursor:crosshair;z-index:1';el.prepend(canvas);labelLayer=document.createElement('div');labelLayer.id='ld21-room-labels';labelLayer.style.cssText='position:absolute;inset:0;z-index:2;pointer-events:none;overflow:hidden';el.append(labelLayer);try{setup()}catch(err){console.warn('Lokales WebGL kann nicht gestartet werden: ',err);disabled=true;reset();if(window.LDRoom3D && window.LDRoom3D.isLocal)window.LDRoom3D=null;return}bindCanvas();}
function updatePeerLabels(axes,aspect,w,h){if(!labelLayer)return;const s=g()?.s;if(!s)return;const roster=s.colleagueRoster||[];labelLayer.replaceChildren();for(let j=0;j<peers.length;j++){const peer=peers[j],p=projectPoint(peer.x,peer.y+.42,peer.z,axes,aspect,w,h);if(!p||p.d<2||p.d>17||p.x<-20||p.x>w+20||p.y<-20||p.y>h+20)continue;const label=document.createElement('span');const operator=roster[j%Math.max(1,roster.length)];label.textContent=(operator?.name||`Leitplatz ${j+2}`).slice(0,26);label.style.cssText=`position:absolute;left:${p.x}px;top:${p.y}px;transform:translate(-50%,-100%);padding:3px 7px;border:1px solid #5c99ac99;background:#0b2539d9;color:#d7f5f8;border-radius:4px;font:10px system-ui;white-space:nowrap`;labelLayer.append(label)}}
function frame(time){requestAnimationFrame(frame);const state=g(),el=document.querySelector('.room');if(!state?.s||!el){if(canvas)reset();return}if(disabled)return;if(!canvas||el!==room)start(el);if(!gl)return;
 const free=state.mode==='free';if(!free&&!seat){cam.x=0;cam.z=5.7;cam.yaw=0;cam.pitch=-.045}seat=!free;cam.y=free?1.68:1.5;
 if(document.getElementById('elsdesk')?.classList.contains('open')||document.getElementById('ld-gis')?.classList.contains('open')||document.getElementById('ld-situation')?.classList.contains('open'))return;
 const dt=Math.min(.06,(time-last)/1000||.016);if(free){const v=dt*2.1;if(keys.w||keys.arrowup)move(v);if(keys.s||keys.arrowdown)move(-v);if(keys.a)walkTo(cam.x-Math.cos(cam.yaw)*v,cam.z+Math.sin(cam.yaw)*v);if(keys.d)walkTo(cam.x+Math.cos(cam.yaw)*v,cam.z-Math.sin(cam.yaw)*v)}
 if(time-last<28)return;last=time;
 const w=Math.max(1,el.clientWidth),h=Math.max(1,el.clientHeight),scale=Math.min(window.devicePixelRatio||1,w<840?1.2:1.5),rw=Math.round(w*scale),rh=Math.round(h*scale);if(canvas.width!==rw||canvas.height!==rh){canvas.width=rw;canvas.height=rh;gl.viewport(0,0,rw,rh)}
 const axes=matrix(w/h);if(time-lastScreens>1700){updateScreens();updatePeerLabels(axes,w/h,w,h);lastScreens=time}const {vp}=axes;
 gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 gl.useProgram(colorProgram);gl.uniformMatrix4fv(gl.getUniformLocation(colorProgram,'uVP'),false,vp);gl.bindBuffer(gl.ARRAY_BUFFER,geo);
 const p=gl.getAttribLocation(colorProgram,'aPosition'),c=gl.getAttribLocation(colorProgram,'aColor');gl.enableVertexAttribArray(p);gl.enableVertexAttribArray(c);gl.vertexAttribPointer(p,3,gl.FLOAT,false,24,0);gl.vertexAttribPointer(c,3,gl.FLOAT,false,24,12);gl.drawArrays(gl.TRIANGLES,0,vertices.length/6);
 gl.useProgram(textureProgram);gl.uniformMatrix4fv(gl.getUniformLocation(textureProgram,'uVP'),false,vp);const tp=gl.getAttribLocation(textureProgram,'aPosition'),uv=gl.getAttribLocation(textureProgram,'aUV');gl.enableVertexAttribArray(tp);gl.enableVertexAttribArray(uv);gl.activeTexture(gl.TEXTURE0);gl.uniform1i(gl.getUniformLocation(textureProgram,'uImage'),0);
 monitorMeshes.forEach((buf,i)=>{gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.vertexAttribPointer(tp,3,gl.FLOAT,false,20,0);gl.vertexAttribPointer(uv,2,gl.FLOAT,false,20,12);gl.bindTexture(gl.TEXTURE_2D,screenTextures[i].texture);gl.drawArrays(gl.TRIANGLES,0,6)});
 gl.disableVertexAttribArray(tp);gl.disableVertexAttribArray(uv);gl.disableVertexAttribArray(p);gl.disableVertexAttribArray(c);
}
window.LDRoom3D={isSoftware:false,isLocal:true,nudge:(d)=>move(d*.46),turn:(d)=>{cam.yaw+=d*Math.PI/180},position:()=>({fx:cam.x,fz:cam.z,yaw:cam.yaw})};
window.updateRoom3D=()=>{lastScreens=0};
document.addEventListener('keydown',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(e.target?.tagName)||document.getElementById('elsdesk')?.classList.contains('open'))return;keys[e.key.toLowerCase()]=true});document.addEventListener('keyup',e=>{delete keys[e.key.toLowerCase()]});window.addEventListener('blur',()=>{Object.keys(keys).forEach(k=>delete keys[k])});
requestAnimationFrame(frame);
})();
