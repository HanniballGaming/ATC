/* LEITSTELLE DEUTSCHLAND – repeatable, local training scenarios.
   Scripted training events are fictional, not operational dispatch advice. */
(()=>{'use strict';
const get=()=>window.LDOperations?.getState?.();
const escapeHTML=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const scenarios={
 cityCrash:{label:'Verkehrsunfall · mehrere Anrufe',description:'Zwei Meldungen vom selben Ort. Aufnehmen, nachfragen, Kräfte disponieren und gegebenenfalls Meldungen zusammenführen.',
 calls:[['Verkehrsunfall mit Verletzten',0],['Verkehrsunfall mit Verletzten',0]],events:[{after:4,call:0,text:'Nachmeldung vom Einsatzort: Eine Person kann das Fahrzeug nicht selbstständig verlassen.',priority:1}]},
 stormCluster:{label:'Unwetter · mehrere Einsatzstellen',description:'Gleichzeitige wetterbedingte Hilfeleistungen in mehreren Orten. Fahrzeuge priorisieren und Gebietsabdeckung beobachten.',
 calls:[['Umgestürzter Baum',0],['Wasserschaden',1],['Türöffnung / Hilflose Person',2]],events:[{after:5,call:1,text:'Nachmeldung: Wasserstand im Keller steigt weiter.',priority:2},{after:8,call:2,text:'Weitere Meldung: Der Zugang zur Wohnung ist verschlossen.',priority:2}]},
 majorCrash:{label:'Großschadenslage · Autobahn',description:'Größerer Unfall mit Nachforderungen und mehreren Anrufern. Einsatzstelleninformationen dokumentieren.',
 calls:[['Massenanfall Verletzter',0],['Verkehrsunfall mit Verletzten',0]],events:[{after:3,call:0,text:'Lagefortschreibung: Es werden weitere verletzte Personen gemeldet.',priority:1},{after:7,call:0,text:'Nachforderung: Weitere Einsatzkräfte könnten benötigt werden.',priority:1}]}
};
function scenarioStart(s,key){const a=scenarios[key],g=window.getGame?.();if(!s||!a||!g)return {ok:false,reason:'Keine aktive Spielrunde'};
 if(s.exercise?.active)return {ok:false,reason:'Vorher laufendes Übungsszenario beenden'};
 if(s.incidents.filter(i=>i.phase==='Anruf').length>2)return {ok:false,reason:'Zu viele unangenommene Notrufe im System'};
 const cities=g.areas?.[s.area]?.cities||[];if(!cities.length)return {ok:false,reason:'Keine Orte in der Region'};
 const selected=panel.querySelector('[data-exercise-city]')?.value;
 const cityIndex=Math.max(0,cities.indexOf(selected));
 const calls=[];const created=[];
 const types=g.types||[];
 for(const [kind,offset] of a.calls){
   const template=types.find(t=>t.name===kind);if(!template)continue;
   const incident=window.LDLogic.spawn(s,g.areas,[template],message=>s.logs.unshift(message));
   if(!incident)break;
   const city=cities[(cityIndex+offset)%cities.length];
   const c=window.LDCityCoords?.[city];
   incident.city=city;
   incident.coords=c?(Array.isArray(c)?[c[0],c[1]]:[c.lat,c.lon]):null;
   incident.location=`${city} · simulierter Einsatzort`;
   incident.documentation??={};incident.documentation.location=incident.location;
   incident.trainingScenario=key;
   incident.history?.unshift({minute:s.minute,text:'Übungsszenario gestartet: '+a.label});
   calls.push(incident.id);created.push(incident);
 }
 if(calls.length!==a.calls.length)return {ok:false,reason:'Übung wegen zu vieler Notrufe nicht vollständig gestartet'};
 s.exercise={active:true,key,startedAt:s.minute,city:cities[cityIndex],calls,events:a.events.map((ev,index)=>({index,incidentId:calls[ev.call],at:s.minute+ev.after,text:ev.text,priority:ev.priority,fired:false})),mode:'only-scenario',randomBackup:s.nextCall};
 s.nextCall=1000000;
 s.logs.unshift(`ÜBUNG · ${a.label} in ${cities[cityIndex]} gestartet · ${calls.length} Meldungen (fiktiv)`);
 window.LDOperations?.save?.();window.LDRefresh?.();
 return {ok:true,calls};
}
function scenarioEnd(s){if(!s?.exercise?.active)return false;
 s.exercise.active=false;s.exercise.finishedAt=s.minute;
 s.nextCall=Math.max(4,Math.min(12,s.exercise.randomBackup||8));
 s.logs.unshift('ÜBUNG · Szenario beendet · normaler Simulationsbetrieb wiederhergestellt');
 window.LDOperations?.save?.();window.LDRefresh?.();return true;
}
function onTick(s){const e=s?.exercise;if(!e?.active)return;
 s.nextCall=1000000;
 for(const item of e.events){if(item.fired||s.minute<item.at)continue;
   item.fired=true;
   const incident=s.incidents.find(i=>i.id===item.incidentId);
   if(!incident||incident.phase==='Abgeschlossen')continue;
   incident.prio=Math.min(Number(incident.prio)||3,item.priority);
   incident.history??=[];incident.history.unshift({minute:s.minute,text:item.text});
   incident.transcript??=[];incident.transcript.push(`${String(Math.floor(s.minute/60)%24).padStart(2,'0')}:${String(s.minute%60).padStart(2,'0')} · NACHTRAG: ${item.text}`);
   s.logs.unshift(`ÜBUNG · #${incident.id}: ${item.text}`);
   window.LDSound?.radio?.();
 }
}
const baseTick=window.LDLogic.tick;
window.LDLogic.tick=function(s,...args){if(s?.exercise?.active)s.nextCall=1000000;
 const result=baseTick.call(this,s,...args);onTick(s);return result;
};
const sheet=document.createElement('style');sheet.textContent=`
#ld-exercise{position:fixed;inset:0;background:#0a1b29;color:#eaf5fa;z-index:10040;display:none;flex-direction:column;font:14px system-ui}
#ld-exercise.open{display:flex}#ld-exercise header{display:flex;gap:12px;align-items:center;flex-wrap:wrap;padding:15px;background:#17344a;border-bottom:1px solid #5c8194}
#ld-exercise main{overflow:auto;max-width:980px;width:100%;margin:auto;padding:18px}
#ld-exercise button,#ld-exercise select{background:#184964;border:1px solid #6999ac;border-radius:7px;padding:11px;color:white;font:inherit;min-height:43px}
#ld-exercise button{cursor:pointer}#ld-exercise .intro{color:#bdd4e0;font-size:12px}#ld-exercise .layout{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;margin:14px 0}
#ld-exercise .tile{border:1px solid #3b6b81;background:#132d40;border-radius:8px;padding:13px}#ld-exercise .tile strong{display:block;margin-bottom:6px}
#ld-exercise .events li{margin:8px 0}#ld-exercise .st{color:#a9c9d7;font-size:12px}#ld-exercise .warning{color:#ffc98f}
#ld-exercise-toggle{position:fixed;bottom:120px;left:14px;z-index:900;background:#17566d;color:white;border:1px solid #69aabd;border-radius:7px;padding:10px;cursor:pointer}
@media(max-width:680px){#ld-exercise header{padding:10px}#ld-exercise main{padding:11px}#ld-exercise-toggle{bottom:118px;left:8px;padding:8px}}
`;document.head.append(sheet);
const panel=document.createElement('div');panel.id='ld-exercise';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-label','Übungsszenarien');document.body.append(panel);
function render(){const s=get();if(!s){close();return}const g=window.getGame?.();const cities=g?.areas?.[s.area]?.cities||[];
 const city=panel.querySelector('[data-exercise-city]')?.value||cities[0];const ex=s.exercise;const desc=ex&&scenarios[ex.key];
 const selectedCalls=ex?.calls?.map(id=>s.incidents.find(i=>i.id===id)).filter(Boolean)||[];
 panel.innerHTML=`<header><b>LEITSTELLE DEUTSCHLAND · ÜBUNGSLEITUNG</b><span class="st">Szenarien mit fiktiven Daten</span><span style="flex:1"></span><button data-exercise="close">Zurück ✕</button></header>
 <main><h2>Übungs- und Einsatztraining</h2><p class="intro">Hier werden zusammenhängende fiktive Meldungen erzeugt. Kein Einsatztraining mit amtlicher AAO oder medizinisch geprüftem Ablauf.</p>
 ${ex?.active?`<div class="tile"><strong>Laufende Übung: ${escapeHTML(desc?.label||ex.key)}</strong><div>Start: Sim.-Minute ${ex.startedAt} · Einsatzort ${escapeHTML(ex.city)} · ${selectedCalls.filter(i=>i.phase==='Abgeschlossen').length}/${selectedCalls.length} abgeschlossene Vorgänge</div><p class="st">Geplante Lagemeldungen: ${ex.events.filter(x=>x.fired).length}/${ex.events.length} ausgelöst</p><button data-exercise="end">Übung beenden · normalen Simulationsbetrieb fortsetzen</button></div>`:
 `<label>Hauptort der neuen Übung <select data-exercise-city>${cities.map(c=>`<option value="${escapeHTML(c)}" ${c===city?'selected':''}>${escapeHTML(c)}</option>`).join('')}</select></label><div class="layout">${Object.entries(scenarios).map(([key,val])=>`<div class="tile"><strong>${escapeHTML(val.label)}</strong><p class="st">${escapeHTML(val.description)}</p><button data-exercise="start" data-key="${key}">Übung starten</button></div>`).join('')}</div>`}
 <h3>Einsatzübersicht</h3><div class="layout">${(selectedCalls.length?selectedCalls:s.incidents.filter(i=>i.phase!=='Abgeschlossen').slice(0,6)).map(i=>`<div class="tile"><b>#${i.id} · ${escapeHTML(i.type)}</b><p class="st">${escapeHTML(i.city)} · Priorität ${i.prio} · ${escapeHTML(i.phase)}</p><p class="st">Kräfte: ${(i.assigned||[]).length}; offener Bedarf: ${(i.need||[]).join(', ')||'keiner'}</p></div>`).join('')||'<p>Derzeit keine Einsätze.</p>'}</div>
 <h3>Aktuelle Übungsmeldungen</h3><ul class="events">${(ex?.events||[]).map(ev=>`<li>${ev.fired?'✓ Abgesetzt':'Geplant'} · Sim.-Minute ${ev.at} · #${ev.incidentId} · ${escapeHTML(ev.text)}</li>`).join('')||'<li>Keine Übung aktiv.</li>'}</ul><p class="warning st">Normale Notrufe werden während der Übung ausgesetzt und nach Übungsende wieder aktiviert.</p></main>`;
}
function open(){if(!get())return;panel.classList.add('open');render()}
function close(){panel.classList.remove('open')}
panel.addEventListener('click',e=>{const b=e.target.closest('[data-exercise]');if(!b)return;
 switch(b.dataset.exercise){case 'close':close();return;case 'end':scenarioEnd(get());break;case 'start':{const res=scenarioStart(get(),b.dataset.key);if(!res.ok)alert(res.reason);break}}
 render();
});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&panel.classList.contains('open')){e.preventDefault();e.stopImmediatePropagation();close()}},true);
const btn=document.createElement('button');btn.id='ld-exercise-toggle';btn.textContent='📋 Einsatztraining';btn.onclick=open;document.body.append(btn);
setInterval(()=>{btn.style.display=get()?'block':'none';if(panel.classList.contains('open'))render()},3500);
window.LDExercise={start:scenarioStart,end:scenarioEnd,onTick,scenarios,open};
})();
