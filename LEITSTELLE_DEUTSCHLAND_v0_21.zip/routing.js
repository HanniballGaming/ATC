/* Optional street-based routing for a fictional training simulator.
   OSRM's public demo is rate limited. Always fall back to a clearly labeled
   coordinate estimate, never claim live traffic or measured response times. */
(()=>{'use strict';
const memo=new Map(),inflight=new Map(),queue=[];
let running=false,lastCall=0;
const rad=x=>x*Math.PI/180;
function crow(a,b){
 const x=rad(b.lat-a.lat),y=rad(b.lon-a.lon);
 const v=Math.sin(x/2)**2+Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(y/2)**2;
 return 12742*Math.asin(Math.min(1,Math.sqrt(Math.max(0,v))));
}
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function fallback(a,b){
 const distanceKm=crow(a,b)*1.42;
 return {distanceKm,drivingSeconds:Math.max(240,distanceKm/48*3600),
  method:'Koordinaten-Ersatzschätzung (keine Straßenroute)',path:null,geometrySource:'none'};
}
function normalizeRoute(points){
 if(!Array.isArray(points)||points.length<2||points.length>100000)return null;
 const normalized=points.filter(p=>Array.isArray(p)&&p.length>=2&&Number.isFinite(p[0])&&Number.isFinite(p[1])).map(p=>[p[1],p[0]]);
 if(normalized.length<2)return null;
 const step=Math.max(1,Math.ceil(normalized.length/170));
 const output=normalized.filter((_,i)=>i%step===0);
 const end=normalized.at(-1);
 if(output.at(-1)?.[0]!==end[0]||output.at(-1)?.[1]!==end[1])output.push(end);
 return output;
}
async function pump(){
 if(running)return;
 running=true;
 while(queue.length){
  const task=queue.shift();
  const ms=1500-(Date.now()-lastCall);
  if(ms>0)await pause(ms);
  lastCall=Date.now();
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),8500);
  let result;
  try{
   const a=task.a,b=task.b;
   const url=`https://router.project-osrm.org/route/v1/driving/${a.lon.toFixed(5)},${a.lat.toFixed(5)};${b.lon.toFixed(5)},${b.lat.toFixed(5)}?overview=simplified&geometries=geojson&steps=false`;
   const response=await fetch(url,{signal:controller.signal});
   if(!response.ok)throw Error('Routing-HTTP-'+response.status);
   const data=await response.json();
   if(data.code!=='Ok'||!data.routes?.[0]||!Number.isFinite(data.routes[0].duration))throw Error('Keine Straßenroute');
   const route=data.routes[0];
   result={distanceKm:route.distance/1000,drivingSeconds:route.duration,
    method:'OSRM · Straßennetz ohne Live-Verkehr',path:normalizeRoute(route.geometry?.coordinates),geometrySource:'OSRM'};
  }catch{result=fallback(task.a,task.b)}
  finally{clearTimeout(timeout)}
  memo.set(task.key,result);inflight.delete(task.key);task.resolve(result);
 }
 running=false;
}
function network(a,b){
 const key=[a.lat.toFixed(4),a.lon.toFixed(4),b.lat.toFixed(4),b.lon.toFixed(4)].join(':');
 if(memo.has(key))return Promise.resolve(memo.get(key));
 if(inflight.has(key))return inflight.get(key);
 const p=new Promise(resolve=>queue.push({key,a,b,resolve}));
 inflight.set(key,p);pump();return p;
}
async function route(a,b,{priority=false,turnoutSeconds=90}={}){
 if(!a||!b||![a.lat,a.lon,b.lat,b.lon].every(Number.isFinite))throw Error('Koordinaten ungültig');
 const base=await network(a,b);
 return {...base,turnoutSeconds,estimatedSeconds:Math.round(turnoutSeconds+base.drivingSeconds*(priority?.9:1)),
  estimated:true,priority,traffic:'keine Live-Verkehrsdaten'};
}
/* Linear interpolation over actual segment lengths in the returned road route.
   Straight-line fallback is deliberately named and never presented as a GPS track. */
function interpolate(path,fraction){
 if(!Array.isArray(path)||path.length<2)return null;
 const f=Math.min(1,Math.max(0,Number(fraction)||0)),lengths=[];
 let sum=0;
 for(let j=1;j<path.length;j++){
  const a={lat:path[j-1][0],lon:path[j-1][1]},b={lat:path[j][0],lon:path[j][1]};
  const length=crow(a,b);lengths.push(length);sum+=length;
 }
 if(sum<=.000001)return path[0].slice();
 let target=f*sum;
 for(let j=1;j<path.length;j++){
  if(target<=lengths[j-1]||j===path.length-1){
   const r=lengths[j-1]>0?Math.min(1,target/lengths[j-1]):0;
   return [path[j-1][0]+(path[j][0]-path[j-1][0])*r,path[j-1][1]+(path[j][1]-path[j-1][1])*r];
  }
  target-=lengths[j-1];
 }
 return path.at(-1).slice();
}
window.LDRouting={route,crow,interpolate,normalizeRoute,fallback};
})();
