/* v0.21: context-aware, local caller conversation enrichment. Original fictional
   responses only. No LLM or medical dispatch protocol. */
(()=>{'use strict';
const api=window.LDLogic;if(!api?.converse)return;
const previous=api.converse;
const normalize=t=>String(t||'').toLocaleLowerCase('de-DE').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ß/g,'ss');
const fmt=s=>`${String(Math.floor((s.minute||0)/60)%24).padStart(2,'0')}:${String((s.minute||0)%60).padStart(2,'0')}`;
function memory(i){return i.callerConversation21??={mood:['beunruhigt','aufgeregt','angespannt','unsicher'][Math.abs(Number(i.id)||0)%4],asked:{},arrivedHelp:false};}
function classify(text){const q=normalize(text);
 const patterns=[
 ['line',/horen sie mich|sind sie noch dran|verstehen sie mich|ist die verbindung/],
 ['alone',/sind sie allein|ist jemand bei ihnen|weitere helfer|noch jemand da/],
 ['evac',/alle.*drau(?:ss|ß)en|alle.*evakuier|menschen.*gebaude|noch jemand im haus/],
 ['doors',/t[uü]r.*offen|abgeschlossen|eingesperrt|klingel|turschloss/],
 ['landmark',/auffalliges gebaude|orientierungspunkt|erkennbar|findet man|markantes/],
 ['deterioration',/wird es schlimmer|verschlechter|zustand.*andert|neue symptome/],
 ['noise',/was.*hintergrund|welche ger[aä]usche|h[oö]ren sie etwas|hintergrundger[aä]usch/],
 ['support',/bleiben sie ruhig|ich bin bei ihnen|wir helfen ihnen|sie machen das gut/],
 ['locationcheck',/best[aä]tigen.*adresse|adresse.*korrekt|adresse.*bestatig|habe ich.*richtig verstanden/],
 ['wait',/bleiben sie am telefon|legen sie nicht auf|warten sie|nicht auflegen/],
 ];
 for(const [tag,re] of patterns)if(re.test(q))return tag;
 return null;
}
function reply(s,i,topic){const m=memory(i),p=window.LDDialogue?.profile?.(i)||{},kind=i.type||'',fire=/brand|feuer|kohlenmonoxid|rauch/i.test(kind),collision=/verkehr|unfall/i.test(kind);
 switch(topic){
 case 'line':return 'Ja, ich höre Sie. Ich bin noch am Telefon.';
 case 'alone':return m.asked.alone?'Es ist noch genauso: '+(i.id%3===0?'Eine weitere Person ist bei mir.':'Ich bin gerade allein.'):(i.id%3===0?'Eine weitere Person ist bei mir.':'Ich bin hier gerade allein.');
 case 'evac':return fire?'Ich kann nicht sicher sagen, ob alle draußen sind. Ich sehe noch Menschen in der Nähe.':'Ich weiß nicht, ob alle Betroffenen an einem sicheren Ort sind.';
 case 'doors':return fire?'Ich bin draußen. Ob die Eingangstür offen ist, weiß ich gerade nicht.':`Der Zugang ist über ${p.door||'den Haupteingang'} möglich. Eine weitere Tür kann ich nicht beurteilen.`;
 case 'landmark':return `Es ist in ${i.city||'dem genannten Ort'}. Die Adresse steht hier auf dem Gebäude, sonst kann ich keinen sicheren Orientierungspunkt nennen.`;
 case 'deterioration':{const f=(i.live?.followUps||[]).at(-1);return f?`Es hat sich etwas verändert: ${f.text.replace(/^#\d+ · /,'')}`:'Ich bin weiter bei der Person. Im Moment kann ich keine neue Veränderung erkennen.'}
 case 'noise':return fire?'Man hört im Hintergrund Menschen rufen, es ist sehr unruhig.':collision?'Man hört den Straßenverkehr und Stimmen.':'Es ist unruhig, aber ich kann nichts Eindeutiges erkennen.';
 case 'support':return ['Danke. Ich versuche ruhig zu bleiben.','Ja, ich bleibe hier. Bitte helfen Sie uns.','Okay. Ich versuche, mich zu konzentrieren.'][i.id%3];
 case 'locationcheck':return `Ja, ${i.city||'dieser Ort'} ist richtig. ${p.street?'Die Straße lautet '+p.street+'.':'Eine genaue Straße weiß ich gerade nicht.'}`;
 case 'wait':return 'Ich bleibe dran. Bitte sagen Sie mir, wenn Sie noch etwas wissen müssen.';
 default:return null;
 }
}
function converse(s,id,input,logger){const i=s?.incidents?.find(x=>x.id===id);if(!i||i.callEnded||['Anruf','Unversorgt','Abgeschlossen'].includes(i.phase))return previous.call(this,s,id,input,logger);
 const text=String(input||'').trim().slice(0,320),intent=classify(text);if(!intent)return previous.call(this,s,id,input,logger);
 const m=memory(i);m.asked[intent]=(m.asked[intent]||0)+1;
 const response=reply(s,i,intent);if(!response)return previous.call(this,s,id,input,logger);
 i.transcript??=[];i.history??=[];
 i.transcript.push(`${fmt(s)} · DISPONENT: ${text}`,`${fmt(s)} · ANRUFER: ${response}`);i.transcript=i.transcript.slice(-110);
 i.history.unshift({minute:s.minute,text:`Dialog zum Thema ${intent} protokolliert`});i.history=i.history.slice(0,80);i.freeQuestions=(i.freeQuestions||0)+1;
 logger?.(`#${i.id}: Rückfrage ${intent} beantwortet (Offline-Dialog)`);
 return {answer:response,matched:true,scripted:true,intent,version:21};
}
api.converse=converse;
window.LDDialogue21={classify,reply,converse,memory};
})();
