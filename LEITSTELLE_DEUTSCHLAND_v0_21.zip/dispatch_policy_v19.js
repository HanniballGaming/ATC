/* Public-facing fictional resource policy. Not a real AAO, emergency instruction or guaranteed response time. */
(()=>{'use strict';const api=window.LDLogic;if(!api)return;
const rawDispatch=api.dispatch,rawSuggestions=api.suggestions,rawTick=api.tick;
const pick=(s,kind,unit)=>kind==='FF'?5+(unit.id.charCodeAt(unit.id.length-1)%5):kind==='BF'?2+(unit.id.length%2):kind==='RD'?1+(unit.id.length%3):3;
function modelFor(v){if(['RTW','NEF','KTW'].includes(v.type))return 'RD';if(v.id.includes('HLF')||v.id.includes('DLK'))return Number(v.id.slice(-2))%3===0?'FF':'BF';return 'sonstige'}
function addModels(s){if(!s?.vehicles)return;for(const v of s.vehicles){v.crewModel??=modelFor(v);v.simulatedCrew=true;v.crewBaseMinutes??=pick(s,v.crewModel,v)}}
function turnout(s,v){addModels(s);let minutes=v.crewBaseMinutes;const hour=(s.minute/60)%24;
 if(hour<6||hour>=22)minutes+=(v.crewModel==='FF'?3:v.crewModel==='RD'?1:0);
 if(s.shiftControl?.preset==='storm'||s.trainingPreset==='storm')minutes+=1;
 if(s.workload==='hoch')minutes+=1;
 return Math.max(1,Math.round(minutes))}
api.dispatch=function(s,id,type,unitId,log){addModels(s);const i=s.incidents.find(x=>x.id===id);const before=new Set(i?.assigned||[]);const ok=rawDispatch(s,id,type,unitId,log);if(!ok)return ok;const vid=i.assigned.find(x=>!before.has(x)),v=s.vehicles.find(x=>x.id===vid);if(!v)return ok;
 const real=turnout(s,v);v.turnout=real;v.eta=real;v.departure=s.minute+real;v.turnoutProfile=`Modell ${v.crewModel} · ${real} Min.`;v.provenance='Ausrückmodell fiktiv; keine verifizierten Dienstpläne';
 if(i?.history)i.history.unshift({minute:s.minute,text:`Ausrückmodell ${v.id}: ${real} Sim.-Min., Besatzung ${v.crewModel} (Annahme)`});return true};
api.suggestions=function(s,i,type){addModels(s);const original=rawSuggestions(s,i,type);return original.map(x=>{const v=s.vehicles.find(v=>v.id===x.id);if(!v)return x;const time=s.minute%1440/60;const traffic= time>=7&&time<9||time>=16&&time<18?1.22:time>=22||time<5?.84:1;const newEta=Math.max(1,Number(x.minutes||0)+turnout(s,v)-(v.type==='HLF'||v.type==='DLK'?5:v.type==='KTW'?3:2));return {...x,minutes:Math.round(newEta*traffic*10)/10,method:`${x.method||'Schätzung'} · ${v.crewModel}-Ausrückmodell · Tagesprofil`}}).sort((a,b)=>a.minutes-b.minutes||a.id.localeCompare(b.id))};
api.tick=function(s,areas,types,log){addModels(s);return rawTick(s,areas,types,log)};
window.LDDispatchModel={turnout,modelFor,addModels};
})();
