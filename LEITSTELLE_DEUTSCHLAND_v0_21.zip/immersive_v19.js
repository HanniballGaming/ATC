/* Optional first-person-only workspace mode, fully reversible. */
(()=>{'use strict';const KEY='ld-immersive-v019';let immersive=false;try{immersive=localStorage.getItem(KEY)==='1'}catch{};
const style=document.createElement('style');style.textContent=`
body.ld-immersive .game{max-width:none;padding:8px 10px}
body.ld-immersive .game>.layout{display:none}
body.ld-immersive .room{height:calc(100dvh - 180px);min-height:280px;max-height:none}
body.ld-immersive .roomcontrols{background:#102536;border:1px solid #405e6b;border-radius:7px;padding:7px;margin:7px 0}
body.ld-immersive footer{display:none}
body.ld-immersive .status{font-size:12px}
#ld-immersion{background:#22566a;border-color:#80a9b5}
#ld-immersion[aria-pressed="true"]{background:#196a62;border-color:#5adbc3}
@media(max-width:650px){body.ld-immersive .room{height:calc(100dvh - 245px);min-height:250px}}
`;document.head.append(style);
function apply(){document.body.classList.toggle('ld-immersive',immersive);document.querySelector('#ld-immersion')?.setAttribute('aria-pressed',String(immersive));const b=document.querySelector('#ld-immersion');if(b)b.textContent=immersive?'▤ Übersichtsmodus':'◉ Ego-Vollbild'}
function toggle(){immersive=!immersive;try{localStorage.setItem(KEY,immersive?'1':'0')}catch{}apply();window.updateRoom3D?.()}
function controls(){const c=document.querySelector('.roomcontrols');if(!c)return;let b=c.querySelector('#ld-immersion');if(b)return;const holder=document.createElement('span');holder.className='actions';holder.style.cssText='display:flex;gap:6px;flex-wrap:wrap';holder.innerHTML='<button id="ld-immersion" aria-pressed="false">◉ Ego-Vollbild</button><button id="ld-immersion-call">☎ Telefon</button><button id="ld-immersion-radio">📻 Funk</button>';c.append(holder);holder.querySelector('#ld-immersion').onclick=toggle;holder.querySelector('#ld-immersion-call').onclick=()=>window.openWorkstation?.('call');holder.querySelector('#ld-immersion-radio').onclick=()=>window.LDComms?.open?.();apply()}
new MutationObserver(controls).observe(document.querySelector('#app'),{subtree:true,childList:true});controls();document.addEventListener('keydown',e=>{if(e.ctrlKey&&e.key.toLowerCase()==='i'&&window.getGame?.()?.s){e.preventDefault();toggle()}});
window.LDImmersive={toggle,apply,get enabled(){return immersive}};
})();
